import Vue from "vue";

import App from "./App.vue";
import router from "./router";

import vueNumeralFilterInstaller from "vue-numeral-filter";
import VueProgressBar from "vue-progressbar";
import Vue2TouchEvents from "vue2-touch-events";

import { library } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/vue-fontawesome";
import "./registerServiceWorker";

// Font awesome
import {
	faExclamationTriangle,
	faTimesCircle,
	faCheckCircle,
	faTimes,
	faCheck,
	faArrowRight,
} from "@fortawesome/free-solid-svg-icons";

library.add(
	faExclamationTriangle,
	faTimesCircle,
	faCheckCircle,
	faTimes,
	faCheck,
	faArrowRight
);
Vue.component("font-awesome-icon", FontAwesomeIcon);

Vue.use(vueNumeralFilterInstaller, { locale: "en-gb" });
Vue.use(VueProgressBar, {
	color: "rgb(255, 255, 255)",
	height: "2px",
	transition: {
		speed: "0.001s",
	},
});
Vue.use(Vue2TouchEvents);

Vue.config.productionTip = false;

new Vue({
	router,
	render: (h) => h(App),
}).$mount("#app");
