export default class Stats {
	constructor(
		startTime = null,
		truePositive = 0,
		falsePositive = 0,
		falseNegative = 0,
		trueNegative = 0,
		correctionTruePositive = 0,
		correctionFalseNegative = 0,
		wrongDirection = false
	) {
		this.startTime = startTime;
		this.endTime = null;
		this.timeTakenS = null;
		this.truePositive = truePositive; // correct targets clicked
		this.falsePositive = falsePositive; // missed targets (not clicked)
		this.falseNegative = falseNegative; // distractors clicked
		this.trueNegative = trueNegative; // missed distractors
		this.correctionTruePositive = correctionTruePositive; // clicked again on a target
		this.correctionFalseNegative = correctionFalseNegative; // clicked again on a distractor
		this.wrongDirection = wrongDirection;
	}

	addToTotals(stats) {
		this.truePositive += stats.truePositive;
		this.falsePositive += stats.falsePositive;
		this.falseNegative += stats.falseNegative;
		this.trueNegative += stats.trueNegative;
		this.correctionTruePositive += stats.correctionTruePositive;
		this.correctionFalseNegative += stats.correctionFalseNegative;
		this.wrongDirection = stats.wrongDirection;
	}
}
