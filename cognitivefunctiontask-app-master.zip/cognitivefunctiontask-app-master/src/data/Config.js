const basicThemeBackgroundColor = "#500066";
const superherosThemeBackgroundImage = "backroom.jpg";

export const config = {
	trialColours: ["#81d4fa", "#f48fb1", "#ce93d8", "#e6ee9c"],
	defaults: {
		tutorialTargets: [
			"L_0_sharp.png",
			"L_90_sharp.png",
			"L_180_sharp.png",
			"L_270_sharp.png",
		],
		tutorialDirection: {
			vertical: "tb",
			horizontal: "lr",
			lineByLine: "sd",
		},
	},
	themes: {
		superheroes: {
			tutorialTrial: {
				nearDistractors: [
					"X_0_sharp.png",
					"T_0_sharp.png",
					"T_90_sharp.png",
					"T_180_sharp.png",
					"T_270_sharp.png",
					"I_0_sharp.png",
					"I_90_sharp.png",
					"O_0_sharp.png",
					"O_90_sharp.png",
				],
				farDistractors: [
					"X_0_round.png",
					"T_0_round.png",
					"T_90_round.png",
					"T_180_round.png",
					"T_270_round.png",
					"L_0_round.png",
					"L_90_round.png",
					"L_180_round.png",
					"L_270_round.png",
					"I_0_round.png",
					"I_90_round.png",
					"O_0_round.png",
					"O_90_round.png",
					"O_180_round.png",
				],
				numRows: 3,
				numNodesPerRow: 15,
				padding: 10,
				timeLimit: 40,
				showTimeLimit: true,
				showTimeLimitNextButton: false,
				numTrials: 3,
				nearDistractorProportion: 20,
				withholdResponse: false,
				withholdNResponse: 1,
				withholdResponseOnlyForIsTarget: false,
				adaptive: false,
				adaptiveRules: [],
				trialIndex: 0,
			},
			tutorialScreens: [
				{
					background: "back.jpg",
					prompt: {
						text: "",
						speech: true,
						top: 7,
						left: 11,
						width: 45,
						height: 30,
						reverse: false,
					},
					character: {
						image: "3characters.png",
						top: 40,
						left: 24,
						width: 40,
					},
				},
				{
					background: superherosThemeBackgroundImage,
					prompt: {
						text: `We fight crime\nacross the galaxy!`,
						speech: true,
						top: 34,
						left: 44,
						width: 45,
						height: 30,
						reverse: false,
					},
					character: {
						image: "allcharacters.png",
						top: 0,
						left: 0,
						width: 100,
						relative: true,
					},
				},
				{
					background: "backroom_brokenship.jpg",
					prompt: {
						text: `But our spaceship\nis broken...`,
						speech: true,
						top: 29,
						left: 40,
						width: 41,
						height: 30,
						reverse: false,
					},
					ship: true,
					character: {
						image: "purple.png",
						top: 64,
						left: 62,
						width: 12.5,
					},
				},
				{
					background: "backroom_brokenship.jpg",
					prompt: {
						text: `...and we need your\nhelp to fix it!`,
						speech: true,
						top: 27,
						left: 42,
						width: 41,
						height: 30,
						reverse: false,
					},
					ship: true,
					character: {
						image: "red.png",
						top: 57,
						left: 71,
						width: 12.5,
					},
				},
				{
					background: superherosThemeBackgroundImage,
					prompt: {
						text: `We have lots\nof parts...`,
						speech: true,
						top: 29,
						left: 0,
						width: 30,
						height: 30,
						reverse: true,
					},
					placeholder: true,
					character: {
						image: "green.png",
						top: 64,
						left: 2,
						width: 16,
					},
				},
				{
					background: superherosThemeBackgroundImage,
					prompt: {
						text: `Can you tap the ones\nwe need... in the right order?`,
						speech: true,
						top: 13,
						left: 0,
						width: 40,
						height: 44,
						reverse: true,
					},
					placeholder: true,
					character: {
						image: "black.png",
						top: 58,
						left: 2,
						width: 14,
					},
				},
				{
					background: superherosThemeBackgroundImage,
					prompt: {
						text: "You will need to tap the parts in the parts box",
					},
					task: {
						demo: true,
						highlight: {
							direction: false,
							targets: true,
						},
						trial: {},
						grid: [],
						rulesOnly: true,
					},
					character: {
						image: "navy.png",
						top: 35,
						left: 0,
						width: 14,
					},
				},
				{
					background: superherosThemeBackgroundImage,
					prompt: {
						text: `For example...`,
					},
					task: {
						demo: true,
						highlight: {
							direction: false,
						},
						trial: {},
						grid: [],
					},
					character: {
						image: "navy.png",
						top: 44,
						left: 0,
						width: 14,
					},
				},
				{
					background: superherosThemeBackgroundImage,
					prompt: {
						text: `Watch out! The direction is important!`,
					},
					task: {
						demo: true,
						highlight: {
							direction: true,
						},
						trial: {},
						grid: [],
					},
					character: {
						image: "navy.png",
						top: 44,
						left: 0,
						width: 14,
					},
				},
				{
					background: superherosThemeBackgroundImage,
					prompt: {
						text:
							"Look at the parts box and the directions box because they can change",
					},
					task: {
						demo: true,
						highlight: {
							direction: true,
							targets: true,
						},
						trial: {},
						grid: [],
						second: true,
						defaultTutorialTargets: [
							"T_0_sharp.png",
							"T_90_sharp.png",
							"T_180_sharp.png",
							"T_270_sharp.png",
						],
						defaultDirection: {
							vertical: "bt",
							horizontal: "rl",
							lineByLine: "sd",
						},
					},
					character: {
						image: "blue.png",
						top: 44,
						left: 0,
						width: 12,
					},
				},
				{
					background: superherosThemeBackgroundImage,
					prompt: {
						text: `Are you ready to start?`,
						speech: true,
						top: 19,
						left: 6,
						width: 54,
						height: 30,
						reverse: true,
					},
					character: {
						image: "pink.png",
						top: 57,
						left: 12,
						width: 14,
					},
				},
			],
			text: {
				welcome: "We need your help!",
				tutorial: "Now, your turn...",
				missedShape: "You've missed one!",
				target: "Good!",
				targetCorrection: "Are you sure?",
				incorrectShape: "That's not a part!",
				wrongDirection: "Be careful, that's the wrong direction!",
				allTargets: "That's all of them, well done!",
				trialRelationships: "For example",
				trialTest: "Practice round!",
				withholdResponse: "You should ignore this one",
				firstTargetWrong:
					"That's a part, but it's not the first one!\nCheck the direction",
				randomAlternateTargetsIntro:
					"Here are your parts and direction",
			},
		},
		basic: {
			tutorialTrial: {
				nearDistractors: [
					"X_0_sharp.png",
					"T_0_sharp.png",
					"T_90_sharp.png",
					"T_180_sharp.png",
					"T_270_sharp.png",
					"I_0_sharp.png",
					"I_90_sharp.png",
					"O_0_sharp.png",
					"O_90_sharp.png",
				],
				farDistractors: [
					"X_0_round.png",
					"T_0_round.png",
					"T_90_round.png",
					"T_180_round.png",
					"T_270_round.png",
					"L_0_round.png",
					"L_90_round.png",
					"L_180_round.png",
					"L_270_round.png",
					"I_0_round.png",
					"I_90_round.png",
					"O_0_round.png",
					"O_90_round.png",
					"O_180_round.png",
				],
				numRows: 3,
				numNodesPerRow: 15,
				padding: 10,
				timeLimit: 40,
				showTimeLimit: true,
				showTimeLimitNextButton: false,
				numTrials: 3,
				nearDistractorProportion: 20,
				withholdResponse: false,
				withholdNResponse: 1,
				withholdResponseOnlyForIsTarget: false,
				adaptive: false,
				adaptiveRules: [],
				trialIndex: 0,
			},
			tutorialScreens: [
				{
					background: basicThemeBackgroundColor,
					prompt: {
						text: "",
					},
				},
				{
					background: basicThemeBackgroundColor,
					prompt: {
						text:
							"For this game, you will need to tap the target shapes",
					},
					placeholder: true,
				},
				{
					background: basicThemeBackgroundColor,
					prompt: {
						text:
							"You will need to tap the shapes shown in the Targets box",
					},
					task: {
						demo: true,
						highlight: {
							direction: false,
							targets: true,
						},
						trial: {},
						grid: [],
						rulesOnly: true,
					},
				},
				{
					background: basicThemeBackgroundColor,
					prompt: {
						text: "For example...",
					},
					task: {
						demo: true,
						highlight: {
							direction: false,
						},
						trial: {},
						grid: [],
					},
				},
				{
					background: basicThemeBackgroundColor,
					prompt: {
						text:
							"You need to search and tap the shapes in the direction in the direction box",
					},
					task: {
						demo: true,
						highlight: {
							direction: true,
						},
						trial: {},
						grid: [],
					},
				},
				{
					background: basicThemeBackgroundColor,
					prompt: {
						text:
							"Look at the targets box and the directions box because they can change",
					},
					task: {
						demo: true,
						highlight: {
							direction: true,
							targets: true,
						},
						trial: {},
						grid: [],
						second: true,
						defaultTutorialTargets: [
							"T_0_sharp.png",
							"T_90_sharp.png",
							"T_180_sharp.png",
							"T_270_sharp.png",
						],
						defaultDirection: {
							vertical: "bt",
							horizontal: "rl",
							lineByLine: "sd",
						},
					},
				},
				{
					background: basicThemeBackgroundColor,
					prompt: {
						text: "Are you ready to start?",
					},
				},
			],
			text: {
				welcome: "Welcome to the shape game",
				tutorial: "Now, your turn...",
				missedShape: "You've missed one",
				target: "Good!",
				targetCorrection: "Are you sure?",
				incorrectShape: "That's not a target",
				wrongDirection: "That's the wrong direction",
				allTargets: "That's all of them, well done",
				trialRelationships: "For example",
				trialTest: "Practice task: tap the correct shapes",
				withholdResponse: "You should ignore this one",
				firstTargetWrong:
					"That's not the first target, check the direction",
				randomAlternateTargetsIntro:
					"Here are your targets and direction",
			},
		},
	},
	exampleRelationships: {
		isBefore: [
			{
				shapes: [
					{
						target: true,
						relationship: false,
						selected: true,
					},
					{
						target: false,
						relationship: true,
						selected: false,
					},
				],
				correct: true,
			},
			{
				shapes: [
					{
						target: false,
						relationship: true,
						selected: false,
					},
					{
						target: true,
						relationship: false,
						selected: true,
					},
				],
				correct: false,
			},
			{
				shapes: [
					{
						target: true,
						relationship: false,
						selected: false,
					},
					{
						target: true,
						relationship: false,
						selected: true,
					},
					{
						target: false,
						relationship: true,
						selected: false,
					},
				],
				correct: true,
			},
		],
		isAfter: [
			{
				shapes: [
					{
						target: false,
						relationship: true,
						selected: false,
					},
					{
						target: true,
						relationship: false,
						selected: true,
					},
				],
				correct: true,
			},
			{
				shapes: [
					{
						target: true,
						relationship: false,
						selected: true,
					},
					{
						target: false,
						relationship: true,
						selected: false,
					},
				],
				correct: false,
			},
			{
				shapes: [
					{
						target: false,
						relationship: true,
						selected: false,
					},
					{
						target: true,
						relationship: false,
						selected: true,
					},
					{
						target: true,
						relationship: false,
						selected: false,
					},
				],
				correct: true,
			},
		],
		isNotBefore: [
			{
				shapes: [
					{
						target: true,
						relationship: false,
						selected: true,
					},
					{
						target: false,
						relationship: true,
						selected: false,
					},
				],
				correct: false,
			},
			{
				shapes: [
					{
						target: true,
						relationship: false,
						selected: true,
					},
					{
						target: false,
						relationship: false,
						selected: false,
					},
				],
				correct: true,
			},
			{
				shapes: [
					{
						target: true,
						relationship: false,
						selected: true,
					},
					{
						target: true,
						relationship: false,
						selected: false,
					},
					{
						target: false,
						relationship: true,
						selected: false,
					},
				],
				correct: true,
			},
		],
		isNotAfter: [
			{
				shapes: [
					{
						target: false,
						relationship: true,
						selected: false,
					},
					{
						target: true,
						relationship: false,
						selected: true,
					},
				],
				correct: false,
			},
			{
				shapes: [
					{
						target: false,
						relationship: false,
						selected: false,
					},
					{
						target: true,
						relationship: false,
						selected: true,
					},
				],
				correct: true,
			},
			{
				shapes: [
					{
						target: false,
						relationship: true,
						selected: false,
					},
					{
						target: true,
						relationship: false,
						selected: false,
					},
					{
						target: true,
						relationship: false,
						selected: true,
					},
				],
				correct: true,
			},
		],
	},
};
