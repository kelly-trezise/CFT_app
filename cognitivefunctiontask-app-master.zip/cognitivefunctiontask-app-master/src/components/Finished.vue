<template>
	<div id="finished" :class="{ fileDownload: fileDownload }">
		<div class="info">
			<div class="button-divider"></div>
			<div class="prompt" v-if="!fileDownload">
				<div class="text-wrapper">
					<div class="text">
						Finished! Well done.
					</div>
				</div>
			</div>
			<button
				class="button secondary"
				@click="exportToJSON()"
				v-if="!fileDownload"
				data-cy="next"
			>
				Next
			</button>
		</div>
		<div class="speech-prompt" v-if="!fileDownload">
			<div class="text-wrapper">
				<div class="text">
					It's as good as new!<br />
					Well done
				</div>
			</div>
		</div>
		<div class="characters" v-if="!fileDownload">
			<img src="img/superheroes/2characters.png" alt="superheroes" />
		</div>
		<div class="ship" v-if="fileDownload"></div>
		<div
			id="uploadOutcome"
			v-if="uploadOutcome.text !== ''"
			:class="{
				error: uploadOutcome.type === 'error',
				success: uploadOutcome.type === 'success',
				warning: uploadOutcome.type === 'warning',
			}"
		>
			<font-awesome-icon :icon="uploadOutcome.icon"></font-awesome-icon
			><span class="text">{{ uploadOutcome.text }}</span>
		</div>
		<button
			class="button secondary try-again"
			@click="uploadToDB()"
			v-if="uploadOutcome.type === 'error'"
		>
			Try Upload Again
		</button>
	</div>
</template>

<script>
	import axios from "axios";

	import TaskAnalyticsService from "@/services/TaskAnalyticsService.js";
	const taskAnalyticsService = new TaskAnalyticsService();

	export default {
		name: "Finished",
		data() {
			return {
				taskAnalytics: {},
				uploadOutcome: {
					text: "",
					type: "",
					icon: "",
				},
				fileDownload: false,
			};
		},
		methods: {
			exportToJSON() {
				this.fileDownload = true;

				setTimeout(() => {
					const data = JSON.stringify(this.taskAnalytics);
					const filename = this.createFileName(this.taskAnalytics);

					let file = new Blob([data], { type: "application/json" });
					if (window.navigator.msSaveOrOpenBlob)
						// IE10+
						window.navigator.msSaveOrOpenBlob(file, filename);
					else {
						// Others
						var a = document.createElement("a"),
							url = URL.createObjectURL(file);
						a.href = url;
						a.download = filename;
						document.body.appendChild(a);
						a.click();
						setTimeout(function() {
							document.body.removeChild(a);
							window.URL.revokeObjectURL(url);
						}, 1000);
					}
				}, 6000);
			},
			createFileName(analytics) {
				return (
					analytics.name.replace(/\s/g, "") +
					analytics.playerName.replace(/\s/g, "") +
					analytics.stats.startTime.substring(0, 10) +
					".json"
				);
			},
			uploadToDB() {
				axios
					.post(process.env.VUE_APP_API_URL + "/saveTest", {
						test: this.taskAnalytics,
					})
					.then((resp) => {
						if (resp.data.error) {
							this.uploadOutcome.type = "warning";
							this.uploadOutcome.icon = "exclamation-triangle";
							this.uploadOutcome.text = resp.data.error;
						} else {
							this.uploadOutcome.type = "success";
							this.uploadOutcome.icon = "check-circle";
							this.uploadOutcome.text = "Successful upload.";
						}
					})
					.catch(() => {
						this.uploadOutcome.type = "error";
						this.uploadOutcome.icon = "times-circle";
						this.uploadOutcome.text = "Device is offline.";
					});
			},
		},
		created() {
			this.taskAnalytics = taskAnalyticsService.getTaskAnalytics();
			this.uploadToDB();
		},
	};
</script>

<style lang="scss" scoped>
	.superheroes {
		#finished {
			background-image: url("/img/superheroes/backroom_ship.png");

			&.fileDownload {
				background-image: url("/img/superheroes/backspace.jpg");
			}

			.speech-prompt {
				top: 29vh;
				left: 44vw;
				width: 45vw;
				height: 30vh;
			}

			.prompt {
				display: none;
			}

			.characters {
				position: absolute;
				z-index: 1;
				top: 64vh;
				left: 62vw;
				width: 26vw;
				img {
					height: 100%;
					width: 100%;
				}
			}

			@keyframes liftoff {
				from {
					bottom: -100%;
					visibility: visible;
				}
				to {
					bottom: 200%;
					visibility: hidden;
				}
			}

			.ship {
				background-image: url("/img/superheroes/ship.png");
				background-size: contain;
				background-repeat: no-repeat;
				width: 34vw;
				height: 100%;
				position: absolute;
				animation-name: liftoff;
				animation-duration: 15s;
				visibility: hidden;
				left: 38vw;
			}

			button {
				position: absolute;
				right: 0;
			}
		}
	}

	.basic {
		#finished {
			background: #500066;
		}

		.broken-ship {
			display: none;
		}

		.characters {
			display: none;
		}

		.speech-prompt {
			display: none;
		}
	}

	#finished {
		padding-top: 5px;
		width: 100vw;
		background-size: cover;
		background-repeat: no-repeat;
		top: 0;
		position: absolute;
	}

	button {
		&.try-again {
			background: #00b0f0;
			bottom: 8vh;
		}
	}

	#uploadOutcome {
		color: white;
		padding: 10px;
		position: absolute;
		bottom: 0;
		width: 100%;

		.text {
			padding-left: 5px;
		}

		&.success {
			background: #00cc00;
		}

		&.warning {
			background: orange;
		}

		&.error {
			background: #e54d42;
		}
	}
</style>
