<template>
	<div id="about">
		<button class="button back" @click="$emit('back')">
			Back
		</button>
		<div class="content">
			<div class="description">
				<h1>Cognitive Function Task</h1>
				Cognitive Function Task by
				<a href="http://kellytrezise.com/" target="_blank"
					>Kelly Trezise</a
				>
				<br />
				Software Developed by
				<a href="https://simon-rose.co.uk/" target="_blank"
					>Simon Rose Software Development</a
				>
				<br />
				Funded by Centre for Mathematical Cognition, Loughborough
				University
				<br />
				<a href="https://simon-rose.co.uk/" target="_blank">
					<img
						src="img/simonrose_logo.png"
						alt="Simon Rose Software
					Development"
				/></a>
				<a href="https://www.lboro.ac.uk/research/cmc/" target="_blank">
					<img
						class="lboro"
						src="img/loughborough_logo.png"
						alt="Loughborough University"
					/>
				</a>
			</div>
			<div class="attribution">
				<h1>Asset Attribution</h1>
				<i
					>All the assets in the Cognitive Function Task are used
					under the Freepik license for personal and commercial
					purpose with attribution.</i
				>
				<ul>
					<li>
						<a
							href="https://www.freepik.com/free-vector/abstract-yellow-zoom-lines-empty-background_5071621.htm#query=abstract%20zoom%20yellow%20lines&position=14"
							target="_blank"
						>
							Abstract yellow background (designed by starline)
						</a>
					</li>
					<li>
						<a
							href="https://www.freepik.com/free-vector/comic-chat-bubbles-sticker-set_2390160.htm#page=1&query=comic%20chat%20bubbles%20sticker%20set&position=3"
							target="_blank"
						>
							Comic chat bubbles (designed by starline)
						</a>
					</li>
					<li>
						<a
							href="https://www.freepik.com/free-vector/house-attic-with-old-furniture-flying-dust_6361183.htm#page=1&query=house%20attic%20with%20old%20furniture&position=1"
							target="_blank"
						>
							House attic with old furniture (designed by upklyak
							/ Freepik)
						</a>
					</li>
					<li>
						<a
							href="https://www.freepik.com/free-vector/kids-wearing-colorful-costumes-different-superheroes-retro-set-isolated_4016511.htm#page=1&query=kids%20wearing%20colorful%20costumes&position=0"
							target="_blank"
						>
							Kids wearing colorful customes (designed by
							macrovector / Freepik)
						</a>
					</li>
					<li>
						<a
							href="https://www.freepik.com/free-vector/realistic-galaxy-background_4665545.htm#page=1&query=space&position=0"
							target="_blank"
							>Galaxy background (designed by pikisuperstar)</a
						>
					</li>
					<li>
						<a
							href="https://www.freepik.com/free-vector/lovely-spaceship-collection-with-flat-design_2857468.htm#page=1&query=lovely%20spaceship%20collection%20with%20flat%20design&position=1"
							target="_blank"
						>
							Spaceship (designed by Freepik)
						</a>
					</li>
				</ul>
			</div>
			<div class="privacy-policy">
				<h1>Privacy Policy</h1>
				<p>
					Personal information of participants will be collected for
					the core purpose of carrying out research examining
					cognitive, motor or perceptual functioning. The data may
					also be used to help understand how to improve and/or
					further develop the website. Personal information of
					researchers will be collected for the core purpose of
					improving and developing the website and examining how
					researchers use the website and/or examine cognitive, motor
					or perceptual functioning.
				</p>
				<p>
					Data will collected, stored and managed in accordance with
					the Loughborough University Data Management Policy and GDPR
					Principles. Personal data will be stored on Loughborough
					University servers, accessible only through password
					protection for approved researchers. Personal data is likely
					to be shared within the project team, primarily in a way
					that we can identify you as a participant. Information where
					you can be identified will be kept for a minimum amount of
					time and in accordance with the research objectives.
				</p>
				<p>
					The data from this project might be used for other, future
					research projects in addition to the project you are
					currently participating in. Those future projects can focus
					on any topic that might be unrelated to the goals of this
					study. We will give access to the data we are collecting to
					the general public via the Internet. Any personal
					information that would possibly identify you will be removed
					or changed before data are shared or results are made
					public.
				</p>
			</div>
			<div class="footer">
				&copy; Cognitive Function Task {{ currentYear }} <br />Build
				{{ version }}
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: "About",
		computed: {
			currentYear() {
				return new Date().getFullYear();
			},
			version() {
				return process.env.APPLICATION_VERSION;
			},
		},
	};
</script>

<style lang="scss" scoped>
	#about {
		width: 100vw;
		display: flex;
		flex-direction: column;
		overflow-y: scroll;

		.content {
			position: relative;
			text-align: left;
			border: $border;
			padding: 1vw;
			margin: 0.5vw;
			height: fit-content;
			background: lightgrey;

			.description {
				font-size: 2.5vw !important;
				margin-bottom: 20px;

				img {
					width: 20%;
					margin: 5px 10px 0 0;
				}

				a {
					font-size: 2.5vw !important;
					text-decoration: none;
				}
			}

			.attribution {
				font-size: 2.5vw !important;
				margin-bottom: 20px;

				i {
					font-size: 2vw !important;
				}
				ul {
					list-style-type: disc;
					padding-left: 3%;
				}
				ul li {
					font-size: 2.5vw !important;
				}
				ul li a {
					font-size: 2vw !important;
				}
			}

			.privacy-policy {
				p {
					font-size: 2vw !important;
				}
			}

			.footer {
				margin-top: 3vh;
				font-size: 2.5vw !important;
				text-align: center;

				a {
					font-size: 2.5vw !important;
					text-decoration: none;
				}
			}
		}

		.button {
			position: relative;
			left: 0;
			top: 0;
			width: fit-content;
			background: yellow;
		}
	}
</style>
