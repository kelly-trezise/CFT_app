<template>
	<div>
		<div id="trial-rules-intro" v-if="status === 0">
			<div class="character">
				<img src="img/superheroes/yellow.png" alt="Superhero" />
			</div>
			<div class="info">
				<div class="button-divider"></div>
				<div class="prompt">
					<div class="text-wrapper">
						<div class="text">
							{{ introText }}
						</div>
					</div>
				</div>
				<button
					class="button next"
					@click="acceptIntro()"
					data-cy="finish-trial-intro"
				>
					Ready
				</button>
			</div>
		</div>
		<TrialRuleTest
			v-if="currentTrialRuleTest && status === 1"
			:trial="currentTrialRuleTest"
			:theme="theme"
			:key="currentTrialRuleTestIndex"
			:index="currentTrialRuleTestIndex"
			:order="order"
			@next="nextTrialRule"
			@back="previousTrialRule"
		/>
		<div
			id="trial-rules-summary"
			v-if="!currentTrialRuleTest && status === 2"
		>
			<div class="info">
				<button class="button previous" @click="previousTrialRule()">
					Back
				</button>
				<div class="prompt">
					<div class="text-wrapper">
						<div class="text">
							{{ summaryText }}
						</div>
					</div>
				</div>
				<button
					class="button next"
					@click="acceptSummary()"
					data-cy="show-message"
				>
					Ready
				</button>
			</div>
			<div class="trials">
				<div
					class="trial"
					v-for="(trial, index) in trials"
					:key="trial._id"
					data-cy="trial-rule"
				>
					<TrialRule
						:trial="trial"
						:index="index"
						:summary="true"
						:displayIndex="trials.length > 1"
						:shapesTitle="
							theme === 'superheroes' ? 'Parts' : 'Targets'
						"
						:highlight="{}"
					/>
				</div>
			</div>
		</div>
		<div id="trial-message" v-if="status === 3">
			<div class="character">
				<img src="img/superheroes/blue.png" alt="Superhero" />
			</div>
			<div class="info">
				<button class="button previous" @click="showSummary()">
					Back
				</button>
				<div class="prompt fullscreen">
					<div class="text-wrapper">
						<div class="text" data-cy="message">
							{{ message }}
						</div>
					</div>
				</div>
				<button
					class="button next"
					@click="$emit('accept-rules')"
					data-cy="finish-trial-rules"
				>
					Next
				</button>
			</div>
		</div>
	</div>
</template>

<script>
	import lodash from "lodash";

	import TrialRule from "@/components/TrialRule";
	import TrialRuleTest from "@/components/TrialRuleTest";

	import TrialGeneratorService from "@/services/TrialGeneratorService";
	import TrialService from "@/services/TrialService";

	const trialGeneratorService = new TrialGeneratorService();
	const trialService = new TrialService();

	const INTRO = 0,
		RULES = 1,
		SUMMARY = 2,
		MESSAGE = 3;

	export default {
		name: "TrialRules",
		props: ["trials", "theme", "order", "postTutorialMessage"],
		components: {
			TrialRule,
			TrialRuleTest,
		},
		data() {
			return {
				publicPath: process.env.BASE_URL,
				trialRuleTests: [],
				currentTrialRuleTest: null,
				currentTrialRuleTestIndex: -1,
				lastSelectedShape: null,
				message: "",
				status: INTRO,
			};
		},
		methods: {
			nextTrialRule() {
				this.currentTrialRuleTestIndex++;
				if (
					this.currentTrialRuleTestIndex < this.trialRuleTests.length
				) {
					this.currentTrialRuleTest = this.trialRuleTests[
						this.currentTrialRuleTestIndex
					];
				} else {
					this.currentTrialRuleTest = null;
					this.status = SUMMARY;
				}
			},
			previousTrialRule() {
				this.currentTrialRuleTestIndex--;
				if (this.currentTrialRuleTestIndex >= 0) {
					this.currentTrialRuleTest = this.trialRuleTests[
						this.currentTrialRuleTestIndex
					];
					this.status = RULES;
				}
			},
			showSummary() {
				this.status = SUMMARY;
			},
			acceptIntro() {
				this.status = RULES;
			},
			acceptSummary() {
				if (this.order === "sequential") {
					if (this.trials[0].preTrialMessage.length > 0) {
						this.status = MESSAGE;
						this.message = this.trials[0].preTrialMessage;
					} else {
						this.$emit("accept-rules");
					}
				} else {
					if (this.postTutorialMessage.length > 0) {
						this.status = MESSAGE;
						this.message = this.postTutorialMessage;
					} else {
						this.$emit("accept-rules");
					}
				}
			},
			setupGrids() {
				this.trialRuleTests.forEach((trial) => {
					trial.numRows = trial.practiceTrialNumRows || 3;
					trial.numNodesPerRow =
						trial.practiceTrialNumNodesPerRow || 15;
					trial.grid = trialGeneratorService.generateGrid(trial);

					let grid = trial.grid.grid;

					grid = trialService.setLineByLineScanningDir(trial, grid);
					grid = trialService.setVerticalScanningDir(trial, grid);
					for (let row = 0; row < grid.length; row++) {
						grid[row] = trialService.setHorizontalScanningDir(
							trial,
							grid[row]
						);
					}

					trial.grid.grid = grid;
				});
			},
		},
		computed: {
			introText() {
				let partsOrTargets =
					this.theme === "superheroes" ? "Parts" : "Targets";
				return `Your ${partsOrTargets} and/or direction will change`;
			},
			summaryText() {
				if (this.order === "randomised" || this.order === "alternate") {
					let showRulesString = true;

					this.trials.forEach((trial) => {
						if (!trial.showTargetReminder) {
							showRulesString = false;
						}
					});

					if (showRulesString) {
						return "Your targets and directions will be shown at the start of each round";
					} else {
						return "Summary...";
					}
				} else {
					return "Summary...";
				}
			},
		},
		created() {
			this.trialRuleTests = lodash.cloneDeep(this.trials);

			// set artificially high target proportion for practice tasks
			this.trialRuleTests.forEach((trial) => {
				trial.targets.forEach((target) => {
					// ensure total target proportion is around 80%
					target.proportion = 80 / trial.targets.length;
				});
			});

			this.setupGrids();

			if (this.order === "sequential") {
				this.status = RULES;
			}

			this.nextTrialRule();
		},
	};
</script>

<style lang="scss" scoped>
	.superheroes {
		#trial-rules-summary,
		#trial-rules-intro,
		#trial-message {
			background-image: url("/img/superheroes/backroom.jpg");
		}

		.character {
			top: 0vh;
			left: 0vw;
			width: 17vw;
			z-index: 1;
			position: absolute;

			img {
				width: 100%;
				height: 100%;
			}
		}

		#trial-message {
			.character {
				top: 46vh;
				left: 1vw;
				width: 12vw;
				z-index: 1;
			}
		}
	}

	.basic {
		#trial-rules-summary,
		#trial-rules-intro,
		#trial-message {
			background: #500066;
		}

		.character {
			display: none;
		}
	}

	#trial-rules-summary,
	#trial-rules-intro,
	#trial-message {
		background-size: cover;
		background-repeat: no-repeat;
		display: flex;
		flex-direction: column;
	}

	.trials {
		display: flex;
		position: relative;
		width: 100vw;
		flex-direction: column;
		overflow-x: hidden;
		overflow-y: auto;

		.trial {
			display: flex;
			width: 100%;
			height: 100%;
			position: relative;
			margin-bottom: 0.5vw;
			flex-direction: column;
		}
	}

	.prompt,
	.options {
		margin-top: 0.5vw;
	}
</style>
