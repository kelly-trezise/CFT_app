<template>
	<div id="trials">
		<div class="rules-summary" v-if="status === 0">
			<TrialRule
				:trial="trial"
				:index="trial.trialIndex"
				:displayIndex="true"
				:shapesTitle="theme === 'superheroes' ? 'Parts' : 'Targets'"
				:highlight="{}"
			/>
			<button
				class="button next"
				@click="confirmRules"
				data-cy="confirm-rules"
			>
				Go
			</button>
		</div>
		<div class="grid-wrapper" :class="{ 'button-exists': showNextButton }">
			<TrialGrid
				:grid="grid"
				:padding="trial.padding"
				:practice="false"
				@select-shape="selectShape"
				class="trial"
				v-if="status === 1"
				:style="{ border: `${trial.backgroundColour} 1vw solid` }"
			/>
		</div>
		<button
			class="button"
			v-if="showNextButton && status === 1"
			@click="nextTrial()"
		>
			Done
		</button>
		<div class="message-wrapper" v-if="status === 2">
			<div
				class="message"
				data-cy="between-trial-gap"
				v-if="
					(showBetweenTrialMessage && !lastTrialInSet) ||
						(lastTrialInSet &&
							(!trial.postTrialMessage ||
								trial.postTrialMessage.length === 0))
				"
			>
				Next...
			</div>
			<div
				class="message"
				v-if="!lastTrial && lastTrialInSet && trial.postTrialMessage"
				data-cy="end-trial-set-gap"
			>
				{{ trial.postTrialMessage }}
			</div>
			<button
				class="button"
				data-cy="confirm-post-trial-message"
				v-if="!lastTrial && lastTrialInSet && trial.postTrialMessage"
				@click="$emit('next-trial')"
			>
				Next
			</button>
		</div>
	</div>
</template>

<script>
	import TrialRule from "@/components/TrialRule";
	import TrialGrid from "@/components/TrialGrid";

	import TrialGeneratorService from "@/services/TrialGeneratorService";
	import TaskAnalyticsService from "@/services/TaskAnalyticsService";
	import TrialService from "@/services/TrialService";

	const trialGeneratorService = new TrialGeneratorService();
	const taskAnalyticsService = new TaskAnalyticsService();
	const trialService = new TrialService();

	const RULES = 0,
		GRID = 1,
		MESSAGE = 2;

	export default {
		name: "Trial",
		props: [
			"trial",
			"lastTrial",
			"lastTrialInSet",
			"firstTrialInSet",
			"showBetweenTrialMessage",
			"theme",
		],
		components: {
			TrialRule,
			TrialGrid,
		},
		data() {
			return {
				publicPath: process.env.BASE_URL,
				grid: [],
				timeLimit: null,
				timeRemaining: null,
				showNextButton: true,
				timer: null,
				startTime: null,
				adaptiveAdjustmentPercentage: {
					numRows: 1,
					numNodesPerRow: 1,
					targetProportion: 1,
					timeLimit: 1,
				},
				previousTrialIndex: 0,
				timeBetweenTrials: 200,
				prompt: null,
				status: null,
				isCypress: window.Cypress ? true : false,
			};
		},
		methods: {
			confirmRules() {
				this.setupNewTrial();
			},
			selectShape(shape) {
				shape.selected = !shape.selected;

				taskAnalyticsService.shapeTouched(
					shape,
					this.timer ? this.timeRemaining : null
				);

				if (
					this.trial.nextTrialWhenAllTargetsSelected &&
					this.checkAllTargets()
				) {
					this.nextTrial();
				}
			},
			checkAllTargets() {
				let allTargets = true;
				let targets = this.getTargets();
				targets.forEach((target) => {
					if (!target.selected) {
						allTargets = false;
					}
				});
				return allTargets;
			},
			getTargets() {
				let targets = [];
				this.grid.forEach((row) => {
					row.forEach((shape) => {
						if (shape.isTarget && !shape.withholdResponse) {
							targets.push(shape);
						}
					});
				});
				return targets;
			},
			setupNewTrial() {
				this.status = GRID;

				if (this.trial.trialIndexInSet === 0) {
					// reset adaptive percentages
					this.adaptiveAdjustmentPercentage = {
						numRows: 1,
						numNodesPerRow: 1,
						targetProportion: 1,
						timeLimit: 1,
					};
				}

				// if trial has adaptive rules
				if (this.trial.adaptive) {
					// setup adaptive rules based on previous trials
					this.checkAdaptiveRules();

					// load previous adaptive rule adjustments if it's part of the same trial
					if (this.previousTrialIndex === this.trial.trialIndex) {
						this.setAdaptiveRuleAdjustments();
					}
				}

				this.previousTrialIndex = this.trial.trialIndex;
				let grid = [];
				if (this.trial.numRows > 1 || this.trial.numNodesPerRow > 1) {
					grid = trialGeneratorService.generateGrid(this.trial);
				} else {
					grid = trialGeneratorService.generateSingleShapeGrid(
						this.trial
					);
				}
				this.grid = grid.grid;

				this.grid = trialService.setLineByLineScanningDir(
					this.trial,
					this.grid
				);
				this.grid = trialService.setVerticalScanningDir(
					this.trial,
					this.grid
				);
				for (let row = 0; row < this.grid.length; row++) {
					this.grid[row] = trialService.setHorizontalScanningDir(
						this.trial,
						this.grid[row]
					);
				}

				taskAnalyticsService.newTrial(
					this.trial,
					this.grid,
					grid.totalShapeCount,
					grid.targetCount
				);
				this.timeLimit = this.trial.timeLimit || null;
				this.showNextButton = false;
				if (this.timeLimit) {
					this.setupTimeLimit();
				}
				if (this.trial.showNextButton) {
					this.showNextButton = true;
				}
			},
			nextTrial() {
				taskAnalyticsService.finishTrial(this.grid, this.timeRemaining);

				this.$Progress.finish();
				clearInterval(this.timer);

				if (!this.lastTrial) {
					if (
						(this.showBetweenTrialMessage &&
							!this.lastTrialInSet) ||
						(this.lastTrialInSet &&
							(!this.trial.postTrialMessage ||
								this.trial.postTrialMessage.length === 0))
					) {
						this.status = MESSAGE;
						setTimeout(() => {
							this.$emit("next-trial");
						}, this.trial.trialGap || 200);
					} else {
						if (this.trial.postTrialMessage.length > 0) {
							this.status = MESSAGE;
						} else {
							this.$emit("next-trial");
						}
					}
				} else {
					this.$emit("next-trial");
				}
			},
			setAdaptiveRuleAdjustments() {
				this.trial.numRows =
					this.trial.numRows *
					this.adaptiveAdjustmentPercentage.numRows;
				this.trial.numNodesPerRow =
					this.trial.numNodesPerRow *
					this.adaptiveAdjustmentPercentage.numNodesPerRow;
				this.trial.targets.forEach((target) => {
					target.proportion =
						target.proportion *
						this.adaptiveAdjustmentPercentage.targetProportion;
				});
				this.trial.timeLimit =
					this.trial.timeLimit *
					this.adaptiveAdjustmentPercentage.timeLimit;
			},
			checkAdaptiveRules() {
				const trialNumber = taskAnalyticsService.getTrialNumber();

				this.trial.adaptiveRules.forEach((rule) => {
					const previousTrialAnalytics = taskAnalyticsService.getPreviousNTrials(
						rule.afterNTrials
					);
					if (
						trialNumber === rule.afterNTrials ||
						(rule.continuous &&
							trialNumber > 0 &&
							trialNumber % rule.afterNTrials === 0)
					) {
						if (rule.averageStatistic === "selectedTargets") {
							let totalSelectedTargetsPerc = 0;
							previousTrialAnalytics.forEach((trial) => {
								totalSelectedTargetsPerc +=
									trial.stats.truePositive /
									trial.targetCount;
							});
							const selectedTargetsPerc =
								totalSelectedTargetsPerc /
								previousTrialAnalytics.length;
							this.checkAdaptiveRule(selectedTargetsPerc, rule);
						} else if (rule.averageStatistic === "timeRemaining") {
							let totalTimeRemainingPerc = 0;
							previousTrialAnalytics.forEach((trial) => {
								totalTimeRemainingPerc +=
									trial.stats.timeRemaining / trial.timeLimit;
							});
							const timeRemainingPercentage =
								totalTimeRemainingPerc /
								previousTrialAnalytics.length;
							this.checkAdaptiveRule(
								timeRemainingPercentage,
								rule
							);
						}
					}
				});
			},
			checkAdaptiveRule(percentage, rule) {
				if (rule.averageStatisticComparison === "lessThan") {
					if (percentage < rule.averageStatisticPercentage / 100) {
						this.updateTrial(rule);
					}
				} else if (rule.averageStatisticComparison === "greaterThan") {
					if (percentage > rule.averageStatisticPercentage / 100) {
						this.updateTrial(rule);
					}
				}
			},
			updateTrial(rule) {
				// use adaptive adjustment percentage to maintain adjustments for consecutive trials
				// and ensure that continuous checks keep adjusting
				const perc = rule.updateVariablePercentage / 100;
				if (rule.updateVariable === "targetProportion") {
					this.adaptiveAdjustmentPercentage.targetProportion =
						this.adaptiveAdjustmentPercentage.targetProportion +
						perc;
				} else if (rule.updateVariable === "gridSize") {
					this.adaptiveAdjustmentPercentage.numRows =
						this.adaptiveAdjustmentPercentage.numRows + perc;
					this.adaptiveAdjustmentPercentage.numNodesPerRow =
						this.adaptiveAdjustmentPercentage.numNodesPerRow + perc;
				} else if (rule.updateVariable === "timeLimit") {
					this.adaptiveAdjustmentPercentage.timeLimit =
						this.adaptiveAdjustmentPercentage.timeLimit + perc;
				}
			},
			setupTimeLimit() {
				this.startTime = Date.now();
				this.$Progress.start();
				this.timer = setInterval(() => {
					let timeElapsed = Date.now() - this.startTime;
					this.timeRemaining =
						(this.timeLimit * 1000 - timeElapsed) / 1000;
					const progressBarPercentage =
						(this.timeRemaining / this.timeLimit) * 100;
					this.$Progress.set(progressBarPercentage);
					if (this.timeRemaining < 0) {
						clearInterval(this.timer);
						this.nextTrial();
						this.timeRemaining = null;
						this.timeLimit = null;
					}
				}, 1);
				if (this.trial.showTimeLimitNextButton) {
					this.showNextButton = true;
				}
			},
		},
		created() {
			// some older trials don't have this property so default to true
			const showTargetReminder =
				this.trial.showTargetReminder === undefined
					? true
					: this.trial.showTargetReminder;
			if (this.firstTrialInSet && showTargetReminder) {
				this.status = RULES;
			} else {
				this.setupNewTrial();
			}
		},
		watch: {
			trial() {
				// trial changed
				if (this.trial) {
					const showTargetReminder =
						this.trial.showTargetReminder === undefined
							? true
							: this.trial.showTargetReminder;
					if (this.firstTrialInSet && showTargetReminder) {
						this.status = RULES;
					} else {
						this.setupNewTrial();
					}
				} else {
					taskAnalyticsService.finishTask();
					this.$emit("finish-task");
				}
			},
		},
	};
</script>

<style lang="scss" scoped>
	.superheroes {
		#trials {
			background-image: url("/img/superheroes/backroom.jpg");
		}
	}

	.basic {
		#trials {
			background: #500066;
		}
	}

	.message-wrapper {
		display: flex;
		align-items: center;
		justify-content: center;
		text-align: center;
		flex-direction: column;
		height: 100%;
		position: absolute;
		top: 0;
		left: 0;
		right: 0;

		.message {
			background: #fff;
			border: $border;
			padding: 1vw 2vw;
			margin-bottom: 10px;
		}

		.button {
			flex: none !important;
		}
	}

	.rules-summary {
		margin-top: 0.5vw;

		button {
			top: 0.5vw;
		}
	}

	#trials {
		width: 100vw;
		position: absolute;
		top: 0;
		background-size: cover;
		background-repeat: no-repeat;

		.time-limit {
			color: #fff;
		}

		.grid-wrapper {
			width: 100%;
			height: 98%;

			&.button-exists {
				height: 87%;
			}
		}

		.trial {
			margin: 10px auto;
			height: 99%;
			display: grid;
			grid-auto-rows: 1fr;
			min-height: 0;
			background: #fff;
			border: $border;
			flex: 20 0 auto;
		}

		button {
			position: absolute;
			bottom: 0.5vw;
			margin: 0 auto;
			left: 0;
			right: 0;
			width: 12vw;
			height: 10vh;

			&.next {
				position: relative;
			}
		}
	}
</style>
