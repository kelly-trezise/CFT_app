<template>
	<div class="grid">
		<div class="row" v-for="(row, i) in grid" :key="i">
			<div
				class="shape"
				data-cy="shape"
				v-for="(shape, j) in row"
				:key="j"
				v-touch:tap="tapHandler(shape)"
				v-touch:swipe="tapHandler(shape)"
				@click="clickHandler(shape)"
				:style="{
					margin: calcMargin(shape, padding),
					'flex-basis': calcBasis(shape, row),
				}"
				:class="{
					selected: shape.selected,
					target: shape.isTarget,
				}"
			>
				<div
					class="shape-img"
					:style="{
						'background-image': `url(${publicPath}img/shapes/${shape.file})`,
					}"
				></div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: "TrialGrid",
		props: ["grid", "padding", "practice"],
		data() {
			return {
				publicPath: process.env.BASE_URL,
			};
		},
		methods: {
			tapHandler(shape) {
				// https://www.npmjs.com/package/vue2-touch-events
				// hack to add extra params
				let that = this;
				return function() {
					that.$emit("select-shape", shape);
				};
			},
			clickHandler(shape) {
				if (window.Cypress) {
					this.$emit("select-shape", shape);
				}
			},
			getRowWidth(row) {
				let rowWidth = 0;
				row.forEach((shape) => {
					rowWidth += shape.width;
				});
				return rowWidth;
			},
			calcMargin(shape, padding) {
				let padVal = padding / 20;
				if (padVal > 5 && this.practice) {
					padVal = 5;
				}
				return padVal + "%";
			},
			calcBasis(shape, row) {
				return (shape.width / this.getRowWidth(row)) * 100 + "%";
			},
		},
	};
</script>

<style lang="scss" scoped>
	.grid {
		max-height: 100%;
		margin: auto;
		flex: 0 1 auto;
		height: 100%;
	}

	.shape-img {
		background-repeat: no-repeat;
		background-size: contain;
		background-position: center;
		height: 100%;
	}
</style>
