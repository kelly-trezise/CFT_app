<template>
	<div class="rules">
		<div class="or" v-if="summary && index > 0">
			Or
		</div>
		<div class="targets-wrapper">
			<div
				class="trial-number"
				v-if="displayIndex"
				:style="{ background: `${trial.backgroundColour}` }"
				data-cy="trial-index"
			>
				{{ index + 1 }}
			</div>
			<div
				class="targets"
				:class="{ highlight: highlight.targets }"
				data-cy="targets"
			>
				<div class="title">{{ shapesTitle }}</div>
				<div
					class="target"
					v-for="(target, index) in trial.targets"
					:key="target._id"
					:class="{ 'divider-padding': index > 0 }"
				>
					<div v-if="index > 0" class="divider">And</div>
					<div class="col">
						<div class="isNTarget">
							{{ convertAllOrEveryN(target, "isNTarget") }}
							<span v-if="target.isNTarget > 1">
								{{ target.isNTarget | ordinal }} of these
							</span>
						</div>
						<div class="shapes-summary">
							<div
								class="shape rule"
								v-for="(shape, i) in target.shapes"
								:key="i"
							>
								<img
									:src="`${publicPath}img/shapes/${shape}`"
								/>
							</div>
						</div>
					</div>
					<div class="col center" v-if="target.relationship">
						But only...
					</div>
					<div class="col" v-if="target.relationship">
						<div class="relationship">
							{{
								formatRelationshipString(
									target.relationshipRule
								)
							}}
							{{ target.relationshipRule.position }}
							<div class="shapes-summary">
								<div
									class="shape"
									v-for="(shape, i) in target.relationshipRule
										.shapes"
									:key="i"
								>
									<img
										:src="
											`${publicPath}img/shapes/${shape}`
										"
									/>
								</div>
							</div>
						</div>
					</div>
					<div
						class="col center"
						v-if="target.withholdResponseFor > 0"
					>
						But ignore...
					</div>
					<div class="col" v-if="target.withholdResponseFor > 0">
						<div class="withholdResponseFor">
							{{
								convertAllOrEveryN(
									target,
									"withholdResponseFor"
								)
							}}
							<span v-if="target.withholdResponseFor > 1">
								{{ target.withholdResponseFor | ordinal }}
							</span>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div
			class="direction"
			:class="{ highlight: highlight.direction }"
			data-cy="direction"
		>
			<div class="title">Direction</div>
			<div class="image">
				<img :src="`/img/${getConcatScanningDir(trial)}.gif`" />
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: "TrialRule",
		props: [
			"trial",
			"index",
			"summary",
			"displayIndex",
			"highlight",
			"shapesTitle",
		],
		data() {
			return {
				publicPath: process.env.BASE_URL,
			};
		},
		methods: {
			getConcatScanningDir(trial) {
				return `${trial.scanningDirectionHorizontal}${trial.scanningDirectionVertical}${trial.scanningDirectionLineByLine}`;
			},
			convertAllOrEveryN(target, option) {
				if (parseInt(target[option]) === 1) {
					if (option === "isNTarget") {
						return "All of these";
					} else {
						return "Them all";
					}
				} else {
					return "Every";
				}
			},
			formatRelationshipString(relationship) {
				let is = "if they are";
				if (relationship.not) {
					is = "if they are not";
				}

				return is;
			},
			prefix(index, relationship) {
				if (index !== 0) {
					if (!relationship.not) {
						return "or";
					} else {
						return "and";
					}
				} else {
					return "if";
				}
			},
		},
	};
</script>

<style lang="scss" scoped>
	.rules {
		width: 100vw;
		right: 0;
		padding: 0 0.5vw;
		overflow-y: auto;

		.or {
			position: relative;
			background: #000;
			color: #fff;
			border: $border;
			margin-right: 0.5vw;
			padding: 0.5vw;
			height: fit-content;
		}

		.trial-number {
			background: #000;
			color: #fff;
			padding: 1vw;
			margin-right: 0.5vw;
			border: $border;
			height: fit-content;
		}

		.targets-wrapper {
			display: flex;
		}

		.targets {
			flex: 0 1 auto;
			margin-right: 1vw;
			height: fit-content;

			.target {
				display: flex;
				align-items: center;
				justify-content: space-between;
				position: relative;

				.divider {
					width: 100%;
					height: 4vw;
					position: absolute;
					flex: none;
					top: 0;
					left: 1vw;
					text-align: left;
				}

				&.divider-padding {
					padding-top: 4vw;
				}

				.col {
					width: 100%;
					flex-grow: 1;

					&.center {
						flex-shrink: 2;
						justify-content: center;
					}
				}
			}

			.shapes-summary {
				max-width: 60vw;
				margin: auto;
				max-height: 9vh;
			}
		}

		.direction.highlight,
		.targets.highlight {
			border: red 0.5vw solid !important;
		}
	}
</style>
