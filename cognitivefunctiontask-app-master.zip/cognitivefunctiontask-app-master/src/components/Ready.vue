<template>
	<div id="ready">
		<div class="centered">
			<button class="button" @click="startCountdown" data-cy="ready">
				{{ buttonText }}
			</button>
		</div>
	</div>
</template>

<script>
	export default {
		name: "Ready",
		data() {
			return {
				buttonText: "Start",
				countdown: false,
				countdownInterval: null,
			};
		},
		methods: {
			startCountdown() {
				if (!this.countdown) {
					let secondsRemaining = 3;
					this.buttonText = secondsRemaining;
					this.countdownInterval = setInterval(() => {
						if (secondsRemaining > 1) {
							secondsRemaining--;
							this.buttonText = secondsRemaining;
						} else {
							clearInterval(this.countdownInterval);
							this.$emit("player-ready");
						}
					}, 1000);
				}
			},
		},
	};
</script>

<style lang="scss" scoped>
	.superheroes {
		#ready {
			background-image: url("/img/superheroes/backroom.jpg");
		}
	}

	.basic {
		#ready {
			background: #500066;
		}
	}

	#ready {
		width: 100vw;
		background-size: cover;
		background-repeat: no-repeat;
	}
</style>
