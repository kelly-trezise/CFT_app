<template>
	<div id="relationship-examples">
		<div class="target" v-for="target in targetList" :key="target._id">
			<div
				class="example"
				v-for="(example, i) in target.examples"
				:key="i"
			>
				<div class="example-wrapper">
					<div class="title">
						<font-awesome-icon
							icon="arrow-right"
						></font-awesome-icon>
					</div>
					<div
						class="shapes"
						:class="{ 'fit-height': example.correct === undefined }"
					>
						<div
							class="shape"
							v-for="(shape, j) in example.shapes"
							:key="j"
							:class="{
								correct: shape.correct,
								incorrect: shape.incorrect,
							}"
						>
							<img
								:src="`${publicPath}img/shapes/${shape.file}`"
								:class="{ selected: shape.selected }"
							/>
						</div>
					</div>
					<div
						v-if="example.correct !== undefined"
						class="is-correct"
						:class="{
							correct: example.correct,
							incorrect: !example.correct,
						}"
					>
						<font-awesome-icon
							:icon="example.icon"
						></font-awesome-icon>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import lodash from "lodash";

	import RelationshipExamplesService from "@/services/RelationshipExamplesService";
	const relationshipExamplesService = new RelationshipExamplesService();

	export default {
		name: "RelationshipExamples",
		props: ["targets"],
		data() {
			return {
				publicPath: process.env.BASE_URL,
				targetList: [],
			};
		},
		methods: {
			setupExamples() {
				this.targetList.forEach((target) => {
					target.examples = relationshipExamplesService.getExampleRelationships(
						target
					);
				});
			},
		},
		created() {
			this.targetList = lodash.cloneDeep(this.targets);
			this.setupExamples();
		},
	};
</script>

<style lang="scss" scoped>
	#relationship-examples {
		position: relative;
		display: flex;
		flex-direction: column;
		justify-content: space-around;
		width: 100vw;
		flex: 1 1 auto;

		.target {
			display: flex;
			flex-direction: row;
			justify-content: space-around;
			width: 100vw;
			height: 20vh;
			margin-top: 3vh;
		}

		.example {
			border: $border;
			background: #fff;
			width: fit-content;

			.example-wrapper {
				height: 100%;

				.title {
					background: #000;
					margin: -1px;
					height: 25%;
					padding: 0px 3vw;
					position: relative;

					svg {
						color: #fff !important;
						top: 0;
						position: absolute;
						height: 100%;
						left: 50%;
						margin-left: -5%;

						path {
							color: #fff !important;
						}
					}
				}

				.shapes {
					padding: 0.5vw;
					display: flex;
					flex-direction: row;
					justify-content: space-between;
					flex: 1;
					position: relative;
					height: 50%;
					min-width: 22vw;

					&.fit-height {
						height: 75%;
					}
				}

				.is-correct {
					height: 25%;
					position: relative;
					width: 100%;
					margin-top: 2px;

					&.correct {
						background: #00cc00;
					}

					&.incorrect {
						background: #e54d42;
					}

					svg {
						top: 0;
						position: absolute;
						height: 100%;
						left: 50%;
						margin-left: -5%;
					}
				}
			}
		}
	}
</style>
