<template>
	<div id="tutorial" :style="backgroundStyle">
		<div class="cover-background" v-if="showCoverBackground">
			<div class="centered">
				Loading...
			</div>
		</div>
		<!-- load all backgrounds -->
		<img
			class="background"
			src="/img/superheroes/back.jpg"
			v-show="currentTutorialScreen.background.includes('back.jpg')"
		/>
		<img
			class="background"
			src="/img/superheroes/backroom.jpg"
			v-show="currentTutorialScreen.background.includes('backroom.jpg')"
		/>
		<img
			class="background"
			src="/img/superheroes/backroom_brokenship.jpg"
			v-show="
				currentTutorialScreen.background.includes(
					'backroom_brokenship.jpg'
				)
			"
		/>
		<img
			class="background"
			src="/img/superheroes/backroom_ship.png"
			v-show="
				currentTutorialScreen.background.includes('backroom_ship.png')
			"
		/>
		<div
			class="end-tutorial-options"
			v-if="currentTutorialScreenIndex >= tutorialScreens.length - 1"
		>
			<button class="button repeat" @click="repeatTutorial()">
				Repeat tutorial
			</button>
			<button
				class="button next"
				@click="nextTutorialScreen()"
				data-cy="to-trial-rules"
			>
				I'm ready!
			</button>
		</div>
		<div class="info">
			<button
				class="button previous"
				@click="previousTutorialScreen()"
				v-if="
					currentTutorialScreenIndex > 0 &&
						currentTutorialScreenIndex < tutorialScreens.length - 1
				"
				data-cy="tutorial-previous"
			>
				Back
			</button>
			<div class="button-divider" v-else></div>
			<div
				:style="{
					top:
						currentTutorialScreen.prompt.speech &&
						currentTutorialScreen.prompt.top + 'vh',
					left:
						currentTutorialScreen.prompt.speech &&
						currentTutorialScreen.prompt.left + 'vw',
					width:
						currentTutorialScreen.prompt.speech &&
						currentTutorialScreen.prompt.width + 'vw',
					height:
						currentTutorialScreen.prompt.speech &&
						currentTutorialScreen.prompt.height + 'vh',
				}"
				:class="{
					'speech-prompt': currentTutorialScreen.prompt.speech,
					prompt: !currentTutorialScreen.prompt.speech,
					reverse: currentTutorialScreen.prompt.reverse,
					fullscreen: currentTutorialScreen.fullscreen,
				}"
				data-cy="prompt"
				v-show="!showCoverBackground"
			>
				<div class="text-wrapper">
					<div
						class="text"
						:class="{
							reverse: currentTutorialScreen.prompt.reverse,
						}"
					>
						{{ currentTutorialScreen.prompt.text }}
					</div>
				</div>
			</div>
			<button
				class="button next"
				@click="nextTutorialScreen()"
				v-if="
					showNextButton &&
						currentTutorialScreenIndex < tutorialScreens.length - 1
				"
				data-cy="tutorial-next"
				:class="{
					absolute: currentTutorialScreen.prompt.speech,
				}"
			>
				Next
			</button>
			<div class="button-divider" v-else></div>
		</div>
		<!-- load all images and show/hide them instead of changing src -->
		<div v-if="task.theme === 'superheroes'" class="character-wrapper">
			<div
				class="character"
				v-for="(screen, index) in tutorialScreens"
				v-show="
					index === currentTutorialScreenIndex && !showCoverBackground
				"
				:key="index"
				:style="{
					top: screen.character.top + 'vh',
					left: screen.character.left + 'vw',
					width: screen.character.width + 'vw',
				}"
				:class="{ relative: screen.character.relative }"
			>
				<img
					v-if="screen.character"
					:src="'img/superheroes/' + screen.character.image"
					alt="Superhero"
				/>
			</div>
		</div>
		<div class="grid-wrapper" v-if="currentTutorialScreen.placeholder">
			<div class="placeholder-grid">
				<div class="row" v-for="(row, index) in shapes" :key="index">
					<div
						class="shape"
						v-for="shape in row"
						:key="shape.file"
						:style="{
							margin: 0.5 + '%',
							'flex-basis':
								(shape.width / getRowWidth(row)) * 100 + '%',
						}"
					>
						<img :src="`${publicPath}img/shapes/${shape.file}`" />
					</div>
				</div>
			</div>
		</div>
		<div class="task" v-if="currentTutorialScreen.task">
			<TrialRule
				:trial="currentTutorialScreen.task.trial"
				:highlight="highlight"
				:shapesTitle="
					task.theme === 'superheroes' ? 'Parts' : 'Targets'
				"
			/>
		</div>
		<div
			class="grid-wrapper"
			v-if="
				currentTutorialScreen.task &&
					!currentTutorialScreen.task.rulesOnly
			"
		>
			<div class="grid">
				<div
					class="row"
					v-for="(row, i) in currentTutorialScreen.task.grid"
					:key="i"
				>
					<div
						class="shape"
						data-cy="shape"
						v-for="(shape, j) in row"
						:key="j"
						:style="{
							margin: 0.5 + '%',
							'flex-basis':
								(shape.width / getRowWidth(row)) * 100 + '%',
						}"
						:class="{
							correct: shape.correct,
							incorrect: shape.incorrect,
						}"
					>
						<img
							:src="`${publicPath}img/shapes/${shape.file}`"
							:class="{
								target: shape.isTarget,
								selected: shape.selected,
							}"
						/>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import lodash from "lodash";

	import { config } from "@/data/Config";
	import { shapes } from "@/data/Shapes";

	import TrialRule from "@/components/TrialRule";

	import TrialGeneratorService from "@/services/TrialGeneratorService";
	import TrialService from "@/services/TrialService";

	const trialGeneratorService = new TrialGeneratorService();
	const trialService = new TrialService();

	export default {
		name: "Tutorial",
		props: ["player", "task"],
		components: {
			TrialRule,
		},
		data() {
			return {
				publicPath: process.env.BASE_URL,
				tutorialScreens: [],
				currentTutorialScreenIndex: 0,
				currentTutorialScreen: null,
				tutorialDemoGridInterval: null,
				showNextButton: false,
				showCoverBackground: false,
				tutorialDemoGridIntervalSpeed: 100,
				lastSelectedShape: null,
				highlight: {
					direction: false,
					targets: false,
				},
			};
		},
		methods: {
			nextTutorialScreen() {
				if (
					this.currentTutorialScreenIndex <
					this.tutorialScreens.length - 1
				) {
					this.currentTutorialScreenIndex++;
					this.currentTutorialScreen = this.tutorialScreens[
						this.currentTutorialScreenIndex
					];

					this.showNextButton = false;

					if (this.currentTutorialScreen.task) {
						this.highlight = this.currentTutorialScreen.task.highlight;

						if (this.currentTutorialScreen.task.demo) {
							if (this.currentTutorialScreen.task.rulesOnly) {
								// next button timeout if not cypress test
								if (
									window.Cypress ||
									process.env.NODE_ENV === "development"
								) {
									this.showNextButton = true;
								} else {
									setTimeout(() => {
										this.showNextButton = true;
									}, 1000);
								}
							} else {
								this.showDemoShapeSelect();
							}
						} else {
							this.showNextButton = false;
							clearInterval(this.tutorialDemoGridInterval);
						}
					} else {
						clearInterval(this.tutorialDemoGridInterval);

						// next button timeout if not cypress test
						if (
							window.Cypress ||
							process.env.NODE_ENV === "development"
						) {
							this.showNextButton = true;
						} else {
							setTimeout(() => {
								this.showNextButton = true;
							}, 1000);
						}
					}
				} else {
					this.$emit("finish-tutorial");
				}
			},
			showDemoShapeSelect() {
				clearInterval(this.tutorialDemoGridInterval);
				let currentShapeIndex = 0;
				this.resetShapes();
				let shapes = this.getShapes();
				shapes = lodash.orderBy(shapes, "overallPosition");
				this.tutorialDemoGridInterval = setInterval(() => {
					if (shapes[currentShapeIndex]) {
						if (shapes[currentShapeIndex].isTarget) {
							shapes[currentShapeIndex].correct = true;
						} else {
							shapes[currentShapeIndex].incorrect = true;
						}
					}

					if (currentShapeIndex < shapes.length) {
						currentShapeIndex++;
					} else {
						if (this.currentTutorialScreen.task) {
							// cycle again if not cypress test
							if (!window.Cypress) {
								this.showDemoShapeSelect();
							}
							this.showNextButton = true;
						}
					}
				}, this.tutorialDemoGridIntervalSpeed);
			},
			previousTutorialScreen() {
				if (
					this.currentTutorialScreen.task &&
					!this.currentTutorialScreen.task.demo
				) {
					this.loadTutorialTask();
				}

				this.currentTutorialScreenIndex--;
				this.currentTutorialScreen = this.tutorialScreens[
					this.currentTutorialScreenIndex
				];

				this.showNextButton = true;
				clearInterval(this.tutorialDemoGridInterval);

				if (this.currentTutorialScreen.task) {
					this.highlight = this.currentTutorialScreen.task.highlight;
				}

				if (
					this.currentTutorialScreen.task &&
					this.currentTutorialScreen.task.demo
				) {
					this.loadDemoTutorials();
					this.showDemoShapeSelect();
					this.showNextButton = false;
				}
			},
			getTargets() {
				let targets = [];
				this.currentTutorialScreen.task.grid.forEach((row) => {
					row.forEach((shape) => {
						if (shape.isTarget) {
							targets.push(shape);
						}
					});
				});
				return targets;
			},
			getShapes() {
				let shapes = [];
				this.currentTutorialScreen.task.grid.forEach((row) => {
					row.forEach((shape) => {
						// add attributes for selection classes
						shapes.push(shape);
					});
				});
				return shapes;
			},
			resetShapes() {
				this.currentTutorialScreen.task.grid.forEach((row) => {
					row.forEach((shape) => {
						// add attributes for selection classes
						shape.correct = false;
						shape.incorrect = false;
					});
				});
			},
			checkAllTargets() {
				let allTargets = true;
				let targets = this.getTargets();
				targets.forEach((target) => {
					if (!target.selected) {
						allTargets = false;
					}
				});
				return allTargets;
			},
			repeatTutorial() {
				// reload tutorial component
				this.loadDemoTutorials();
				this.loadTutorialTask();

				clearInterval(this.tutorialDemoGridInterval);

				this.currentTutorialScreenIndex = 0;
				this.currentTutorialScreen = this.tutorialScreens[
					this.currentTutorialScreenIndex
				];
			},
			loadDemoTutorials() {
				let demoTrialScreens = this.tutorialScreens.filter(
					(s) => s.task && s.task.demo
				);
				if (demoTrialScreens.length > 0) {
					// setup trial from task config
					demoTrialScreens.forEach((screen) => {
						this.loadTrialAndGrid(screen);
					});
				}
			},
			loadTutorialTask() {
				let trialScreen = this.tutorialScreens.find(
					(s) => s.task && !s.task.demo
				);
				if (trialScreen) {
					this.loadTrialAndGrid(trialScreen);
					trialScreen.prompt.text =
						config.themes[this.task.theme].text.tutorial;
				}
			},
			loadTrialAndGrid(screen) {
				screen.task.trial = {
					targets: [
						{
							shapes:
								this.task.firstDemoTargets ||
								config.defaults.tutorialTargets,
							isNTarget: 1,
							proportion: this.task.tutorialTargetProportion,
							relationship: false,
							relationshipRule: {},
						},
					],
					scanningDirectionVertical:
						this.task.firstDemoScanningDirectionVertical ||
						config.defaults.tutorialDirection.vertical,
					scanningDirectionHorizontal:
						this.task.firstDemoScanningDirectionHorizontal ||
						config.defaults.tutorialDirection.horizontal,
					scanningDirectionLineByLine:
						this.task.firstDemoScanningDirectionLineByLine ||
						config.defaults.tutorialDirection.lineByLine,
				};

				if (screen.task.second) {
					screen.task.trial.targets = [
						{
							shapes:
								this.task.secondTutorialTargets ||
								screen.task.defaultTutorialTargets,
							isNTarget: 1,
							proportion: this.task.tutorialTargetProportion,
							relationship: false,
							relationshipRule: {},
						},
					];

					screen.task.trial.scanningDirectionVertical =
						this.task.secondDemoScanningDirectionVertical ||
						screen.task.defaultDirection.vertical;
					screen.task.trial.scanningDirectionHorizontal =
						this.task.secondDemoScanningDirectionHorizontal ||
						screen.task.defaultDirection.horizontal;
					screen.task.trial.scanningDirectionLineByLine =
						this.task.secondDemoScanningDirectionLineByLine ||
						screen.task.defaultDirection.lineByLine;
				}

				screen.task.trial = Object.assign(
					screen.task.trial,
					config.themes[this.task.theme].tutorialTrial
				);

				screen.task.grid = trialGeneratorService.generateGrid(
					screen.task.trial
				).grid;

				screen.task.grid = trialService.setLineByLineScanningDir(
					screen.task.trial,
					screen.task.grid
				);
				screen.task.grid = trialService.setVerticalScanningDir(
					screen.task.trial,
					screen.task.grid
				);
				for (let row = 0; row < screen.task.grid.length; row++) {
					screen.task.grid[
						row
					] = trialService.setHorizontalScanningDir(
						screen.task.trial,
						screen.task.grid[row]
					);
				}
			},
			firstPrompt() {
				return `Hi ${this.player.codeName}!\n${
					config.themes[this.task.theme].text.welcome
				}`;
			},
			getRowWidth(row) {
				let rowWidth = 0;
				row.forEach((shape) => {
					rowWidth += shape.width;
				});
				return rowWidth;
			},
		},
		computed: {
			backgroundStyle() {
				let backgroundStyle = {};
				if (this.task.theme === "basic") {
					backgroundStyle.background = this.currentTutorialScreen.background;
				}
				return backgroundStyle;
			},
			shapes() {
				let rows = [];
				let row = [];

				shapes.forEach((shape, index) => {
					row.push(shape);

					if ((index + 1) % 7 === 0) {
						rows.push(row);
						row = [];
					}
				});

				return rows;
			},
		},
		created() {
			clearInterval(this.tutorialDemoGridInterval);
			this.tutorialScreens =
				config.themes[this.task.theme].tutorialScreens;
			this.tutorialScreens[0].prompt.text = this.firstPrompt();
			this.loadDemoTutorials();
			this.loadTutorialTask();

			this.currentTutorialScreen = this.tutorialScreens[
				this.currentTutorialScreenIndex
			];

			if (this.task.theme === "superheroes") {
				// allow browser to load all images/backgrounds
				this.showCoverBackground = true;

				setTimeout(() => {
					this.showCoverBackground = false;

					// next button timeout if not cypress test
					if (!window.Cypress) {
						this.showNextButton = false;
						setTimeout(() => {
							this.showNextButton = true;
						}, 1000);
					} else {
						this.showNextButton = true;
						// speed up animations for cypress tests
						this.tutorialDemoGridIntervalSpeed = 10;
					}
				}, 3000);
			} else {
				// next button timeout if not cypress test
				if (!window.Cypress) {
					this.showNextButton = false;
					setTimeout(() => {
						this.showNextButton = true;
					}, 1000);
				} else {
					this.showNextButton = true;
					// speed up animations for cypress tests
					this.tutorialDemoGridIntervalSpeed = 10;
				}
			}

			this.tutorialDemoGridIntervalSpeed = this.task.tutorialDemoCycleSpeed;
		},
		destroyed() {
			clearInterval(this.tutorialDemoGridInterval);
		},
	};
</script>

<style lang="scss" scoped>
	.superheroes {
		#tutorial {
			background: #000;
		}

		.character-wrapper {
			position: absolute;
			height: 100%;
			width: 100%;
		}

		.character {
			position: absolute;
			z-index: 1;

			img {
				height: 100%;
				width: 100%;
			}

			&.relative {
				flex: 1 0 auto;
				position: relative;
				overflow: hidden;
				height: 100%;

				img {
					height: 95%;
					width: auto;
				}
			}
		}

		.placeholder-grid {
			margin-left: 30vw;
			height: 100%;
		}

		.cover-background {
			background-image: url("/img/superheroes/back.jpg");
			background-size: cover;
			background-repeat: no-repeat;
			z-index: 100;
			position: absolute;
			width: 100%;
			height: 100%;
		}

		.background {
			z-index: 0;
			position: absolute;
			height: 100%;
			width: 100%;
			object-fit: cover;
		}
	}

	.basic {
		.placeholder-grid {
			margin: auto;
			height: 100%;
		}
	}

	#tutorial {
		text-align: center;
		background-size: cover;
		background-repeat: no-repeat;
		display: flex;
		flex-direction: column;

		.end-tutorial-options {
			position: absolute;
			bottom: 0;
			left: 50vw;
			display: flex;
			justify-content: space-between;
			flex-direction: column;
			top: 76%;
			left: 50%;
			transform: translate(-50%, -50%);
			z-index: 2;

			button {
				&.repeat {
					background: #00b0f0;
				}
			}
		}

		.grid-wrapper {
			position: relative;
			width: 100vw;
			height: 100%;
			padding: 0.5vw;
			overflow: hidden;

			.grid {
				max-height: 100%;
				margin: auto;
				flex: 0 1 auto;
			}
		}

		.placeholder-grid {
			position: relative;
			background: #fff;
			border: $border;
			display: grid;
			grid-auto-rows: 1fr;
			min-height: 0;
			justify-content: space-between;
			max-width: 70vw;

			.row {
				display: flex;
				flex-direction: row;
				min-height: 0;
				justify-content: space-between;
				flex: 1;
			}

			.shape {
				flex: 1 1 auto;

				img {
					height: 100%;
					width: 100%;
					object-fit: contain;
					padding: 10px;
					cursor: default;

					&.selected {
						filter: brightness(50%);
					}
				}
			}
		}

		.info {
			button.absolute {
				right: 0;
				position: absolute;
			}
		}
	}
</style>
