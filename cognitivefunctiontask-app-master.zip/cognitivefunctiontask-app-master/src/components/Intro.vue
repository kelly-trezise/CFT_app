<template>
	<div id="intro">
		<button class="button about" @click="$emit('about')">
			About
		</button>
		<div class="form centered">
			<div
				class="details"
				v-if="task && task.trials && task.trials.length > 0"
			>
				<label for="code-name">Code name</label>
				<input
					type="text"
					name="code-name"
					v-model="codeName"
					autocomplete="off"
					:class="{ error: validation.codeNameError }"
				/>
				<label for="dob">Date of birth</label>
				<input
					type="text"
					placeholder="DD/MM/YYYY"
					name="dob"
					autocomplete="off"
					v-model="dateOfBirth"
					@keyup="insertSlashes"
					:class="{ error: validation.dateOfBirthError }"
				/>
				<button class="button" @click="startTask" data-cy="start-task">
					Start
				</button>
			</div>
			<div class="no-task" v-show="!task.trials" data-cy="task-not-found">
				Task not found.
			</div>
			<div
				class="no-trials"
				v-if="task && task.trials && task.trials.length === 0"
			>
				This task contains no trials.
			</div>
		</div>
	</div>
</template>

<script>
	import moment from "moment";

	export default {
		name: "Intro",
		props: ["task"],
		data() {
			return {
				codeName: "",
				dateOfBirth: "",
				validation: {
					codeNameError: false,
					dateOfBirthError: false,
				},
			};
		},
		methods: {
			startTask() {
				let isValid = true;

				if (this.codeName === "") {
					this.validation.codeNameError = true;
					isValid = false;
				}

				if (this.dateOfBirth === "") {
					this.validation.dateOfBirthError = true;
					isValid = false;
				}

				// validate format
				if (!moment(this.dateOfBirth, "D/M/YYYY").isValid()) {
					this.validation.dateOfBirthError = true;
					isValid = false;
				}

				if (isValid) {
					this.$emit(
						"start-tutorial",
						this.codeName,
						this.dateOfBirth
					);
				}
			},
			insertSlashes(ev) {
				if (ev.which !== 8) {
					var numChars = this.dateOfBirth.length;
					if (numChars === 2 || numChars === 5) {
						this.dateOfBirth += "/";
					}
				}
			},
		},
		watch: {
			codeName() {
				if (this.codeName !== "") {
					this.validation.codeNameError = false;
				}
			},
			dateOfBirth() {
				if (
					this.dateOfBirth !== "" &&
					moment(this.dateOfBirth, "D/M/YYYY").isValid()
				) {
					this.validation.dateOfBirthError = false;
				}
			},
		},
		mounted() {
			if (!window.Cypress && process.env.NODE_ENV === "development") {
				this.codeName = "Simon";
				this.dateOfBirth = "01/01/2000";
			}
		},
	};
</script>

<style lang="scss" scoped>
	#intro {
		width: 100vw;
		display: flex;

		.form {
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			width: 50vw;
		}

		input {
			text-align: center;

			&.error {
				border: red 0.5vw solid;
			}
		}

		.about {
			position: absolute;
			left: 0;
			top: 0;
			background: #fff;
		}

		.no-trials {
			color: #000;
			border: $border;
			background: #fff;
		}

		.button {
			position: relative;
			top: 0;
			left: 0;
		}
	}
</style>
