<template>
	<div id="trial-rules-test">
		<div id="intro" v-if="status === 0">
			<div class="character">
				<img src="img/superheroes/yellow.png" alt="Superhero" />
			</div>
			<div class="info">
				<button
					class="button previous"
					@click="$emit('back')"
					v-if="index > 0"
				>
					Back
				</button>
				<div class="button-divider" v-else></div>
				<div class="prompt">
					<div class="text-wrapper">
						<div class="text">
							{{ introText }}
						</div>
					</div>
				</div>
				<button
					class="button next"
					@click="showRelationships(0)"
					data-cy="to-relationships"
				>
					Next
				</button>
			</div>
			<TrialRule
				:trial="trial"
				:index="index"
				:displayIndex="order !== 'sequential'"
				:shapesTitle="theme === 'superheroes' ? 'Parts' : 'Targets'"
				:highlight="{}"
			/>
		</div>
		<div id="relationships" v-if="status === 1">
			<div class="character">
				<img src="img/superheroes/yellow.png" alt="Superhero" />
			</div>
			<div class="info">
				<button class="button previous" @click="showIntro()">
					Back
				</button>
				<div class="prompt">
					<div class="text-wrapper">
						<div class="text">
							{{ prompt }}
						</div>
					</div>
				</div>
				<button
					class="button next"
					@click="showTest()"
					data-cy="to-task"
				>
					Next
				</button>
			</div>
			<div class="examples">
				<TrialRule
					:trial="trial"
					:index="index"
					:displayIndex="order !== 'sequential'"
					:shapesTitle="theme === 'superheroes' ? 'Parts' : 'Targets'"
					:highlight="{}"
				/>
				<RelationshipExamples :targets="trial.targets" />
			</div>
		</div>
		<div id="test" v-if="status === 2">
			<div class="character">
				<img src="img/superheroes/blue.png" alt="Superhero" />
			</div>
			<div class="info">
				<button class="button previous" @click="showRelationships(2)">
					Back
				</button>
				<div class="prompt">
					<div class="text-wrapper">
						<div
							class="text"
							:class="{
								incorrect: this.isIncorrect,
							}"
						>
							{{ prompt }}
						</div>
					</div>
				</div>
				<button
					class="button next"
					@click="$emit('next')"
					v-if="showNextButton"
					data-cy="next-rule"
				>
					Next
				</button>
				<div class="button-divider" v-else></div>
			</div>
			<TrialRule
				:trial="trial"
				:index="index"
				:displayIndex="order !== 'sequential'"
				:shapesTitle="theme === 'superheroes' ? 'Parts' : 'Targets'"
				:highlight="{}"
			/>
			<div class="grid-wrapper">
				<TrialGrid
					:grid="grid"
					:padding="trial.padding"
					:practice="true"
					@select-shape="selectShape"
				/>
			</div>
		</div>
	</div>
</template>

<script>
	import lodash from "lodash";

	import { config } from "@/data/Config";

	import TrialRule from "@/components/TrialRule";
	import RelationshipExamples from "@/components/RelationshipExamples";
	import TrialGrid from "@/components/TrialGrid";

	const INTRO = 0,
		RELATIONSHIPS = 1,
		TEST = 2;

	export default {
		name: "TrialRuleTest",
		props: ["trial", "theme", "index", "order"],
		components: {
			TrialRule,
			RelationshipExamples,
			TrialGrid,
		},
		data() {
			return {
				publicPath: process.env.BASE_URL,
				grid: [],
				showNextButton: false,
				hasRelationships: false,
				hasWithholdResponse: false,
				hasIsNTarget: false,
				status: INTRO,
				introText: "",
				prompt: "",
				isIncorrect: false,
			};
		},
		methods: {
			showIntro() {
				this.status = INTRO;
			},
			showRelationships(from) {
				this.status = RELATIONSHIPS;

				if (
					this.hasRelationships ||
					this.hasWithholdResponse ||
					this.hasIsNTarget
				) {
					this.prompt =
						config.themes[this.theme].text.trialRelationships;
				} else {
					if (from === INTRO) {
						this.showTest();
					} else if (from === TEST) {
						this.showIntro();
					}
				}
			},
			showTest() {
				this.status = TEST;
				this.prompt = config.themes[this.theme].text.trialTest;

				this.grid = lodash.cloneDeep(this.trial.grid.grid);

				this.trial.targets.forEach((target) => {
					if (target.relationship) {
						this.hasRelationships = true;
					}
					if (target.withholdResponseFor > 0) {
						this.hasWithholdResponse = true;
					}
					if (target.isNTarget > 1) {
						this.hasIsNTarget = true;
					}
				});

				this.lastSelectedShape = null;

				// for testing
				if (!window.Cypress && process.env.NODE_ENV === "development") {
					// this.selectAllTargets();
					this.showNextButton = true;
				}
			},
			selectShape(shape) {
				this.isIncorrect = false;

				// check if target shape
				if (shape.isTarget) {
					// check if missed shape
					const missedShapes = this.getTargets().filter(
						(s) =>
							!s.selected &&
							!s.withholdResponse &&
							s.overallPosition < shape.overallPosition
					);
					if (missedShapes.length > 0) {
						// first target not selected
						const selectedShapes = this.getTargets().filter(
							(s) => s.selected
						);
						if (selectedShapes.length === 0) {
							this.prompt =
								config.themes[this.theme].text.firstTargetWrong;
						} else {
							this.prompt =
								config.themes[this.theme].text.missedShape;
						}
						this.isIncorrect = true;
					} else {
						if (shape.withholdResponse) {
							this.prompt =
								config.themes[this.theme].text.withholdResponse;
							this.isIncorrect = true;
						} else {
							if (!shape.selected) {
								this.prompt =
									config.themes[this.theme].text.target;
							} else {
								this.prompt =
									config.themes[
										this.theme
									].text.targetCorrection;
							}
						}
					}
				} else {
					this.prompt = config.themes[this.theme].text.incorrectShape;
					this.isIncorrect = true;
				}

				// check if wrong direction
				// but only show the feedback if the current shape is not a target and the previously
				// tapped shape was - otherwise this overwrites more important feedback
				if (this.lastSelectedShape) {
					if (
						this.lastSelectedShape.overallPosition >
							shape.overallPosition &&
						!shape.isTarget &&
						this.lastSelectedShape.isTarget
					) {
						this.prompt =
							config.themes[this.theme].text.wrongDirection;
						this.isIncorrect = true;
					}
				}

				shape.selected = !shape.selected;
				this.lastSelectedShape = shape;

				if (this.isIncorrect) {
					setTimeout(() => {
						shape.selected = !shape.selected;
					}, 100);
				}

				if (this.checkAllTargets()) {
					this.prompt = config.themes[this.theme].text.allTargets;
					this.showNextButton = true;
				}
			},
			checkAllTargets() {
				let allTargets = true;
				let targets = this.getTargets();
				targets.forEach((target) => {
					if (!target.selected) {
						allTargets = false;
					}
				});
				return allTargets;
			},
			getTargets() {
				let targets = [];
				this.grid.forEach((row) => {
					row.forEach((shape) => {
						if (shape.isTarget && !shape.withholdResponse) {
							targets.push(shape);
						}
					});
				});
				return targets;
			},
			selectAllTargets() {
				// DEBUGGING ONLY
				let targets = this.getTargets();
				targets.forEach((target) => {
					if (!target.selected) {
						target.selected = true;
					}
				});
			},
		},
		created() {
			this.grid = lodash.cloneDeep(this.trial.grid.grid);

			this.trial.targets.forEach((target) => {
				if (target.relationship) {
					this.hasRelationships = true;
				}
				if (target.withholdResponseFor > 0) {
					this.hasWithholdResponse = true;
				}
				if (target.isNTarget > 1) {
					this.hasIsNTarget = true;
				}
			});

			this.introText =
				this.order === "sequential"
					? config.themes[this.theme].text.randomAlternateTargetsIntro
					: "Sometimes you need to find:";
		},
	};
</script>

<style lang="scss" scoped>
	.superheroes {
		#intro,
		#relationships {
			background-image: url("/img/superheroes/backroom.jpg");

			.character {
				top: 0vh;
				left: 7vw;
				width: 17vw;
				z-index: 1;
				position: absolute;
			}
		}

		#test,
		#message {
			background-image: url("/img/superheroes/backroom.jpg");

			.character {
				top: 46vh;
				left: 1vw;
				width: 12vw;
				z-index: 1;
				position: absolute;
			}
		}
	}

	.basic {
		#intro,
		#relationships,
		#test {
			background: #500066;
		}

		.character {
			display: none;
		}
	}

	#intro,
	#relationships,
	#test {
		background-size: cover;
		background-repeat: no-repeat;
		display: flex;
		flex-direction: column;
	}

	#relationships {
		.rules {
			min-height: fit-content !important;
			flex: 0 0 auto;
		}
	}

	.grid-wrapper {
		position: relative;
		width: 100vw;
		height: 100%;
		padding: 0.5vw;
		overflow: hidden;
	}

	.trials {
		.trial {
			display: flex;
			width: 100%;
			position: relative;
		}
	}

	.prompt,
	.options {
		margin-top: 0.5vw;
	}

	.incorrect {
		color: #ff0000;
	}

	.examples {
		overflow-y: auto;
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	.character {
		img {
			width: 100%;
			height: 100%;
		}
	}
</style>
