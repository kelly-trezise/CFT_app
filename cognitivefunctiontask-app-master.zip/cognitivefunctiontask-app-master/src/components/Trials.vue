<template>
	<div>
		<TrialRules
			v-if="displayRules"
			:trials="displayRulesFor"
			:theme="task.theme"
			:order="task.trialOrder"
			:postTutorialMessage="task.postTutorialMessage"
			@accept-rules="acceptRules"
		/>
		<Ready v-if="!displayRules && !ready" @player-ready="ready = true" />
		<Trial
			:trial="currentTrial"
			:lastTrial="lastTrial"
			:lastTrialInSet="lastTrialInSet"
			:firstTrialInSet="firstTrialInSet"
			:showBetweenTrialMessage="
				!lastTrialInSet ||
					!trialsWithRepeats[currentTrialsWithRepeatsIndex + 1]
						.showTrialRules
			"
			:theme="task.theme"
			@next-trial="nextTrial"
			@finish-task="finishTask"
			v-if="!displayRules && ready"
		/>
	</div>
</template>

<script>
	import Trial from "@/components/Trial";
	import Ready from "@/components/Ready";
	import TrialRules from "@/components/TrialRules";

	import { config } from "@/data/Config.js";

	import TrialGeneratorService from "@/services/TrialGeneratorService.js";

	const trialGeneratorService = new TrialGeneratorService();

	export default {
		name: "Trials",
		props: ["task"],
		components: {
			Trial,
			Ready,
			TrialRules,
		},
		data() {
			return {
				currentTrialsWithRepeatsIndex: 0,
				currentTrial: null,
				trialsWithRepeats: [],
				previousTrialIndex: -1,
				displayRules: false,
				displayRulesFor: [],
				ready: false,
				firstTrialInSet: false,
				lastTrialInSet: false,
				lastTrial: false,
			};
		},
		methods: {
			nextTrial() {
				this.currentTrialsWithRepeatsIndex++;

				this.checkIfLastTrial();
				this.firstTrialInSet = false;
				this.lastTrialInSet = false;

				this.currentTrial = this.trialsWithRepeats[
					this.currentTrialsWithRepeatsIndex
				];
				if (this.currentTrial) {
					if (this.task.trialOrder === "sequential") {
						this.checkDisplayTrialRules();
						this.checkIfLastTrialInSet();
					} else {
						this.checkIfFirstTrialInSet();
					}
				}
			},
			checkDisplayTrialRules() {
				// if sequential and trial index changes - display rules before trial
				if (
					this.previousTrialIndex !== this.currentTrial.trialIndex &&
					this.currentTrial.showTrialRules &&
					!this.displayRules
				) {
					this.displayRules = true;
					this.ready = false;
					this.displayRulesFor.push(this.currentTrial);
				}

				// this is the trial index without repeats (so each of the same trial has the same index)
				// used to track trial changes (and generate trial order)
				this.previousTrialIndex = this.currentTrial.trialIndex;
			},
			acceptRules() {
				this.displayRules = false;
				this.displayRulesFor = [];
			},
			finishTask() {
				this.$emit("finish-task");
			},
			checkIfFirstTrialInSet() {
				// for now - always show as first in set to display rules before every matrix
				this.firstTrialInSet = true;
			},
			checkIfLastTrialInSet() {
				const trialsInThisSet = this.trialsWithRepeats.filter(
					(t) => t.trialIndex === this.currentTrial.trialIndex
				);
				if (
					trialsInThisSet.length - 1 ===
					this.currentTrial.trialIndexInSet
				) {
					if (
						this.trialsWithRepeats[
							this.currentTrialsWithRepeatsIndex + 1
						]
					) {
						this.lastTrialInSet = true;
					}
				}
			},
			checkIfLastTrial() {
				if (
					this.currentTrialsWithRepeatsIndex ===
					this.trialsWithRepeats.length - 1
				) {
					this.lastTrial = true;
				}
			},
		},
		created() {
			// if alternate/randomised - display rules for all trials first (colour coded)
			if (
				this.task.trialOrder === "alternate" ||
				this.task.trialOrder === "randomised"
			) {
				if (this.task.trials.length > 1) {
					// set background colours
					let colourIndex = 0;
					this.task.trials.forEach((trial) => {
						trial.backgroundColour =
							config.trialColours[colourIndex];
						colourIndex++;
					});
				}

				this.displayRules = true;
				this.displayRulesFor = this.task.trials;
			}

			// add extra trials
			this.trialsWithRepeats = trialGeneratorService.generateTrialOrder(
				this.task.trials,
				this.task.trialOrder
			);

			this.currentTrial = this.trialsWithRepeats[0];
			this.checkIfLastTrial();

			if (this.task.trialOrder === "sequential") {
				this.checkDisplayTrialRules();
				this.checkIfLastTrialInSet();
			} else {
				this.checkIfFirstTrialInSet();
			}
		},
	};
</script>

<style lang="scss" scoped></style>
