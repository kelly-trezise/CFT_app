<template>
	<div cl>
		<Loading
			:active.sync="this.requestingTask"
			:can-cancel="false"
			:is-full-page="true"
		/>
		<div class="loaded" :class="[task.theme]" v-if="!requestingTask">
			<Intro
				:task="task"
				@start-tutorial="startTutorial"
				@about="toggleAbout"
				v-if="status === 0"
			/>
			<About v-if="status === 1" @back="toggleAbout()" />
			<Tutorial
				v-if="status === 2"
				:player="player"
				:task="task"
				@finish-tutorial="finishTutorial"
			/>
			<Trials
				:task="task"
				v-if="status === 3"
				@finish-task="finishTask"
			/>
			<Finished v-if="status === 4" />
		</div>
	</div>
</template>

<script>
	import axios from "axios";
	import "vue-loading-overlay/dist/vue-loading.css";

	import { shapes } from "@/data/Shapes";

	import Loading from "vue-loading-overlay";
	import Intro from "@/components/Intro";
	import About from "@/components/About";
	import Tutorial from "@/components/Tutorial";
	import Trials from "@/components/Trials";
	import Finished from "@/components/Finished";

	import TaskAnalyticsService from "@/services/TaskAnalyticsService.js";
	const taskAnalyticsService = new TaskAnalyticsService();

	const INTRO = 0,
		ABOUT = 1,
		TUTORIAL = 2,
		TRIALS = 3,
		FINISHED = 4;

	export default {
		name: "App",
		data() {
			return {
				task: {},
				requestingTask: false,
				player: {},
				status: INTRO,
				publicPath: process.env.BASE_URL,
			};
		},
		components: {
			Intro,
			About,
			Tutorial,
			Trials,
			Finished,
			Loading,
		},
		methods: {
			getTask() {
				this.requestingTask = true;
				axios
					.get(process.env.VUE_APP_API_URL + "/getTask", {
						params: {
							task: this.$route.query.task,
						},
					})
					.then((resp) => {
						if (!resp.data.error) {
							this.task = resp.data;

							var myDynamicManifest = {
								name: this.task.name,
								short_name: this.task.name,
								description: "",
								icons: [
									{
										src:
											process.env.VUE_APP_URL +
											"/img/icons/android-chrome-192x192.png",
										sizes: "192x192",
										type: "image/png",
										purpose: "any",
									},
									{
										src:
											process.env.VUE_APP_URL +
											"/img/icons/android-chrome-512x512.png",
										sizes: "512x512",
										type: "image/png",
										purpose: "any",
									},
									{
										src:
											process.env.VUE_APP_URL +
											"/img/icons/android-chrome-maskable-192x192.png",
										sizes: "192x192",
										type: "image/png",
										purpose: "maskable",
									},
									{
										src:
											process.env.VUE_APP_URL +
											"/img/icons/android-chrome-maskable-512x512.png",
										sizes: "512x512",
										type: "image/png",
										purpose: "maskable",
									},
								],
								prefer_related_applications: true,
								related_applications: [],
								start_url:
									process.env.VUE_APP_URL +
									"/#/?task=" +
									this.$route.query.task,
								background_color: "#000000",
								theme_color: "#FFBE00",
								display: "standalone",
								orentation: "landscape",
							};
							const stringManifest = JSON.stringify(
								myDynamicManifest
							);
							const blob = new Blob([stringManifest], {
								type: "application/json",
							});
							const manifestURL = URL.createObjectURL(blob);
							document
								.querySelector("#my-manifest-placeholder")
								.setAttribute("href", manifestURL);

							document.title = this.task.name;

							this.preloadImages(
								shapes.map(
									(shape) =>
										`${process.env.BASE_URL}img/shapes/${shape.file}`
								)
							);

							const directionImages = [
								"lrbtsd.gif",
								"lrbtsnake.gif",
								"lrtbsd.gif",
								"lrtbsnake.gif",
								"rlbtsd.gif",
								"rlbtsnake.gif",
								"rltbsd.gif",
								"rltbsnake.gif",
							];

							this.preloadImages(
								directionImages.map(
									(image) =>
										`${process.env.BASE_URL}img/${image}`
								)
							);

							if (this.task.theme === "superheroes") {
								const superheroesImages = [
									"2characters.png",
									"3characters.png",
									"allcharacters.png",
									"back.jpg",
									"backroom.jpg",
									"backroom_brokenship.jpg",
									"backroom_ship.png",
									"backspace.jpg",
									"black.png",
									"blue.png",
									"green.png",
									"navy.png",
									"pink.png",
									"purple.png",
									"red.png",
									"ship.png",
									"speech.png",
									"yellow.png",
								];

								// preload images
								this.preloadImages(
									superheroesImages.map(
										(image) =>
											`${process.env.BASE_URL}img/superheroes/${image}`
									)
								);
							}
						}
						this.requestingTask = false;
					});
			},
			toggleAbout() {
				if (this.status === INTRO) {
					this.status = ABOUT;
				} else {
					this.status = INTRO;
				}
			},
			startTutorial(codeName, dateOfBirth) {
				this.status = TUTORIAL;
				this.player.codeName = codeName;
				this.player.dateOfBirth = dateOfBirth;
				taskAnalyticsService.setPlayerDetails(this.player);
				taskAnalyticsService.setTaskDetails(this.task);
			},
			finishTutorial() {
				this.status = TRIALS;
			},
			finishTask() {
				this.status = FINISHED;
			},
			updateAvailable(event) {
				this.registration = event.detail;
				this.updateExists = true;
				if (!alert("A new version is available, press OK to refresh")) {
					this.refreshApp();
				}
			},
			refreshApp() {
				this.updateExists = false;
				if (!this.registration || !this.registration.waiting) return;
				this.registration.waiting.postMessage({ type: "SKIP_WAITING" });
			},
			preloadImages(array) {
				for (var i = 0; i < array.length; i++) {
					var img = new Image();
					img.onload = function() {
						var index = array.indexOf(this);
						if (index !== -1) {
							// remove image from the array once it's loaded
							// for memory consumption reasons
							array.splice(index, 1);
						}
					};
					img.src = array[i];
				}
			},
		},
		created() {
			this.getTask();
			taskAnalyticsService.clear();

			// service worker update logic taken from
			// https://dev.to/drbragg/handling-service-worker-updates-in-your-vue-pwa-1pip
			document.addEventListener("swUpdated", this.updateAvailable, {
				once: true,
			});

			// Prevent multiple refreshes
			navigator.serviceWorker.addEventListener("controllerchange", () => {
				if (this.refreshing) return;
				this.refreshing = true;
				window.location.reload();
			});

			// set viewport height
			let vh = window.innerHeight * 0.01;
			document.documentElement.style.setProperty("--vh", `${vh}px`);

			window.addEventListener("resize", () => {
				// We execute the same script as before
				let vh = window.innerHeight * 0.01;
				document.documentElement.style.setProperty("--vh", `${vh}px`);
			});

			// TODO: for testing - remove
			if (!window.Cypress && process.env.NODE_ENV === "development") {
				// setTimeout(() => {
				// 	this.startTutorial("Simon", "01/01/2000");
				// 	this.finishTutorial();
				// }, 200);
			}
		},
	};
</script>

<style lang="scss">
	@import url("https://fonts.googleapis.com/css2?family=Bangers&display=swap");

	body {
		-webkit-tap-highlight-color: rgba(255, 255, 255, 0);
		overscroll-behavior-y: contain;
		-webkit-text-size-adjust: none;
		touch-action: manipulation;
	}

	button {
		border: $border;
		background: #92d050;
		margin: 0.5vw;
		padding: 0 1vw;
		cursor: pointer;
		z-index: 2;
		outline: none;
		height: 12vh;
		min-height: fit-content;
		display: inline-block;
		text-align: center;

		&.previous {
			background: yellow;
		}
	}

	input {
		border: $border;
		background: #fff;
		padding: 1.5vw;
		width: 100%;
		margin-bottom: 3vw;
	}

	.qs-datepicker-container {
		width: 33vw !important;
		font-family: "Bangers", cursive;
		font-size: 3vw;
		color: #000;
	}

	.qs-month,
	.qs-year,
	.qs-square,
	.qs-num {
		font-size: 2.1vw !important;
	}

	.grid-container {
		padding: 0 !important;
	}

	.centered {
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		width: 100%;
	}

	// screen heights
	#intro,
	#about,
	#tutorial,
	#trial-rules-summary,
	#trial-rules-intro,
	#trial-message,
	#intro,
	#relationships,
	#test,
	#finished,
	#ready,
	#trials {
		height: 100vh;
		// set mobile viewport
		// https://css-tricks.com/the-trick-to-viewport-units-on-mobile/
		height: calc(var(--vh, 1vh) * 100);
		max-height: -webkit-fill-available;
	}

	.superheroes {
		#intro,
		#about {
			background-image: url("/img/superheroes/back.jpg");
			background-size: cover;
			background-repeat: no-repeat;
		}

		.speech-prompt {
			background-image: url("/img/superheroes/speech.png");
			background-size: 100% 100%;
			background-repeat: no-repeat;
			position: absolute;
			z-index: 1;

			.text-wrapper {
				display: table;
				width: 100%;
				height: 80%;

				.text {
					white-space: pre-wrap;
					word-wrap: break-word;

					display: table-cell;
					vertical-align: middle;
					text-align: center;

					&.reverse {
						-webkit-transform: scaleX(-1);
						transform: scaleX(-1);
					}
				}
			}

			&.reverse {
				-webkit-transform: scaleX(-1);
				transform: scaleX(-1);
			}
		}
	}

	.basic {
		#intro,
		#about {
			background: #500066;

			label {
				color: #fff;
			}
		}

		#tutorial {
			position: relative;
		}
	}

	.prompt {
		background: white;
		border: $border;
		height: 17vh;
		position: relative;
		width: 100%;
		margin: 0.5vw auto;

		.text-wrapper {
			display: table;
			width: 100%;
			height: 100%;

			.text {
				white-space: pre-wrap;
				word-wrap: break-word;

				display: table-cell;
				vertical-align: middle;
				text-align: center;
			}
		}

		&.fullscreen {
			top: 16vh;
			width: 90vw;
			margin: auto;
			height: fit-content;
			padding: 0.5vw;

			.text {
				white-space: pre-wrap;
			}
		}
	}

	.button-divider {
		width: 12.5vw;
	}

	.rules {
		position: relative;
		display: flex;
		justify-content: space-around;
		flex: 0 1 auto;
		min-height: 29vh;

		.title {
			background: #000;
			color: #fff;
			padding: 0px 1vw;
			// due to widths behing vw, sometimes we have to offset to remove a 1px border that appears between divs and their borders
			margin: -1px;
		}

		.targets {
			background: #fff;
			border: $border;
			min-width: 40vw;

			.shapes-summary {
				padding: 1vw;
				display: flex;
				height: 73%;

				.shape {
					margin-right: 0.8vw;
					display: inline-block;
					min-height: 7vh;
				}

				.more-shapes {
					display: inline;
				}
			}
		}

		.direction {
			border: $border;
			background: #fff;
			height: fit-content;

			.title {
				margin: -1px;
			}

			.image {
				img {
					width: 15vh;
					margin: 1px;
				}
			}
		}
	}

	.grid {
		background: #fff;
		border: $border;
		max-width: 80%;
		display: grid;
		grid-auto-rows: 1fr;
		min-height: 0;
		background: #fff;
	}

	.row {
		display: flex;
		flex-direction: row;
		min-height: 0;
		justify-content: space-between;
		flex: 0 0 auto;
	}

	.shape {
		flex: 1 1 auto;
		cursor: pointer;

		&.rule {
			cursor: initial;
		}

		img {
			height: 100%;
			width: 100%;
			object-fit: contain;
			pointer-events: none;
			-webkit-touch-callout: none; /* iOS Safari */
			-webkit-user-select: none; /* Safari */
			-khtml-user-select: none; /* Konqueror HTML */
			-moz-user-select: none; /* Old versions of Firefox */
			-ms-user-select: none; /* Internet Explorer/Edge */
			user-select: none; /* Non-prefixed version, currently
                                  supported by Chrome, Edge, Opera and Firefox */
		}

		&.selected {
			filter: brightness(50%);
		}

		// these css colours are calculated using https://codepen.io/sosuke/pen/Pjoqqp
		&.correct {
			filter: invert(43%) sepia(94%) saturate(1746%) hue-rotate(87deg)
				brightness(106%) contrast(114%);
		}
		&.incorrect {
			filter: invert(52%) sepia(54%) saturate(6665%) hue-rotate(338deg)
				brightness(95%) contrast(88%);
		}
	}

	.info {
		position: relative;
		display: flex;
		width: 100vw;
		flex: 0 0 auto;

		.options {
			width: 100%;
			height: 100%;

			button {
				position: absolute;
				padding: 0;
				width: 14%;
				height: 60%;

				&.next {
					right: 0.5vw;
				}
			}
		}
	}
</style>
