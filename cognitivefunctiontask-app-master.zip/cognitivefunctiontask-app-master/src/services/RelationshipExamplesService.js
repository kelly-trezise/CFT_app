import lodash from "lodash";

import { config } from "@/data/Config";
import { shapes } from "@/data/Shapes";

let minShapes = 6;

export default class RelationshipExamplesService {
	getExampleRelationships(target) {
		// currently there is a maximum of 1 relationship
		const relationshipString = this._getRelationshipString(target);

		let exampleMeta = config.exampleRelationships[relationshipString];
		let examples = [];

		// must be a withhold response or is N target
		if (!exampleMeta) {
			exampleMeta = [];
			if (target.isNTarget > 1) {
				if (minShapes <= target.isNTarget) {
					minShapes = target.isNTarget;
				}

				let shapes = [];
				for (let count = 0; count < minShapes; count++) {
					if ((count + 1) % target.isNTarget === 0) {
						shapes.push({
							target: true,
							selected: true,
							correct: true,
							incorrect: false,
						});
					} else {
						shapes.push({
							target: true,
							selected: false,
							correct: false,
							incorrect: true,
						});
					}
				}

				exampleMeta.push({
					shapes: shapes,
				});
			}
			if (target.withholdResponseFor) {
				minShapes = 6;
				if (minShapes <= target.withholdResponseFor) {
					minShapes = target.withholdResponseFor;
				}

				let shapes = [];
				for (let count = 0; count < minShapes; count++) {
					if ((count + 1) % target.withholdResponseFor === 0) {
						shapes.push({
							target: true,
							selected: false,
							correct: false,
							incorrect: true,
						});
					} else {
						shapes.push({
							target: true,
							selected: true,
							correct: true,
							incorrect: false,
						});
					}
				}

				exampleMeta.push({
					shapes: shapes,
				});
			}
		}

		// if matching shape and relationship shape - redo last 2 examples
		if (target.relationship) {
			if (
				target.shapes.length === 1 &&
				target.relationshipRule.shapes.length === 1 &&
				target.shapes[0] === target.relationshipRule.shapes[0]
			) {
				exampleMeta.length = 1;
				exampleMeta.push({
					shapes: [
						{
							target: false,
							relationship: true,
							selected: false,
						},
						{
							target: true,
							relationship: false,
							selected: true,
						},
						{
							target: false,
							relationship: false,
							selected: false,
						},
					],
					correct: false,
				});
				if (target.relationshipRule.position === "after") {
					exampleMeta[1].shapes.reverse();
				}
				if (target.relationshipRule.not) {
					exampleMeta[1].correct = true;
				}
			}
		}

		exampleMeta.forEach((example) => {
			let newExample = {
				shapes: [],
				correct: example.correct,
				icon: example.correct ? "check" : "times",
			};
			// convert meta into example with shapes from target
			example.shapes.forEach((shape) => {
				let shapeDetail = {};
				if (shape.target) {
					shapeDetail.file = this._randomArrayElement(target.shapes);
				} else if (shape.relationship) {
					shapeDetail.file = this._randomArrayElement(
						target.relationshipRule.shapes
					);
				} else {
					// any other shape
					let notTargetShapes = shapes.filter(
						(s) => !target.shapes.includes(s.file)
					);

					if (target.relationshipRule) {
						notTargetShapes = notTargetShapes.filter(
							(s) =>
								!target.relationshipRule.shapes.includes(s.file)
						);
					}

					shapeDetail.file = this._randomArrayElement(
						notTargetShapes
					).file;
				}
				shapeDetail.selected = shape.selected;
				shapeDetail.correct = shape.correct;
				shapeDetail.incorrect = shape.incorrect;

				newExample.shapes.push(shapeDetail);
			});

			examples.push(newExample);
		});

		return examples;
	}

	_getRelationshipString(target) {
		let string = "";
		if (target.relationship) {
			string += "is";
			if (target.relationshipRule.not) {
				string += "Not";
			}
			string += this._capitalizeFirstLetter(
				target.relationshipRule.position
			);
		}

		return string;
	}

	_capitalizeFirstLetter(string) {
		return string.charAt(0).toUpperCase() + string.slice(1);
	}

	_randomArrayElement(arr) {
		return lodash.cloneDeep(arr[Math.floor(Math.random() * arr.length)]);
	}
}
