import Stats from "@/models/Stats.js";

export default class TaskAnalyticsService {
	_trialNumber = 0;
	_taskStats = new Stats();
	_trialStats = new Stats();

	clear() {
		localStorage.clear();
	}

	setPlayerDetails(player) {
		localStorage.setItem("player", JSON.stringify(player));
	}

	setTaskDetails(task) {
		let taskAnalytics = this.getTaskAnalytics();

		taskAnalytics.name = task.name;
		taskAnalytics.taskId = task._id;
		taskAnalytics.task = task;
		taskAnalytics.playerName = this._getPlayerInfo().playerName;
		taskAnalytics.dob = this._getPlayerInfo().dob;
		taskAnalytics.trials = [];
		taskAnalytics.stats = {};

		this._taskStats = new Stats();

		this._setTaskAnalytics(taskAnalytics);
	}

	finishTask() {
		this._taskStats.endTime = new Date();
		this._taskStats.timeTakenS =
			(this._taskStats.endTime - this._taskStats.startTime) / 1000;

		let taskAnalytics = this.getTaskAnalytics();

		taskAnalytics.stats = this._taskStats;

		this._setTaskAnalytics(taskAnalytics);
	}

	shapeTouched(shape, timerCount) {
		// Push trial log analytic
		const analytic = {
			timeRemaining: timerCount,
			trialNumberInTask: this._trialNumber,
			selected: shape.selected,
			hasAlreadyTouched: this._hasAlreadyTouched(shape),
			row: shape.row,
			positionInRow: shape.positionInRow,
			overallPosition: shape.overallPosition,
			shape: shape.file,
			isTarget: shape.isTarget,
			isNotNthTarget: shape.isNotNthTarget,
			isDistractorTarget: shape.isDistractorTarget,
			isNearDistractor: shape.isNearDistractor,
			isFarDistractor: shape.isFarDistractor,
			withholdResponse: shape.withholdResponse,
			timestamp: new Date(),
		};

		this._pushTrialLogAnalytic(analytic);

		if (this._isWrongDirection(shape)) {
			this._trialStats.wrongDirection = true;
		}
	}

	newTrial(trial, grid, totalShapeCount, totalTargetCount) {
		this._trialNumber++;

		const analytic = {
			trialId: trial._id,
			grid: grid,
			trialNumberInTask: this._trialNumber,
			trialSet: trial.trialIndex + 1,
			trialNumberInSet: trial.trialIndexInSet + 1,
			numRows: trial.numRows,
			numNodesPerRow: trial.numNodesPerRow,
			totalShapeCount: totalShapeCount,
			targetCount: totalTargetCount,
			timeLimit: trial.timeLimit,
			generatedAt: new Date(),
			log: [],
		};

		this._pushTrialAnalytic(analytic);

		this._trialStats = new Stats(new Date());

		if (this._trialNumber === 1) {
			this._taskStats.startTime = new Date();
		}
	}

	finishTrial(grid, timeRemaining) {
		let taskAnalytics = this.getTaskAnalytics();
		let trial = this._getCurrentTrial(taskAnalytics, this._trialNumber);

		let selectedShapes = [];
		grid.forEach((row) => {
			row.forEach((shape) => {
				if (shape.selected) {
					selectedShapes.push(shape);
				}
			});
		});

		// Update stats
		this._trialStats.truePositive = selectedShapes.filter(
			(s) => s.isTarget && !s.withholdResponse
		).length;
		this._trialStats.falseNegative = selectedShapes.filter(
			(s) => !s.isTarget || (s.isTarget && s.withholdResponse)
		).length;
		this._trialStats.falsePositive =
			trial.targetCount - this._trialStats.truePositive;
		this._trialStats.trueNegative =
			trial.totalShapeCount -
			trial.targetCount -
			this._trialStats.falseNegative;
		this._trialStats.endTime = new Date();
		this._trialStats.timeTakenS =
			(this._trialStats.endTime - this._trialStats.startTime) / 1000;
		this._trialStats.timeRemaining = timeRemaining;

		// ensure time stats aren't minus if time limit reached (as it takes milliseconds to reach this point)
		if (this._trialStats.timeTakenS < 0) {
			this._trialStats.timeTakenS = 0;
		}

		if (this._trialStats.timeRemaining < 0) {
			this._trialStats.timeRemaining = 0;
		}

		// Push trial stats
		trial.stats = this._trialStats;

		// Add to total stats
		this._taskStats.addToTotals(this._trialStats);

		this._setTaskAnalytics(taskAnalytics);
	}

	getPreviousNTrials(n) {
		let taskAnalytics = this.getTaskAnalytics();
		return taskAnalytics.trials.slice(-n);
	}

	getTaskAnalytics() {
		let taskAnalytics = {};
		if (localStorage.getItem("taskAnalytics")) {
			taskAnalytics = JSON.parse(localStorage.getItem("taskAnalytics"));
		}
		return taskAnalytics;
	}

	getTrialNumber() {
		return this._trialNumber;
	}

	_pushTrialAnalytic(trial) {
		let taskAnalytics = this.getTaskAnalytics();
		taskAnalytics.trials.push(trial);
		this._setTaskAnalytics(taskAnalytics);
	}

	_pushTrialLogAnalytic(analytic) {
		let taskAnalytics = this.getTaskAnalytics();

		let trial = this._getCurrentTrial(taskAnalytics, this._trialNumber);
		if (trial) {
			trial.log.push(analytic);
		}

		this._setTaskAnalytics(taskAnalytics);
	}

	_hasAlreadyTouched(shape) {
		// check if shape has already been clicked in this trial
		const taskAnalytics = this.getTaskAnalytics();

		const trial = this._getCurrentTrial(taskAnalytics, this._trialNumber);

		let alreadyTouched = false;

		if (trial.log) {
			alreadyTouched =
				trial.log.filter(
					(analytic) =>
						analytic.trialNumberInTask == this._trialNumber &&
						analytic.overallPosition === shape.overallPosition
				).length > 0;
		}

		if (alreadyTouched) {
			if (shape.isTarget) {
				this._trialStats.correctionTruePositive++;
			} else {
				this._trialStats.correctionFalseNegative++;
			}
		}

		return alreadyTouched;
	}

	_isWrongDirection(shape) {
		const taskAnalytics = this.getTaskAnalytics();

		const trial = this._getCurrentTrial(taskAnalytics, this._trialNumber);

		let wrongDirection = false;

		if (trial.log && trial.log.length > 1) {
			wrongDirection =
				trial.log[trial.log.length - 2].overallPosition >
				shape.overallPosition;
		}

		return wrongDirection;
	}

	_getCurrentTrial(taskAnalytics, trialNumber) {
		let trial = taskAnalytics.trials.find(
			(t) => t.trialNumberInTask === trialNumber
		);
		if (trial) {
			return trial;
		}
		console.error("Trial not found.");
	}

	_getPlayerInfo() {
		let player = JSON.parse(localStorage.getItem("player"));
		if (player) {
			return {
				playerName: player.codeName,
				dob: player.dateOfBirth,
			};
		}
		return "";
	}

	_setTaskAnalytics(taskAnalytics) {
		localStorage.setItem("taskAnalytics", JSON.stringify(taskAnalytics));
	}
}
