export default class TrialService {
	setVerticalScanningDir(trial, grid) {
		if (trial.scanningDirectionVertical === "tb") {
			return grid;
		} else if (trial.scanningDirectionVertical === "bt") {
			return grid.slice().reverse();
		}
	}
	setHorizontalScanningDir(trial, row) {
		if (trial.scanningDirectionHorizontal === "lr") {
			return row;
		} else if (trial.scanningDirectionHorizontal === "rl") {
			return row.slice().reverse();
		}
	}
	setLineByLineScanningDir(trial, grid) {
		if (trial.scanningDirectionLineByLine === "sd") {
			return grid;
		} else if (trial.scanningDirectionLineByLine === "snake") {
			for (let row = 0; row < grid.length; row++) {
				if ((row + 1) % 2 === 0) {
					grid[row] = grid[row].slice().reverse();
				}
			}
			return grid;
		}
	}
}
