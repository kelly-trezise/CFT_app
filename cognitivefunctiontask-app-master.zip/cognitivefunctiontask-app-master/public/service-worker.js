importScripts(
	"https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js"
);

self.__precacheManifest = [].concat(self.__precacheManifest || []);
workbox.precaching.precacheAndRoute(self.__precacheManifest, {});

workbox.routing.registerRoute(
	({ url }) => url.origin === "https://cognitivefunctiontask.local:8079",
	new workbox.strategies.NetworkFirst()
);

workbox.routing.registerRoute(
	({ url }) => url.origin === "https://www.cognitivefunctiontask.com/api",
	new workbox.strategies.NetworkFirst()
);

workbox.routing.registerRoute(
	({ url }) => url.origin === "https://fonts.gstatic.com",
	new workbox.strategies.CacheFirst({
		cacheName: "google-fonts-webfonts",
		plugins: [
			new workbox.cacheableResponse.Plugin({
				statuses: [0, 200],
			}),
			new workbox.expiration.Plugin({
				maxAgeSeconds: 60 * 60 * 24 * 365,
				maxEntries: 30,
			}),
		],
	})
);

workbox.routing.registerRoute(
	({ request }) => request.destination === "image",
	new workbox.strategies.CacheFirst({
		cacheName: "images",
		plugins: [
			new workbox.expiration.Plugin({
				maxEntries: 60,
				maxAgeSeconds: 30 * 24 * 60 * 60, // 30 Days
			}),
		],
	})
);

addEventListener("message", (event) => {
	if (event.data && event.data.type === "SKIP_WAITING") {
		skipWaiting();
	}
});
