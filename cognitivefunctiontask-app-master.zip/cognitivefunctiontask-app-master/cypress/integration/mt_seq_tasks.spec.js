describe("Basic Theme, Multiple Trials, Sequential, No Relationships", () => {
	before(() => {
		// ensure files are saved to dummy db
		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
			() => {
				cy.request("POST", Cypress.env("api") + "/test/empty").then(
					() => {
						cy.task("db:seed");
					}
				);
			}
		);
	});

	beforeEach(() => {
		cy.restoreLocalStorageCache();
	});

	afterEach(() => {
		cy.saveLocalStorageCache();
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads app", () => {
		cy.visit("/");

		cy.get("[data-cy=task-not-found]").should("be.visible");
	});

	it("successfully loads test", () => {
		cy.visit("/#/?task=5efdc2bec0941e45e11a3fa7");

		cy.get("input[name=code-name]").should("be.visible");

		cy.get("input[name=dob]").should("be.visible");
	});

	it("can complete tutorial", () => {
		cy.get("input[name=code-name]").type("Simon");

		cy.get("input[name=dob]").type("01012000");

		// ignore date picker with force
		cy.get("[data-cy=start-task]").click({ force: true });

		// intro
		cy.get("[data-cy=tutorial-next]").click();

		// shape list
		cy.get("[data-cy=tutorial-next]").click();

		// target box example
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=tutorial-next]").click();

		// example
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();

		// direction highlight
		cy.get("[data-cy=direction]").should("have.class", "highlight");

		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});

		cy.get("[data-cy=tutorial-next]").click();

		// change in targets and direction
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.get("[data-cy=direction]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();
	});

	it("can view first trial rules and complete trial rule test", () => {
		cy.get("[data-cy=to-trial-rules]").click();

		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		cy.get("[data-cy=show-message").click();

		cy.get("[data-cy=message]").should("be.visible");

		cy.get("[data-cy=finish-trial-rules").click();
	});

	it("can complete first set of trials", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		cy.get("[data-cy=confirm-post-trial-message]").click();

		cy.wait(2500);
	});

	it("can view second trial rules and complete trial rule test", () => {
		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		cy.get("[data-cy=show-message").click();

		cy.get("[data-cy=message]").should("be.visible");

		cy.get("[data-cy=finish-trial-rules").click();
	});

	it("can complete second set of trials", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});
	});

	it("can save json file", () => {
		cy.get("[data-cy=next]")
			.click()
			.then(() => {
				const date = new Date().toISOString();

				cy.readFile(
					Cypress.env("downloadPath") +
						`MultipleTrialsTaskSimon${date.substring(0, 10)}.json`
				)
					.its("name")
					.should("eq", "Multiple Trials Task");

				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`MultipleTrialsTaskSimon${date.substring(0, 10)}.json`
				);
			});
	});
});

describe("Basic Theme, Multiple Trials - Only Instructions On First Trial, Sequential, No Relationships", () => {
	before(() => {
		// ensure files are saved to dummy db
		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
			() => {
				cy.request("POST", Cypress.env("api") + "/test/empty").then(
					() => {
						cy.task("db:seed");
					}
				);
			}
		);
	});

	beforeEach(() => {
		cy.restoreLocalStorageCache();
	});

	afterEach(() => {
		cy.saveLocalStorageCache();
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads app", () => {
		cy.visit("/");

		cy.get("[data-cy=task-not-found]").should("be.visible");
	});

	it("successfully loads test", () => {
		cy.visit("/#/?task=5efdc2bec0941e45e11a3fa3");

		cy.get("input[name=code-name]").should("be.visible");

		cy.get("input[name=dob]").should("be.visible");
	});

	it("can complete tutorial", () => {
		cy.get("input[name=code-name]").type("Simon");

		cy.get("input[name=dob]").type("01012000");

		// ignore date picker with force
		cy.get("[data-cy=start-task]").click({ force: true });

		// intro
		cy.get("[data-cy=tutorial-next]").click();

		// shape list
		cy.get("[data-cy=tutorial-next]").click();

		// target box example
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=tutorial-next]").click();

		// example
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();

		// direction highlight
		cy.get("[data-cy=direction]").should("have.class", "highlight");

		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});

		cy.get("[data-cy=tutorial-next]").click();

		// change in targets and direction
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.get("[data-cy=direction]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();
	});

	it("can view first trial rules and complete trial rule test", () => {
		cy.get("[data-cy=to-trial-rules]").click();

		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		cy.get("[data-cy=show-message").click();
	});

	it("can complete first set of trials", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});
	});

	it("can complete second set of trials - no instructions shown for these", () => {
		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});
	});

	it("can save json file", () => {
		cy.get("[data-cy=next]")
			.click()
			.then(() => {
				const date = new Date().toISOString();

				cy.readFile(
					Cypress.env("downloadPath") +
						`MultipleTrialsTaskSimon${date.substring(0, 10)}.json`
				)
					.its("name")
					.should("eq", "Multiple Trials Task");

				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`MultipleTrialsTaskSimon${date.substring(0, 10)}.json`
				);
			});
	});
});

describe("Basic Theme, Multiple Trials, Sequential, Relationship", () => {
	before(() => {
		// ensure files are saved to dummy db
		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
			() => {
				cy.request("POST", Cypress.env("api") + "/test/empty").then(
					() => {
						cy.task("db:seed");
					}
				);
			}
		);
	});

	beforeEach(() => {
		cy.restoreLocalStorageCache();
	});

	afterEach(() => {
		cy.saveLocalStorageCache();
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads app", () => {
		cy.visit("/");

		cy.get("[data-cy=task-not-found]").should("be.visible");
	});

	it("successfully loads test", () => {
		cy.visit("/#/?task=5efddb5a4f58a59af9c5319b");

		cy.get("input[name=code-name]").should("be.visible");

		cy.get("input[name=dob]").should("be.visible");
	});

	it("can complete tutorial", () => {
		cy.get("input[name=code-name]").type("Simon");

		cy.get("input[name=dob]").type("01012000");

		// ignore date picker with force
		cy.get("[data-cy=start-task]").click({ force: true });

		// intro
		cy.get("[data-cy=tutorial-next]").click();

		// shape list
		cy.get("[data-cy=tutorial-next]").click();

		// target box example
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=tutorial-next]").click();

		// example
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();

		// direction highlight
		cy.get("[data-cy=direction]").should("have.class", "highlight");

		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});

		cy.get("[data-cy=tutorial-next]").click();

		// change in targets and direction
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.get("[data-cy=direction]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();
	});

	it("can view first trial rules and complete trial rule test", () => {
		cy.get("[data-cy=to-trial-rules]").click();

		cy.get("[data-cy=to-relationships]").click();

		cy.get("[data-cy=to-task]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		cy.get("[data-cy=show-message").click();
	});

	it("can complete first set of trials", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		cy.get("[data-cy=confirm-post-trial-message]").click();

		cy.wait(2500);
	});

	it("can view second trial rules and complete trial rule test", () => {
		cy.get("[data-cy=to-relationships]").click();

		cy.get("[data-cy=to-task]").click();
		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		cy.get("[data-cy=show-message").click();
	});

	it("can complete second set of trials", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});
	});

	it("can save json file", () => {
		cy.get("[data-cy=next]")
			.click()
			.then(() => {
				const date = new Date().toISOString();

				cy.readFile(
					Cypress.env("downloadPath") +
						`MultipleTrialsRelationshipTaskSimon${date.substring(
							0,
							10
						)}.json`
				)
					.its("name")
					.should("eq", "Multiple Trials Relationship Task");

				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`MultipleTrialsRelationshipTaskSimon${date.substring(
							0,
							10
						)}.json`
				);
			});
	});
});

describe("Basic Theme, Multiple Trials - Adaptive, Sequential, No Relationships", () => {
	before(() => {
		// ensure files are saved to dummy db
		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
			() => {
				cy.request("POST", Cypress.env("api") + "/test/empty").then(
					() => {
						cy.task("db:seed");
					}
				);
			}
		);
	});

	beforeEach(() => {
		cy.restoreLocalStorageCache();
	});

	afterEach(() => {
		cy.saveLocalStorageCache();
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads app", () => {
		cy.visit("/");

		cy.get("[data-cy=task-not-found]").should("be.visible");
	});

	it("successfully loads test", () => {
		cy.visit("/#/?task=5eff0858b29b95122c95b67e");

		cy.get("input[name=code-name]").should("be.visible");

		cy.get("input[name=dob]").should("be.visible");
	});

	it("can complete tutorial", () => {
		cy.get("input[name=code-name]").type("Simon");

		cy.get("input[name=dob]").type("01012000");

		// ignore date picker with force
		cy.get("[data-cy=start-task]").click({ force: true });

		// intro
		cy.get("[data-cy=tutorial-next]").click();

		// shape list
		cy.get("[data-cy=tutorial-next]").click();

		// target box example
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=tutorial-next]").click();

		// example
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();

		// direction highlight
		cy.get("[data-cy=direction]").should("have.class", "highlight");

		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});

		cy.get("[data-cy=tutorial-next]").click();

		// change in targets and direction
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.get("[data-cy=direction]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();
	});

	it("can view first trial rules and complete trial rule test", () => {
		cy.get("[data-cy=to-trial-rules]").click();

		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		cy.get("[data-cy=show-message").click();
	});

	it("can complete adaptive trials", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		// check that grid adapts if the user gets 100% of the targets
		cy.get("[data-cy=shape]")
			.its("length")
			.then((size) => {
				let previousShapeCount = size;

				cy.get(".target").each(($target) => {
					$target.click();
				});

				// wait for countdown
				cy.get("[data-cy=between-trial-gap]").should("be.visible");
				cy.wait(200);

				cy.get("[data-cy=shape]")
					.its("length")
					.should("be.gte", previousShapeCount);

				cy.get("[data-cy=shape]")
					.its("length")
					.then((size) => {
						previousShapeCount = size;

						cy.get(".target").each(($target) => {
							$target.click();
						});

						// wait for countdown
						cy.get("[data-cy=between-trial-gap]").should(
							"be.visible"
						);
						cy.wait(200);

						cy.get("[data-cy=shape]")
							.its("length")
							.should("be.gte", previousShapeCount);

						cy.get(".target").each(($target) => {
							$target.click();
						});
					});
			});
	});

	it("can view second trial rules and complete trial rule test", () => {
		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		cy.get("[data-cy=show-message").click();
	});

	it("can complete adaptive trials", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		// check that grid adapts if the user gets 100% of the targets
		cy.get("[data-cy=shape]")
			.its("length")
			.then((size) => {
				let previousShapeCount = size;

				cy.get(".target").each(($target) => {
					$target.click();
				});

				// wait for countdown
				cy.get("[data-cy=between-trial-gap]").should("be.visible");
				cy.wait(200);

				cy.get("[data-cy=shape]")
					.its("length")
					.should("be.gte", previousShapeCount);

				cy.get("[data-cy=shape]")
					.its("length")
					.then((size) => {
						previousShapeCount = size;

						cy.get(".target").each(($target) => {
							$target.click();
						});

						// wait for countdown
						cy.get("[data-cy=between-trial-gap]").should(
							"be.visible"
						);
						cy.wait(200);

						cy.get("[data-cy=shape]")
							.its("length")
							.should("be.gte", previousShapeCount);

						cy.get(".target").each(($target) => {
							$target.click();
						});
					});
			});
	});

	it("can save json file", () => {
		cy.get("[data-cy=next]")
			.click()
			.then(() => {
				const date = new Date().toISOString();

				cy.readFile(
					Cypress.env("downloadPath") +
						`AdaptiveMultipleTaskSimon${date.substring(0, 10)}.json`
				)
					.its("name")
					.should("eq", "Adaptive Multiple Task");

				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`AdaptiveMultipleTaskSimon${date.substring(0, 10)}.json`
				);
			});
	});
});
