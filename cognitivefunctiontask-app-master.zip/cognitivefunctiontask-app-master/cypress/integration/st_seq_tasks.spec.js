describe("Basic Theme, Single Trial, Sequential, No Relationships", () => {
	before(() => {
		// ensure files are saved to dummy db
		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
			() => {
				cy.request("POST", Cypress.env("api") + "/test/empty").then(
					() => {
						cy.task("db:seed");
					}
				);
			}
		);
	});

	beforeEach(() => {
		cy.restoreLocalStorageCache();
	});

	afterEach(() => {
		cy.saveLocalStorageCache();
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads app", () => {
		cy.visit("/");

		cy.get("[data-cy=task-not-found]").should("be.visible");
	});

	it("successfully loads test", () => {
		cy.visit("/#/?task=5efc50fe16294c201533816e");

		cy.get("input[name=code-name]").should("be.visible");

		cy.get("input[name=dob]").should("be.visible");
	});

	it("can complete tutorial", () => {
		cy.get("input[name=code-name]").type("Simon");

		cy.get("input[name=dob]").type("01012000");

		// ignore date picker with force
		cy.get("[data-cy=start-task]").click({ force: true });

		// intro
		cy.get("[data-cy=tutorial-next]").click();

		// shape list
		cy.get("[data-cy=tutorial-next]").click();

		// can go backwards and forwards
		cy.get("[data-cy=tutorial-previous]").click();
		cy.get("[data-cy=tutorial-next]").click();

		// target box example
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=tutorial-next]").click();

		// example
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();

		// direction highlight
		cy.get("[data-cy=direction]").should("have.class", "highlight");

		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});

		cy.get("[data-cy=tutorial-next]").click();

		// change in targets and direction
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.get("[data-cy=direction]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();
	});

	it("can view trial rules and complete trial rule test", () => {
		cy.get("[data-cy=to-trial-rules]").click();

		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		cy.get("[data-cy=show-message").click();

		cy.get("[data-cy=message]").should("be.visible");

		cy.get("[data-cy=finish-trial-rules").click();
	});

	it("can complete trials", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});
	});

	it("can save json file", () => {
		cy.get("[data-cy=next]")
			.click()
			.then(() => {
				const date = new Date().toISOString();

				cy.readFile(
					Cypress.env("downloadPath") +
						`SimpleTaskSimon${date.substring(0, 10)}.json`
				)
					.its("name")
					.should("eq", "Simple Task");

				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`SimpleTaskSimon${date.substring(0, 10)}.json`
				);
			});
	});
});

describe("Superheroes Theme, Single Trial, Sequential, No Relationships", () => {
	before(() => {
		// ensure files are saved to dummy db
		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
			() => {
				cy.request("POST", Cypress.env("api") + "/test/empty").then(
					() => {
						cy.task("db:seed");
					}
				);
			}
		);
	});

	beforeEach(() => {
		cy.restoreLocalStorageCache();
	});

	afterEach(() => {
		cy.saveLocalStorageCache();
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads app", () => {
		cy.visit("/");

		cy.get("[data-cy=task-not-found]").should("be.visible");
	});

	it("successfully loads test", () => {
		cy.visit("/#/?task=5efc7d9ee5e9342955a2ab8c");

		cy.get("input[name=code-name]").should("be.visible");

		cy.get("input[name=dob]").should("be.visible");
	});

	it("can complete tutorial", () => {
		cy.get("input[name=code-name]").type("Simon");

		cy.get("input[name=dob]").type("01012000");

		// ignore date picker with force
		cy.get("[data-cy=start-task]").click({ force: true });

		// we need your help
		cy.get("[data-cy=tutorial-next]").click();

		// we fight crime across the galaxy
		cy.get("[data-cy=tutorial-next]").click();

		// but our spaceship is broken
		cy.get("[data-cy=tutorial-next]").click();

		// and we need your help to fix it
		cy.get("[data-cy=tutorial-next]").click();

		// parts list
		cy.get("[data-cy=tutorial-next]").click();

		// can you tap the ones we need
		cy.get("[data-cy=tutorial-next]").click();

		// target box example
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=tutorial-next]").click();

		// example
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();

		// direction highlight
		cy.get("[data-cy=direction]").should("have.class", "highlight");

		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});

		cy.get("[data-cy=tutorial-next]").click();

		// change in targets and direction
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.get("[data-cy=direction]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();
	});

	it("can view trial rules and complete trial rule test", () => {
		cy.get("[data-cy=to-trial-rules]").click();

		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		cy.get("[data-cy=show-message").click();

		cy.get("[data-cy=message]").should("be.visible");

		cy.get("[data-cy=finish-trial-rules").click();
	});

	it("can complete trials", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});
	});

	it("can save json file", () => {
		cy.get("[data-cy=next]")
			.click()
			.then(() => {
				const date = new Date().toISOString();

				cy.readFile(
					Cypress.env("downloadPath") +
						`SimpleTaskSimon${date.substring(0, 10)}.json`
				)
					.its("name")
					.should("eq", "Simple Task");

				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`SimpleTaskSimon${date.substring(0, 10)}.json`
				);
			});
	});
});

describe("Basic Theme, Single Trial, Sequential, Relationship", () => {
	before(() => {
		// ensure files are saved to dummy db
		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
			() => {
				cy.request("POST", Cypress.env("api") + "/test/empty").then(
					() => {
						cy.task("db:seed");
					}
				);
			}
		);
	});

	beforeEach(() => {
		cy.restoreLocalStorageCache();
	});

	afterEach(() => {
		cy.saveLocalStorageCache();
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads app", () => {
		cy.visit("/");

		cy.get("[data-cy=task-not-found]").should("be.visible");
	});

	it("successfully loads test", () => {
		cy.visit("/#/?task=5efddb5a4f58a59af9c5319a");

		cy.get("input[name=code-name]").should("be.visible");

		cy.get("input[name=dob]").should("be.visible");
	});

	it("can complete tutorial", () => {
		cy.get("input[name=code-name]").type("Simon");

		cy.get("input[name=dob]").type("01012000");

		// ignore date picker with force
		cy.get("[data-cy=start-task]").click({ force: true });

		// intro
		cy.get("[data-cy=tutorial-next]").click();

		// shape list
		cy.get("[data-cy=tutorial-next]").click();

		// target box example
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=tutorial-next]").click();

		// example
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();

		// direction highlight
		cy.get("[data-cy=direction]").should("have.class", "highlight");

		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});

		cy.get("[data-cy=tutorial-next]").click();

		// change in targets and direction
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.get("[data-cy=direction]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();
	});

	it("can view trial rules and complete trial rule test", () => {
		cy.get("[data-cy=to-trial-rules]").click();

		cy.get("[data-cy=to-relationships]").click();

		cy.get("[data-cy=to-task]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		cy.get("[data-cy=show-message").click();
	});

	it("can complete trials", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});
	});

	it("can save json file", () => {
		cy.get("[data-cy=next]")
			.click()
			.then(() => {
				const date = new Date().toISOString();

				cy.readFile(
					Cypress.env("downloadPath") +
						`SimpleRelationshipTaskSimon${date.substring(
							0,
							10
						)}.json`
				)
					.its("name")
					.should("eq", "Simple Relationship Task");

				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`SimpleRelationshipTaskSimon${date.substring(
							0,
							10
						)}.json`
				);
			});
	});
});

describe("Basic Theme, Single Trial - Adaptive, Sequential, No Relationship", () => {
	before(() => {
		// ensure files are saved to dummy db
		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
			() => {
				cy.request("POST", Cypress.env("api") + "/test/empty").then(
					() => {
						cy.task("db:seed");
					}
				);
			}
		);
	});

	beforeEach(() => {
		cy.restoreLocalStorageCache();
	});

	afterEach(() => {
		cy.saveLocalStorageCache();
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads app", () => {
		cy.visit("/");

		cy.get("[data-cy=task-not-found]").should("be.visible");
	});

	it("successfully loads test", () => {
		cy.visit("/#/?task=5eff0858b29b95122c95b67f");

		cy.get("input[name=code-name]").should("be.visible");

		cy.get("input[name=dob]").should("be.visible");
	});

	it("can complete tutorial", () => {
		cy.get("input[name=code-name]").type("Simon");

		cy.get("input[name=dob]").type("01012000");

		// ignore date picker with force
		cy.get("[data-cy=start-task]").click({ force: true });

		// intro
		cy.get("[data-cy=tutorial-next]").click();

		// shape list
		cy.get("[data-cy=tutorial-next]").click();

		// target box example
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=tutorial-next]").click();

		// example
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();

		// direction highlight
		cy.get("[data-cy=direction]").should("have.class", "highlight");

		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});

		cy.get("[data-cy=tutorial-next]").click();

		// change in targets and direction
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.get("[data-cy=direction]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();
	});

	it("can view trial rules and complete trial rule test", () => {
		cy.get("[data-cy=to-trial-rules]").click();

		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		cy.get("[data-cy=show-message]").click();
	});

	it("can complete adaptive trials", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		// check that grid adapts if the user gets 100% of the targets
		cy.get("[data-cy=shape]")
			.its("length")
			.then((size) => {
				let previousShapeCount = size;

				cy.get(".target").each(($target) => {
					$target.click();
				});

				// wait for countdown
				cy.get("[data-cy=between-trial-gap]").should("be.visible");
				cy.wait(200);

				cy.get("[data-cy=shape]")
					.its("length")
					.should("be.gte", previousShapeCount);

				cy.get("[data-cy=shape]")
					.its("length")
					.then((size) => {
						previousShapeCount = size;

						cy.get(".target").each(($target) => {
							$target.click();
						});

						// wait for countdown
						cy.get("[data-cy=between-trial-gap]").should(
							"be.visible"
						);
						cy.wait(200);

						cy.get("[data-cy=shape]")
							.its("length")
							.should("be.gte", previousShapeCount);

						cy.get(".target").each(($target) => {
							$target.click();
						});
					});
			});
	});

	it("can save json file", () => {
		cy.get("[data-cy=next]")
			.click()
			.then(() => {
				const date = new Date().toISOString();

				cy.readFile(
					Cypress.env("downloadPath") +
						`AdaptiveTaskSimon${date.substring(0, 10)}.json`
				)
					.its("name")
					.should("eq", "Adaptive Task");

				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`AdaptiveTaskSimon${date.substring(0, 10)}.json`
				);
			});
	});
});

describe("Basic Theme, Single Trial, Sequential - Multiple Targets, Not Relationships", () => {
	before(() => {
		// ensure files are saved to dummy db
		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
			() => {
				cy.request("POST", Cypress.env("api") + "/test/empty").then(
					() => {
						cy.task("db:seed");
					}
				);
			}
		);
	});

	beforeEach(() => {
		cy.restoreLocalStorageCache();
	});

	afterEach(() => {
		cy.saveLocalStorageCache();
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads app", () => {
		cy.visit("/");

		cy.get("[data-cy=task-not-found]").should("be.visible");
	});

	it("successfully loads test", () => {
		cy.visit("/#/?task=5f02d017d790e0443434f897");

		cy.get("input[name=code-name]").should("be.visible");

		cy.get("input[name=dob]").should("be.visible");
	});

	it("can complete tutorial", () => {
		cy.get("input[name=code-name]").type("Simon");

		cy.get("input[name=dob]").type("01012000");

		// ignore date picker with force
		cy.get("[data-cy=start-task]").click({ force: true });

		// intro
		cy.get("[data-cy=tutorial-next]").click();

		// shape list
		cy.get("[data-cy=tutorial-next]").click();

		// target box example
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=tutorial-next]").click();

		// example
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();

		// direction highlight
		cy.get("[data-cy=direction]").should("have.class", "highlight");

		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});

		cy.get("[data-cy=tutorial-next]").click();

		// change in targets and direction
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.get("[data-cy=direction]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();
	});

	it("can view trial rules and complete trial rule test", () => {
		cy.get("[data-cy=to-trial-rules]").click();

		cy.get("[data-cy=to-relationships]").click();

		cy.get("[data-cy=to-task]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		cy.get("[data-cy=show-message]").click();
	});

	it("can complete trials", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});

		// wait for countdown
		cy.get("[data-cy=between-trial-gap]").should("be.visible");
		cy.wait(200);

		cy.get(".target").each(($target) => {
			$target.click();
		});
	});

	it("can save json file", () => {
		cy.get("[data-cy=next]")
			.click()
			.then(() => {
				const date = new Date().toISOString();

				cy.readFile(
					Cypress.env("downloadPath") +
						`DifferentTargetsTrialSimon${date.substring(
							0,
							10
						)}.json`
				)
					.its("name")
					.should("eq", "Different Targets Trial");

				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`DifferentTargetsTrialSimon${date.substring(
							0,
							10
						)}.json`
				);
			});
	});
});
