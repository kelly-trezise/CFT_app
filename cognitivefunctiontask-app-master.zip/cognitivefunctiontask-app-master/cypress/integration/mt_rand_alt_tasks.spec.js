describe("Basic Theme, Multiple Trials, Alternate, No Relationships", () => {
	before(() => {
		// ensure files are saved to dummy db
		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
			() => {
				cy.request("POST", Cypress.env("api") + "/test/empty").then(
					() => {
						cy.task("db:seed");
					}
				);
			}
		);
	});

	beforeEach(() => {
		cy.restoreLocalStorageCache();
	});

	afterEach(() => {
		cy.saveLocalStorageCache();
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads app", () => {
		cy.visit("/");

		cy.get("[data-cy=task-not-found]").should("be.visible");
	});

	it("successfully loads test", () => {
		cy.visit("/#/?task=5efeeedfb29b95122c9498e3");

		cy.get("input[name=code-name]").should("be.visible");

		cy.get("input[name=dob]").should("be.visible");
	});

	it("can complete tutorial", () => {
		cy.get("input[name=code-name]").type("Simon");

		cy.get("input[name=dob]").type("01012000");

		// ignore date picker with force
		cy.get("[data-cy=start-task]").click({ force: true });

		// intro
		cy.get("[data-cy=tutorial-next]").click();

		// shape list
		cy.get("[data-cy=tutorial-next]").click();

		// target box example
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=tutorial-next]").click();

		// example
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();

		// direction highlight
		cy.get("[data-cy=direction]").should("have.class", "highlight");

		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});

		cy.get("[data-cy=tutorial-next]").click();

		// change in targets and direction
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.get("[data-cy=direction]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();
	});

	it("can view trial rules for both sets of trials", () => {
		cy.get("[data-cy=to-trial-rules]").click();

		cy.get("[data-cy=finish-trial-intro]").click();

		// first rule set
		cy.get("[data-cy=trial-index]").should("be.visible");

		cy.get("[data-cy=trial-index]").should("contain", "1");

		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		// second rule set
		cy.get("[data-cy=trial-index]").should("be.visible");

		cy.get("[data-cy=trial-index]").should("contain", "2");

		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		// summary
		cy.get("[data-cy=trial-rule]").should("have.length", 2);

		cy.get("[data-cy=show-message").click();
	});

	it("can complete alternating trials with rules shown before each", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		for (let trial = 0; trial < 5; trial++) {
			// confirm rules
			cy.get("[data-cy=confirm-rules]").click();

			cy.get(".target").each(($target) => {
				// click on the shapes that match the task targets
				$target.click();
			});

			cy.get("[data-cy=between-trial-gap]").should("be.visible");
			cy.wait(200);
		}

		// last trial
		cy.get("[data-cy=confirm-rules]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});
	});

	it("can save json file", () => {
		cy.get("[data-cy=next]")
			.click()
			.then(() => {
				const date = new Date().toISOString();

				cy.readFile(
					Cypress.env("downloadPath") +
						`AlternateTaskSimon${date.substring(0, 10)}.json`
				)
					.its("name")
					.should("eq", "Alternate Task");

				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`AlternateTaskSimon${date.substring(0, 10)}.json`
				);
			});
	});
});

describe("Basic Theme, Multiple Trials, Randomised, One Trial Relationship", () => {
	before(() => {
		// ensure files are saved to dummy db
		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
			() => {
				cy.request("POST", Cypress.env("api") + "/test/empty").then(
					() => {
						cy.task("db:seed");
					}
				);
			}
		);
	});

	beforeEach(() => {
		cy.restoreLocalStorageCache();
	});

	afterEach(() => {
		cy.saveLocalStorageCache();
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads app", () => {
		cy.visit("/");

		cy.get("[data-cy=task-not-found]").should("be.visible");
	});

	it("successfully loads test", () => {
		cy.visit("/#/?task=5efefdeeb29b95122c94b3a9");

		cy.get("input[name=code-name]").should("be.visible");

		cy.get("input[name=dob]").should("be.visible");
	});

	it("can complete tutorial", () => {
		cy.get("input[name=code-name]").type("Simon");

		cy.get("input[name=dob]").type("01012000");

		// ignore date picker with force
		cy.get("[data-cy=start-task]").click({ force: true });

		// intro
		cy.get("[data-cy=tutorial-next]").click();

		// shape list
		cy.get("[data-cy=tutorial-next]").click();

		// target box example
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=tutorial-next]").click();

		// example
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();

		// direction highlight
		cy.get("[data-cy=direction]").should("have.class", "highlight");

		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});

		cy.get("[data-cy=tutorial-next]").click();

		// change in targets and direction
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.get("[data-cy=direction]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();
	});

	it("can view trial rules for both sets of trials", () => {
		cy.get("[data-cy=to-trial-rules]").click();

		cy.get("[data-cy=finish-trial-intro]").click();

		// first rule set
		cy.get("[data-cy=trial-index]").should("be.visible");

		cy.get("[data-cy=trial-index]").should("contain", "1");

		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		// second rule set
		cy.get("[data-cy=trial-index]").should("be.visible");

		cy.get("[data-cy=trial-index]").should("contain", "2");

		cy.get("[data-cy=to-relationships]").click();

		// relationship prompt
		cy.get("[data-cy=to-task]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		// summary
		cy.get("[data-cy=trial-rule]").should("have.length", 2);

		cy.get("[data-cy=show-message").click();
	});

	it("can complete randomised trials with rules shown before each", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		for (let trial = 0; trial < 5; trial++) {
			// confirm rules
			cy.get("[data-cy=confirm-rules]").click();

			cy.get(".target").each(($target) => {
				// click on the shapes that match the task targets
				$target.click();
			});

			cy.get("[data-cy=between-trial-gap]").should("be.visible");
			cy.wait(200);
		}

		// last trial
		cy.get("[data-cy=confirm-rules]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});
	});

	it("can save json file", () => {
		cy.get("[data-cy=next]")
			.click()
			.then(() => {
				const date = new Date().toISOString();

				cy.readFile(
					Cypress.env("downloadPath") +
						`RandomisedTaskSimon${date.substring(0, 10)}.json`
				)
					.its("name")
					.should("eq", "Randomised Task");

				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`RandomisedTaskSimon${date.substring(0, 10)}.json`
				);
			});
	});
});

describe("Superheroes Theme, Multiple Trials, Alternate, No Relationships", () => {
	before(() => {
		// ensure files are saved to dummy db
		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
			() => {
				cy.request("POST", Cypress.env("api") + "/test/empty").then(
					() => {
						cy.task("db:seed");
					}
				);
			}
		);
	});

	beforeEach(() => {
		cy.restoreLocalStorageCache();
	});

	afterEach(() => {
		cy.saveLocalStorageCache();
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads app", () => {
		cy.visit("/");

		cy.get("[data-cy=task-not-found]").should("be.visible");
	});

	it("successfully loads test", () => {
		cy.visit("/#/?task=5efeeedfb29b95122c9498e1");

		cy.get("input[name=code-name]").should("be.visible");

		cy.get("input[name=dob]").should("be.visible");
	});

	it("can complete tutorial", () => {
		cy.get("input[name=code-name]").type("Simon");

		cy.get("input[name=dob]").type("01012000");

		// ignore date picker with force
		cy.get("[data-cy=start-task]").click({ force: true });

		// we need your help
		cy.get("[data-cy=tutorial-next]").click();

		// we fight crime across the galaxy
		cy.get("[data-cy=tutorial-next]").click();

		// but our spaceship is broken
		cy.get("[data-cy=tutorial-next]").click();

		// and we need your help to fix it
		cy.get("[data-cy=tutorial-next]").click();

		// parts list
		cy.get("[data-cy=tutorial-next]").click();

		// can you tap the ones we need
		cy.get("[data-cy=tutorial-next]").click();

		// target box example
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=tutorial-next]").click();

		// example
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();

		// direction highlight
		cy.get("[data-cy=direction]").should("have.class", "highlight");

		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});

		cy.get("[data-cy=tutorial-next]").click();

		// change in targets and direction
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.get("[data-cy=direction]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();
	});

	it("can view trial rules for both sets of trials", () => {
		cy.get("[data-cy=to-trial-rules]").click();

		cy.get("[data-cy=finish-trial-intro]").click();

		// first rule set
		cy.get("[data-cy=trial-index]").should("be.visible");

		cy.get("[data-cy=trial-index]").should("contain", "1");

		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		// second rule set
		cy.get("[data-cy=trial-index]").should("be.visible");

		cy.get("[data-cy=trial-index]").should("contain", "2");

		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		// summary
		cy.get("[data-cy=trial-rule]").should("have.length", 2);

		cy.get("[data-cy=show-message").click();
	});

	it("can complete alternating trials with rules shown before each", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		for (let trial = 0; trial < 5; trial++) {
			// confirm rules
			cy.get("[data-cy=confirm-rules]").click();

			cy.get(".target").each(($target) => {
				// click on the shapes that match the task targets
				$target.click();
			});

			cy.get("[data-cy=between-trial-gap]").should("be.visible");
			cy.wait(200);
		}

		// last trial
		cy.get("[data-cy=confirm-rules]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});
	});

	it("can save json file", () => {
		cy.get("[data-cy=next]")
			.click()
			.then(() => {
				const date = new Date().toISOString();

				cy.readFile(
					Cypress.env("downloadPath") +
						`AlternateTaskSimon${date.substring(0, 10)}.json`
				)
					.its("name")
					.should("eq", "Alternate Task");

				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`AlternateTaskSimon${date.substring(0, 10)}.json`
				);
			});
	});
});

describe("Superheroes Theme, Multiple Trials, Randomised, One Trial Relationship", () => {
	before(() => {
		// ensure files are saved to dummy db
		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
			() => {
				cy.request("POST", Cypress.env("api") + "/test/empty").then(
					() => {
						cy.task("db:seed");
					}
				);
			}
		);
	});

	beforeEach(() => {
		cy.restoreLocalStorageCache();
	});

	afterEach(() => {
		cy.saveLocalStorageCache();
	});

	after(() => {
		cy.request("POST", Cypress.env("api") + "/connect");
	});

	it("successfully loads app", () => {
		cy.visit("/");

		cy.get("[data-cy=task-not-found]").should("be.visible");
	});

	it("successfully loads test", () => {
		cy.visit("/#/?task=5efefdeeb29b95122c94b3a5");

		cy.get("input[name=code-name]").should("be.visible");

		cy.get("input[name=dob]").should("be.visible");
	});

	it("can complete tutorial", () => {
		cy.get("input[name=code-name]").type("Simon");

		cy.get("input[name=dob]").type("01012000");

		// ignore date picker with force
		cy.get("[data-cy=start-task]").click({ force: true });

		// we need your help
		cy.get("[data-cy=tutorial-next]").click();

		// we fight crime across the galaxy
		cy.get("[data-cy=tutorial-next]").click();

		// but our spaceship is broken
		cy.get("[data-cy=tutorial-next]").click();

		// and we need your help to fix it
		cy.get("[data-cy=tutorial-next]").click();

		// parts list
		cy.get("[data-cy=tutorial-next]").click();

		// can you tap the ones we need
		cy.get("[data-cy=tutorial-next]").click();

		// target box example
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=tutorial-next]").click();

		// example
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();

		// direction highlight
		cy.get("[data-cy=direction]").should("have.class", "highlight");

		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});

		cy.get("[data-cy=tutorial-next]").click();

		// change in targets and direction
		cy.get("[data-cy=targets]").should("have.class", "highlight");
		cy.get("[data-cy=direction]").should("have.class", "highlight");
		cy.wait(2500);
		cy.get("[data-cy=shape]").each(($shape) => {
			expect($shape[0].classList.value).to.satisfy((classString) => {
				return (
					classString.includes("correct") ||
					classString.includes("incorrect")
				);
			});
		});
		cy.get("[data-cy=tutorial-next]").click();
	});

	it("can view trial rules for both sets of trials", () => {
		cy.get("[data-cy=to-trial-rules]").click();

		cy.get("[data-cy=finish-trial-intro]").click();

		// first rule set
		cy.get("[data-cy=trial-index]").should("be.visible");

		cy.get("[data-cy=trial-index]").should("contain", "1");

		cy.get("[data-cy=to-relationships]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		// second rule set
		cy.get("[data-cy=trial-index]").should("be.visible");

		cy.get("[data-cy=trial-index]").should("contain", "2");

		cy.get("[data-cy=to-relationships]").click();

		// relationship prompt
		cy.get("[data-cy=to-task]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});

		cy.get("[data-cy=next-rule]").click();

		// summary
		cy.get("[data-cy=trial-rule]").should("have.length", 2);

		cy.get("[data-cy=show-message").click();
	});

	it("can complete randomised trials with rules shown before each trial", () => {
		cy.get("[data-cy=ready]").click();

		// wait for countdown
		cy.wait(2500);

		for (let trial = 0; trial < 5; trial++) {
			// confirm rules
			cy.get("[data-cy=confirm-rules]").click();

			cy.get(".target").each(($target) => {
				// click on the shapes that match the task targets
				$target.click();
			});

			cy.get("[data-cy=between-trial-gap]").should("be.visible");
			cy.wait(200);
		}

		// last trial
		cy.get("[data-cy=confirm-rules]").click();

		cy.get(".target").each(($target) => {
			// click on the shapes that match the task targets
			$target.click();
		});
	});

	it("can save json file", () => {
		cy.get("[data-cy=next]")
			.click()
			.then(() => {
				const date = new Date().toISOString();

				cy.readFile(
					Cypress.env("downloadPath") +
						`RandomisedTaskSimon${date.substring(0, 10)}.json`
				)
					.its("name")
					.should("eq", "Randomised Task");

				cy.task(
					"delete-file",
					Cypress.env("downloadPath") +
						`RandomisedTaskSimon${date.substring(0, 10)}.json`
				);
			});
	});
});

// describe("Basic Theme, Multiple Trials - Adaptive, Alternate, No Relationships", () => {
// 	before(() => {
// 		// ensure files are saved to dummy db
// 		cy.request("POST", Cypress.env("api") + "/test/connect/app").then(
// 			() => {
// 				cy.request("POST", Cypress.env("api") + "/test/empty").then(
// 					() => {
// 						cy.task("db:seed");
// 					}
// 				);
// 			}
// 		);
// 	});

// 	beforeEach(() => {
// 		cy.restoreLocalStorageCache();
// 	});

// 	afterEach(() => {
// 		cy.saveLocalStorageCache();
// 	});

// 	after(() => {
// 		cy.request("POST", Cypress.env("api") + "/connect");
// 	});

// 	it("successfully loads app", () => {
// 		cy.visit("/");

// 		cy.get("[data-cy=task-not-found]").should("be.visible");
// 	});

// 	it("successfully loads test", () => {
// 		cy.visit("/#/?task=5eff0858b29b95122c95b67g");

// 		cy.get("input[name=code-name]").should("be.visible");

// 		cy.get("input[name=dob]").should("be.visible");
// 	});

// 	it("can complete tutorial", () => {
// 		cy.get("input[name=code-name]").type("Simon");

// 		cy.get("input[name=dob]").type("01012000");

// 		// ignore date picker with force
// 		cy.get("[data-cy=start-task]").click({ force: true });

// 		// intro
// 		cy.get("[data-cy=tutorial-next]").click();

// 		// shape list
// 		cy.get("[data-cy=tutorial-next]").click();

// 		// example
// 		cy.wait(2500);
// 		cy.get("[data-cy=shape]").each(($shape) => {
// 			expect($shape[0].classList.value).to.satisfy((classString) => {
// 				return (
// 					classString.includes("correct") ||
// 					classString.includes("incorrect")
// 				);
// 			});
// 		});
// 		cy.get("[data-cy=tutorial-next]").click();

// 		// direction
// 		cy.get("[data-cy=direction]").should("have.class", "highlight");

// 		cy.wait(2500);
// 		cy.get("[data-cy=shape]").each(($shape) => {
// 			expect($shape[0].classList.value).to.satisfy((classString) => {
// 				return (
// 					classString.includes("correct") ||
// 					classString.includes("incorrect")
// 				);
// 			});
// 		});
// 		cy.get("[data-cy=tutorial-next]").click();

// 		cy.get(".target").each(($target) => {
// 			// click on the shapes that match the task targets
// 			$target.click();
// 		});

// 		cy.get("[data-cy=tutorial-next]").click();
// 	});

// 	it("can view trial rules for both sets of trials", () => {
// 		cy.get("[data-cy=to-trial-rules]").click();

// 		// first rule set
// 		cy.get("[data-cy=trial-index]").should("be.visible");

// 		cy.get("[data-cy=trial-index]").should("contain", "1");

// 		cy.get("[data-cy=to-relationships]").click();

// 		cy.get(".target").each(($target) => {
// 			// click on the shapes that match the task targets
// 			$target.click();
// 		});

// 		cy.get("[data-cy=to-message]").click();

// 		// second rule set
// 		cy.get("[data-cy=trial-index]").should("be.visible");

// 		cy.get("[data-cy=trial-index]").should("contain", "2");

// 		cy.get("[data-cy=to-relationships]").click();

// 		cy.get(".target").each(($target) => {
// 			// click on the shapes that match the task targets
// 			$target.click();
// 		});

// 		cy.get("[data-cy=to-message]").click();

// 		// summary
// 		cy.get("[data-cy=trial-rule]").should("have.length", 2);

// 		cy.get("[data-cy=show-message").click();
// 	});

// 	it("can complete alternating adaptive trials", () => {
// 		// TODO: complete
// 	});

// 	it("can save json file", () => {
// 		cy.get("[data-cy=next]")
// 			.click()
// 			.then(() => {
// 				const date = new Date().toISOString();

// 				cy.readFile(
// 					Cypress.env("downloadPath") +
// 						`AdaptiveMultipleTaskSimon${date.substring(0, 10)}.json`
// 				)
// 					.its("name")
// 					.should("eq", "Adaptive Multiple Task");

// 				cy.task(
// 					"delete-file",
// 					Cypress.env("downloadPath") +
// 						`AdaptiveMultipleTaskSimon${date.substring(0, 10)}.json`
// 				);
// 			});
// 	});
// });
