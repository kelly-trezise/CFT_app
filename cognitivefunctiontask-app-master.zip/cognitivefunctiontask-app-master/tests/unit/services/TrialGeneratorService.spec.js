import TrialGeneratorService from "@/services/TrialGeneratorService";

describe("Generate Trial List", () => {
	let trials = [
		{
			numRows: "5",
			numNodesPerRow: "20",
			padding: 10,
			timeLimit: null,
			showTimeLimit: false,
			showNextButton: false,
			numTrials: "3",
			targets: [
				{
					shapes: [
						"L_0_sharp.png",
						"L_90_sharp.png",
						"L_180_sharp.png",
						"L_270_sharp.png",
					],
					isNTarget: 1,
					withholdResponseFor: 0,
					relationships: [],
					proportion: 20,
					tempId: { id: "[object Uint8Array]" },
				},
			],
			targetProportion: 20,
			nearDistractors: [
				"X_0_sharp.png",
				"T_0_sharp.png",
				"T_90_sharp.png",
				"T_180_sharp.png",
				"T_270_sharp.png",
				"I_0_sharp.png",
				"I_90_sharp.png",
				"O_0_sharp.png",
				"O_90_sharp.png",
			],
			nearDistractorProportion: 20,
			farDistractors: [
				"X_0_round.png",
				"T_0_round.png",
				"T_90_round.png",
				"T_180_round.png",
				"T_270_round.png",
				"L_0_round.png",
				"L_90_round.png",
				"L_180_round.png",
				"L_270_round.png",
				"I_0_round.png",
				"I_90_round.png",
				"O_0_round.png",
				"O_90_round.png",
				"O_180_round.png",
			],
			scanningDirectionVertical: "tb",
			scanningDirectionHorizontal: "lr",
			scanningDirectionLineByLine: "sd",
			adaptive: false,
			adaptiveRules: [],
			showTrialRules: true,
			preTrialMessage: "",
			postTrialMessage: "",
			trialGap: 200,
			tempId: "5f071906b473bf94e76dfda4",
		},
		{
			numRows: "3",
			numNodesPerRow: "20",
			padding: 10,
			timeLimit: null,
			showTimeLimit: false,
			showNextButton: false,
			numTrials: "3",
			targets: [
				{
					shapes: [
						"L_0_sharp.png",
						"L_90_sharp.png",
						"L_180_sharp.png",
						"L_270_sharp.png",
					],
					isNTarget: 1,
					withholdResponseFor: 0,
					relationships: [],
					proportion: 20,
					tempId: { id: "[object Uint8Array]" },
				},
			],
			targetProportion: 20,
			nearDistractors: [
				"X_0_sharp.png",
				"T_0_sharp.png",
				"T_90_sharp.png",
				"T_180_sharp.png",
				"T_270_sharp.png",
				"I_0_sharp.png",
				"I_90_sharp.png",
				"O_0_sharp.png",
				"O_90_sharp.png",
			],
			nearDistractorProportion: 20,
			farDistractors: [
				"X_0_round.png",
				"T_0_round.png",
				"T_90_round.png",
				"T_180_round.png",
				"T_270_round.png",
				"L_0_round.png",
				"L_90_round.png",
				"L_180_round.png",
				"L_270_round.png",
				"I_0_round.png",
				"I_90_round.png",
				"O_0_round.png",
				"O_90_round.png",
				"O_180_round.png",
			],
			scanningDirectionVertical: "tb",
			scanningDirectionHorizontal: "lr",
			scanningDirectionLineByLine: "sd",
			adaptive: false,
			adaptiveRules: [],
			showTrialRules: true,
			preTrialMessage: "",
			postTrialMessage: "",
			trialGap: 200,
			tempId: "5f071908b473bf94e76dfda5",
		},
		{
			numRows: "5",
			numNodesPerRow: "25",
			padding: 10,
			timeLimit: null,
			showTimeLimit: false,
			showNextButton: false,
			numTrials: "3",
			targets: [
				{
					shapes: [
						"L_0_sharp.png",
						"L_90_sharp.png",
						"L_180_sharp.png",
						"L_270_sharp.png",
					],
					isNTarget: 1,
					withholdResponseFor: 0,
					relationships: [],
					proportion: 20,
					tempId: { id: "[object Uint8Array]" },
				},
			],
			targetProportion: 20,
			nearDistractors: [
				"X_0_sharp.png",
				"T_0_sharp.png",
				"T_90_sharp.png",
				"T_180_sharp.png",
				"T_270_sharp.png",
				"I_0_sharp.png",
				"I_90_sharp.png",
				"O_0_sharp.png",
				"O_90_sharp.png",
			],
			nearDistractorProportion: 20,
			farDistractors: [
				"X_0_round.png",
				"T_0_round.png",
				"T_90_round.png",
				"T_180_round.png",
				"T_270_round.png",
				"L_0_round.png",
				"L_90_round.png",
				"L_180_round.png",
				"L_270_round.png",
				"I_0_round.png",
				"I_90_round.png",
				"O_0_round.png",
				"O_90_round.png",
				"O_180_round.png",
			],
			scanningDirectionVertical: "bt",
			scanningDirectionHorizontal: "lr",
			scanningDirectionLineByLine: "sd",
			adaptive: false,
			adaptiveRules: [],
			showTrialRules: true,
			preTrialMessage: "",
			postTrialMessage: "",
			trialGap: 200,
			tempId: "5f071908b473bf94e76dfda6",
		},
	];

	it("trial order should be sequential for an sequential task", () => {
		const trialGeneratorService = new TrialGeneratorService();

		let generatedTrials = trialGeneratorService.generateTrialOrder(
			trials,
			"sequential"
		);

		expect(generatedTrials.length).toBe(9);

		// first trial
		expect(generatedTrials[0].tempId).toBe("5f071906b473bf94e76dfda4");
		expect(generatedTrials[1].tempId).toBe("5f071906b473bf94e76dfda4");
		expect(generatedTrials[2].tempId).toBe("5f071906b473bf94e76dfda4");

		// second trial
		expect(generatedTrials[3].tempId).toBe("5f071908b473bf94e76dfda5");
		expect(generatedTrials[4].tempId).toBe("5f071908b473bf94e76dfda5");
		expect(generatedTrials[5].tempId).toBe("5f071908b473bf94e76dfda5");

		// third trial
		expect(generatedTrials[6].tempId).toBe("5f071908b473bf94e76dfda6");
		expect(generatedTrials[7].tempId).toBe("5f071908b473bf94e76dfda6");
		expect(generatedTrials[8].tempId).toBe("5f071908b473bf94e76dfda6");
	});

	it("trial order should be alternate for an alternate task", () => {
		const trialGeneratorService = new TrialGeneratorService();

		let generatedTrials = trialGeneratorService.generateTrialOrder(
			trials,
			"alternate"
		);

		expect(generatedTrials.length).toBe(9);

		// first set
		expect(generatedTrials[0].tempId).toBe("5f071906b473bf94e76dfda4");
		expect(generatedTrials[1].tempId).toBe("5f071908b473bf94e76dfda5");
		expect(generatedTrials[2].tempId).toBe("5f071908b473bf94e76dfda6");

		// second set
		expect(generatedTrials[3].tempId).toBe("5f071906b473bf94e76dfda4");
		expect(generatedTrials[4].tempId).toBe("5f071908b473bf94e76dfda5");
		expect(generatedTrials[5].tempId).toBe("5f071908b473bf94e76dfda6");

		// third set
		expect(generatedTrials[6].tempId).toBe("5f071906b473bf94e76dfda4");
		expect(generatedTrials[7].tempId).toBe("5f071908b473bf94e76dfda5");
		expect(generatedTrials[8].tempId).toBe("5f071908b473bf94e76dfda6");
	});

	it("trial order should be randomised for a randomised task", () => {
		const trialGeneratorService = new TrialGeneratorService();

		let generatedTrials = trialGeneratorService.generateTrialOrder(
			trials,
			"randomised"
		);

		expect(generatedTrials.length).toBe(9);
	});
});

const numTrials = 50;
// allow 25% variance on proportions
const maxError = 0.25;

describe("No Relationships, No Withhold Response, Every Target", () => {
	let generatedTrials = [];
	let targetShapes = [];
	let trialDetails = {
		nearDistractors: [
			"X_0_sharp.png",
			"T_0_sharp.png",
			"T_90_sharp.png",
			"T_180_sharp.png",
			"T_270_sharp.png",
			"I_0_sharp.png",
			"I_90_sharp.png",
			"O_0_sharp.png",
			"O_90_sharp.png",
		],
		farDistractors: [
			"X_0_round.png",
			"T_0_round.png",
			"T_90_round.png",
			"T_180_round.png",
			"T_270_round.png",
			"L_0_round.png",
			"L_90_round.png",
			"L_180_round.png",
			"L_270_round.png",
			"I_0_round.png",
			"I_90_round.png",
			"O_0_round.png",
			"O_90_round.png",
			"O_180_round.png",
		],
		numRows: 5,
		numNodesPerRow: 25,
		timeLimit: 60,
		showTimeLimit: true,
		showNextButton: false,
		numTrials: 5,
		targets: [
			{
				shapes: [
					"L_0_sharp.png",
					"L_90_sharp.png",
					"L_180_sharp.png",
					"L_270_sharp.png",
				],
				isNTarget: 1,
				relationship: false,
				relationshipRule: {},
				proportion: 25,
			},
		],
		nearDistractorProportion: 25,
		scanningDirectionVertical: "tb",
		scanningDirectionHorizontal: "lr",
		scanningDirectionLineByLine: "sd",
		withholdResponse: false,
		withholdNResponse: 2,
		withholdResponseOnlyForIsTarget: true,
		padding: 5,
		adaptive: true,
		adaptiveRules: [],
	};

	beforeAll(() => {
		const trialGeneratorService = new TrialGeneratorService();

		for (let i = 0; i < numTrials; i++) {
			generatedTrials.push(
				trialGeneratorService.generateGrid(trialDetails)
			);
		}

		targetShapes = getTrialTargetShapes(trialDetails);
	});

	it("generated grids should have the correct target proportion", () => {
		generatedTrials.forEach((trial) => {
			let totalTargets = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isTarget) {
						totalTargets++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion += target.proportion;
			});

			const targetProportion = totalTargets / totalShapes;
			const diff = targetProportion - totalTargetProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct near distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let nearDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isNearDistractor) {
						nearDistractors++;
					}
					totalShapes++;
				});
			});

			const nearDistractorProportion = nearDistractors / totalShapes;
			const diff =
				nearDistractorProportion -
				trialDetails.nearDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct far distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let farDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isFarDistractor) {
						farDistractors++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion += target.proportion;
			});
			let expectedFarDistractorProportion =
				100 -
				totalTargetProportion -
				trialDetails.nearDistractorProportion;

			const farDistractorProportion = farDistractors / totalShapes;
			const diff =
				farDistractorProportion - expectedFarDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("all target shapes (by file) should be targets", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (targetShapes.filter((s) => s === shape.file).length > 0) {
					expect(shape.isTarget).toBeTruthy();
				}
			});
		});
	});
});

describe("Is Before Relationship, No Withhold Response, Every Target", () => {
	let generatedTrials = [];
	let relationshipShapes = [];
	let targetShapes = [];
	let trialDetails = {
		nearDistractors: [
			"X_0_sharp.png",
			"T_0_sharp.png",
			"T_90_sharp.png",
			"T_180_sharp.png",
			"T_270_sharp.png",
			"I_0_sharp.png",
			"I_90_sharp.png",
			"O_0_sharp.png",
			"O_90_sharp.png",
		],
		farDistractors: [
			"X_0_round.png",
			"T_0_round.png",
			"T_90_round.png",
			"T_180_round.png",
			"T_270_round.png",
			"L_0_round.png",
			"L_90_round.png",
			"L_180_round.png",
			"L_270_round.png",
			"I_0_round.png",
			"I_90_round.png",
			"O_0_round.png",
			"O_90_round.png",
			"O_180_round.png",
		],
		numRows: 5,
		numNodesPerRow: 25,
		timeLimit: 60,
		showTimeLimit: true,
		showNextButton: false,
		numTrials: 5,
		targets: [
			{
				shapes: [
					"L_0_sharp.png",
					"L_90_sharp.png",
					"L_180_sharp.png",
					"L_270_sharp.png",
				],
				isNTarget: 1,
				relationship: true,
				relationshipRule: {
					shapes: [
						"T_0_sharp.png",
						"T_90_sharp.png",
						"T_180_sharp.png",
						"T_270_sharp.png",
					],
					not: false,
					position: "before",
					proportion: 50,
				},
				proportion: 25,
			},
		],
		nearDistractorProportion: 25,
		scanningDirectionVertical: "tb",
		scanningDirectionHorizontal: "lr",
		scanningDirectionLineByLine: "sd",
		withholdResponse: false,
		withholdNResponse: 2,
		withholdResponseOnlyForIsTarget: true,
		padding: 5,
		adaptive: true,
		adaptiveRules: [],
	};

	beforeAll(() => {
		const trialGeneratorService = new TrialGeneratorService();

		for (let i = 0; i < numTrials; i++) {
			generatedTrials.push(
				trialGeneratorService.generateGrid(trialDetails)
			);
		}

		relationshipShapes = getTrialRelationshipShapes(trialDetails);
		targetShapes = getTrialTargetShapes(trialDetails);
	});

	it("generated grids should have correct proportion of targets and distractor targets", () => {
		generatedTrials.forEach((trial) => {
			let totalTargets = 0;
			let totalDistractorTargets = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isTarget) {
						totalTargets++;
					}
					if (shape.isDistractorTarget) {
						totalDistractorTargets++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			let totalDistractorTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
				totalDistractorTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
			});

			const targetProportion = totalTargets / totalShapes;
			const targetDiff = targetProportion - totalTargetProportion / 100;
			// can be up to 25% out
			expect(targetDiff).toBeGreaterThan(-maxError);
			expect(targetDiff).toBeLessThan(maxError);

			const distractorTargetProportion =
				totalDistractorTargets / totalShapes;
			const distractorTargetDiff =
				distractorTargetProportion -
				totalDistractorTargetProportion / 100;
			// can be up to 25% out
			expect(distractorTargetDiff).toBeGreaterThan(-maxError);
			expect(distractorTargetDiff).toBeLessThan(maxError);
		});
	});

	it("all targets and distractor targets should be target shapes", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (shape.isTarget || shape.isDistractorTarget) {
					expect(
						targetShapes.filter((s) => s === shape.file).length
					).toBe(1);
				}
			});
		});
	});

	it("generated grids should have the correct near distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let nearDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isNearDistractor) {
						nearDistractors++;
					}
					totalShapes++;
				});
			});

			const nearDistractorProportion = nearDistractors / totalShapes;
			const diff =
				nearDistractorProportion -
				trialDetails.nearDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct far distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let farDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isFarDistractor) {
						farDistractors++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion += target.proportion;
			});
			let expectedFarDistractorProportion =
				100 -
				totalTargetProportion -
				trialDetails.nearDistractorProportion;

			const farDistractorProportion = farDistractors / totalShapes;
			const diff =
				farDistractorProportion - expectedFarDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("all target shapes (by file) should be either targets or distractor targets", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (targetShapes.filter((s) => s === shape.file).length > 0) {
					expect(
						shape.isTarget || shape.isDistractorTarget
					).toBeTruthy();
				}
			});
		});
	});

	it("all targets should have relationship shapes (and flags) after them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isTarget && index + 1 < trial.shapes.length) {
					expect(trial.shapes[index + 1].isRelationship).toBeTruthy();
					expect(
						relationshipShapes.filter(
							(s) => s === trial.shapes[index + 1].file
						).length
					).toBe(1);
				}
			});
		});
	});

	it("all distractor targets should not have relationship shapes after them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (
					shape.isDistractorTarget &&
					index + 1 < trial.shapes.length
				) {
					expect(trial.shapes[index + 1].isRelationship).toBeFalsy();
				}
			});
		});
	});
});

describe("Is After Relationship, No Withhold Response, Every Target", () => {
	let generatedTrials = [];
	let relationshipShapes = [];
	let targetShapes = [];
	let trialDetails = {
		nearDistractors: [
			"X_0_sharp.png",
			"T_0_sharp.png",
			"T_90_sharp.png",
			"T_180_sharp.png",
			"T_270_sharp.png",
			"I_0_sharp.png",
			"I_90_sharp.png",
			"O_0_sharp.png",
			"O_90_sharp.png",
		],
		farDistractors: [
			"X_0_round.png",
			"T_0_round.png",
			"T_90_round.png",
			"T_180_round.png",
			"T_270_round.png",
			"L_0_round.png",
			"L_90_round.png",
			"L_180_round.png",
			"L_270_round.png",
			"I_0_round.png",
			"I_90_round.png",
			"O_0_round.png",
			"O_90_round.png",
			"O_180_round.png",
		],
		numRows: 5,
		numNodesPerRow: 25,
		timeLimit: 60,
		showTimeLimit: true,
		showNextButton: false,
		numTrials: 5,
		targets: [
			{
				shapes: [
					"L_0_sharp.png",
					"L_90_sharp.png",
					"L_180_sharp.png",
					"L_270_sharp.png",
				],
				isNTarget: 1,
				relationship: true,
				relationshipRule: {
					shapes: [
						"T_0_sharp.png",
						"T_90_sharp.png",
						"T_180_sharp.png",
						"T_270_sharp.png",
					],
					not: false,
					position: "after",
					proportion: 50,
				},
				proportion: 25,
			},
		],
		nearDistractorProportion: 25,
		scanningDirectionVertical: "tb",
		scanningDirectionHorizontal: "lr",
		scanningDirectionLineByLine: "sd",
		withholdResponse: false,
		withholdNResponse: 2,
		withholdResponseOnlyForIsTarget: true,
		padding: 5,
		adaptive: true,
		adaptiveRules: [],
	};

	beforeAll(() => {
		const trialGeneratorService = new TrialGeneratorService();

		for (let i = 0; i < numTrials; i++) {
			generatedTrials.push(
				trialGeneratorService.generateGrid(trialDetails)
			);
		}

		relationshipShapes = getTrialRelationshipShapes(trialDetails);
		targetShapes = getTrialTargetShapes(trialDetails);
	});

	it("generated grids should have correct proportion of targets and distractor targets", () => {
		generatedTrials.forEach((trial) => {
			let totalTargets = 0;
			let totalDistractorTargets = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isTarget) {
						totalTargets++;
					}
					if (shape.isDistractorTarget) {
						totalDistractorTargets++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			let totalDistractorTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
				totalDistractorTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
			});

			const targetProportion = totalTargets / totalShapes;
			const targetDiff = targetProportion - totalTargetProportion / 100;
			// can be up to 25% out
			expect(targetDiff).toBeGreaterThan(-maxError);
			expect(targetDiff).toBeLessThan(maxError);

			const distractorTargetProportion =
				totalDistractorTargets / totalShapes;
			const distractorTargetDiff =
				distractorTargetProportion -
				totalDistractorTargetProportion / 100;
			// can be up to 25% out
			expect(distractorTargetDiff).toBeGreaterThan(-maxError);
			expect(distractorTargetDiff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct near distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let nearDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isNearDistractor) {
						nearDistractors++;
					}
					totalShapes++;
				});
			});

			const nearDistractorProportion = nearDistractors / totalShapes;
			const diff =
				nearDistractorProportion -
				trialDetails.nearDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct far distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let farDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isFarDistractor) {
						farDistractors++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion += target.proportion;
			});
			let expectedFarDistractorProportion =
				100 -
				totalTargetProportion -
				trialDetails.nearDistractorProportion;

			const farDistractorProportion = farDistractors / totalShapes;
			const diff =
				farDistractorProportion - expectedFarDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("all targets and distractor targets should be target shapes", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (shape.isTarget || shape.isDistractorTarget) {
					expect(
						targetShapes.filter((s) => s === shape.file).length
					).toBe(1);
				}
			});
		});
	});

	it("all target shapes (by file) should be either targets or distractor targets", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (targetShapes.filter((s) => s === shape.file).length > 0) {
					expect(
						shape.isTarget || shape.isDistractorTarget
					).toBeTruthy();
				}
			});
		});
	});

	it("all targets should have relationship shapes before them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isTarget && index > 0) {
					expect(trial.shapes[index - 1].isRelationship).toBeTruthy();
					expect(
						relationshipShapes.filter(
							(s) => s === trial.shapes[index - 1].file
						).length
					).toBe(1);
				}
			});
		});
	});

	it("all relationship shapes should have target shapes after them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isRelationship && index + 1 < trial.shapes.length) {
					expect(trial.shapes[index + 1].isTarget).toBeTruthy();
					expect(
						targetShapes.filter(
							(s) => s === trial.shapes[index + 1].file
						).length
					).toBe(1);
				}
			});
		});
	});

	it("all distractor targets should not have relationship shapes before them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isDistractorTarget && index > 0) {
					expect(trial.shapes[index - 1].isRelationship).toBeFalsy();
					expect(
						relationshipShapes.filter(
							(s) => s === trial.shapes[index - 1].file
						).length
					).toBe(0);
				}
			});
		});
	});
});

describe("Is Not Before Relationship, No Withhold Response, Every Target", () => {
	let generatedTrials = [];
	let relationshipShapes = [];
	let targetShapes = [];
	let trialDetails = {
		nearDistractors: [
			"X_0_sharp.png",
			"T_0_sharp.png",
			"T_90_sharp.png",
			"T_180_sharp.png",
			"T_270_sharp.png",
			"I_0_sharp.png",
			"I_90_sharp.png",
			"O_0_sharp.png",
			"O_90_sharp.png",
		],
		farDistractors: [
			"X_0_round.png",
			"T_0_round.png",
			"T_90_round.png",
			"T_180_round.png",
			"T_270_round.png",
			"L_0_round.png",
			"L_90_round.png",
			"L_180_round.png",
			"L_270_round.png",
			"I_0_round.png",
			"I_90_round.png",
			"O_0_round.png",
			"O_90_round.png",
			"O_180_round.png",
		],
		numRows: 5,
		numNodesPerRow: 25,
		timeLimit: 60,
		showTimeLimit: true,
		showNextButton: false,
		numTrials: 5,
		targets: [
			{
				shapes: [
					"L_0_sharp.png",
					"L_90_sharp.png",
					"L_180_sharp.png",
					"L_270_sharp.png",
				],
				isNTarget: 1,
				relationship: true,
				relationshipRule: {
					shapes: [
						"T_0_sharp.png",
						"T_90_sharp.png",
						"T_180_sharp.png",
						"T_270_sharp.png",
					],
					not: true,
					position: "before",
					proportion: 50,
				},

				proportion: 25,
			},
		],
		nearDistractorProportion: 25,
		scanningDirectionVertical: "tb",
		scanningDirectionHorizontal: "lr",
		scanningDirectionLineByLine: "sd",
		withholdResponse: false,
		withholdNResponse: 2,
		withholdResponseOnlyForIsTarget: true,
		padding: 5,
		adaptive: true,
		adaptiveRules: [],
	};

	beforeAll(() => {
		const trialGeneratorService = new TrialGeneratorService();

		for (let i = 0; i < numTrials; i++) {
			generatedTrials.push(
				trialGeneratorService.generateGrid(trialDetails)
			);
		}

		relationshipShapes = getTrialRelationshipShapes(trialDetails);
		targetShapes = getTrialTargetShapes(trialDetails);
	});

	it("generated grids should have correct proportion of targets and distractor targets", () => {
		generatedTrials.forEach((trial) => {
			let totalTargets = 0;
			let totalDistractorTargets = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isTarget) {
						totalTargets++;
					}
					if (shape.isDistractorTarget) {
						totalDistractorTargets++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			let totalDistractorTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
				totalDistractorTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
			});

			const targetProportion = totalTargets / totalShapes;
			const targetDiff = targetProportion - totalTargetProportion / 100;
			// can be up to 25% out
			expect(targetDiff).toBeGreaterThan(-maxError);
			expect(targetDiff).toBeLessThan(maxError);

			const distractorTargetProportion =
				totalDistractorTargets / totalShapes;
			const distractorTargetDiff =
				distractorTargetProportion -
				totalDistractorTargetProportion / 100;
			// can be up to 25% out
			expect(distractorTargetDiff).toBeGreaterThan(-maxError);
			expect(distractorTargetDiff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct near distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let nearDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isNearDistractor) {
						nearDistractors++;
					}
					totalShapes++;
				});
			});

			const nearDistractorProportion = nearDistractors / totalShapes;
			const diff =
				nearDistractorProportion -
				trialDetails.nearDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct far distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let farDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isFarDistractor) {
						farDistractors++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion += target.proportion;
			});
			let expectedFarDistractorProportion =
				100 -
				totalTargetProportion -
				trialDetails.nearDistractorProportion;

			const farDistractorProportion = farDistractors / totalShapes;
			const diff =
				farDistractorProportion - expectedFarDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("all targets and distractor targets should be target shapes", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (shape.isTarget || shape.isDistractorTarget) {
					expect(
						targetShapes.filter((s) => s === shape.file).length
					).toBe(1);
				}
			});
		});
	});

	it("all target shapes (by file) should be either targets or distractor targets", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (targetShapes.filter((s) => s === shape.file).length > 0) {
					expect(
						shape.isTarget || shape.isDistractorTarget
					).toBeTruthy();
				}
			});
		});
	});

	it("all relationships (flagged) should have target shapes before them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isRelationship && index + 1 < trial.shapes.length) {
					expect(trial.shapes[index - 1].isTarget).toBeTruthy();
					// grid relationship shapes should not be the relationship shapes specified
					expect(
						targetShapes.filter(
							(s) => s === trial.shapes[index - 1].file
						).length
					).toBe(1);
				}
			});
		});
	});

	it("all distractor targets should have relationship shapes (but no flag) or target shapes after them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (
					shape.isDistractorTarget &&
					index + 1 < trial.shapes.length
				) {
					expect(
						relationshipShapes.filter(
							(s) => s === trial.shapes[index + 1].file
						).length ||
							targetShapes.filter(
								(s) => s === trial.shapes[index + 1].file
							).length
					).toBe(1);
				}
			});
		});
	});
});

describe("Is Not After Relationship, No Withhold Response, Every Target", () => {
	let generatedTrials = [];
	let relationshipShapes = [];
	let targetShapes = [];
	let trialDetails = {
		nearDistractors: [
			"X_0_sharp.png",
			"T_0_sharp.png",
			"T_90_sharp.png",
			"T_180_sharp.png",
			"T_270_sharp.png",
			"I_0_sharp.png",
			"I_90_sharp.png",
			"O_0_sharp.png",
			"O_90_sharp.png",
		],
		farDistractors: [
			"X_0_round.png",
			"T_0_round.png",
			"T_90_round.png",
			"T_180_round.png",
			"T_270_round.png",
			"L_0_round.png",
			"L_90_round.png",
			"L_180_round.png",
			"L_270_round.png",
			"I_0_round.png",
			"I_90_round.png",
			"O_0_round.png",
			"O_90_round.png",
			"O_180_round.png",
		],
		numRows: 5,
		numNodesPerRow: 25,
		timeLimit: 60,
		showTimeLimit: true,
		showNextButton: false,
		numTrials: 5,
		targets: [
			{
				shapes: [
					"L_0_sharp.png",
					"L_90_sharp.png",
					"L_180_sharp.png",
					"L_270_sharp.png",
				],
				isNTarget: 1,
				relationship: true,
				relationshipRule: {
					shapes: [
						"T_0_sharp.png",
						"T_90_sharp.png",
						"T_180_sharp.png",
						"T_270_sharp.png",
					],
					not: true,
					position: "after",
					proportion: 50,
				},
				proportion: 25,
			},
		],
		nearDistractorProportion: 25,
		scanningDirectionVertical: "tb",
		scanningDirectionHorizontal: "lr",
		scanningDirectionLineByLine: "sd",
		withholdResponse: false,
		withholdNResponse: 2,
		withholdResponseOnlyForIsTarget: true,
		padding: 5,
		adaptive: true,
		adaptiveRules: [],
	};

	beforeAll(() => {
		const trialGeneratorService = new TrialGeneratorService();

		for (let i = 0; i < numTrials; i++) {
			generatedTrials.push(
				trialGeneratorService.generateGrid(trialDetails)
			);
		}

		relationshipShapes = getTrialRelationshipShapes(trialDetails);
		targetShapes = getTrialTargetShapes(trialDetails);
	});

	it("generated grids should have correct proportion of targets and distractor targets", () => {
		generatedTrials.forEach((trial) => {
			let totalTargets = 0;
			let totalDistractorTargets = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isTarget) {
						totalTargets++;
					}
					if (shape.isDistractorTarget) {
						totalDistractorTargets++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			let totalDistractorTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
				totalDistractorTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
			});

			const targetProportion = totalTargets / totalShapes;
			const targetDiff = targetProportion - totalTargetProportion / 100;
			// can be up to 25% out
			expect(targetDiff).toBeGreaterThan(-maxError);
			expect(targetDiff).toBeLessThan(maxError);

			const distractorTargetProportion =
				totalDistractorTargets / totalShapes;
			const distractorTargetDiff =
				distractorTargetProportion -
				totalDistractorTargetProportion / 100;
			// can be up to 25% out
			expect(distractorTargetDiff).toBeGreaterThan(-maxError);
			expect(distractorTargetDiff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct near distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let nearDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isNearDistractor) {
						nearDistractors++;
					}
					totalShapes++;
				});
			});

			const nearDistractorProportion = nearDistractors / totalShapes;
			const diff =
				nearDistractorProportion -
				trialDetails.nearDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct far distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let farDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isFarDistractor) {
						farDistractors++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion += target.proportion;
			});
			let expectedFarDistractorProportion =
				100 -
				totalTargetProportion -
				trialDetails.nearDistractorProportion;

			const farDistractorProportion = farDistractors / totalShapes;
			const diff =
				farDistractorProportion - expectedFarDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("all targets and distractor targets should be target shapes", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (shape.isTarget || shape.isDistractorTarget) {
					expect(
						targetShapes.filter((s) => s === shape.file).length
					).toBe(1);
				}
			});
		});
	});

	it("all target shapes (by file) should be either targets or distractor targets", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (targetShapes.filter((s) => s === shape.file).length > 0) {
					expect(
						shape.isTarget || shape.isDistractorTarget
					).toBeTruthy();
				}
			});
		});
	});

	it("all relationships (flagged) should have target shapes after them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isRelationship && index + 1 < trial.shapes.length) {
					expect(trial.shapes[index + 1].isTarget).toBeTruthy();
					// grid relationship shapes should not be the relationship shapes specified
					expect(
						targetShapes.filter(
							(s) => s === trial.shapes[index + 1].file
						).length
					).toBe(1);
				}
			});
		});
	});

	it("all distractor targets should have relationship shapes (but no flag) before them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (
					shape.isDistractorTarget &&
					index - 1 < trial.shapes.length
				) {
					expect(
						relationshipShapes.filter(
							(s) => s === trial.shapes[index - 1].file
						).length
					).toBe(1);
				}
			});
		});
	});
});

describe("No Relationships, Withhold Response For Every Target, Every Target", () => {
	let generatedTrials = [];
	let targetShapes = [];
	let trialDetails = {
		nearDistractors: [
			"X_0_sharp.png",
			"T_0_sharp.png",
			"T_90_sharp.png",
			"T_180_sharp.png",
			"T_270_sharp.png",
			"I_0_sharp.png",
			"I_90_sharp.png",
			"O_0_sharp.png",
			"O_90_sharp.png",
		],
		farDistractors: [
			"X_0_round.png",
			"T_0_round.png",
			"T_90_round.png",
			"T_180_round.png",
			"T_270_round.png",
			"L_0_round.png",
			"L_90_round.png",
			"L_180_round.png",
			"L_270_round.png",
			"I_0_round.png",
			"I_90_round.png",
			"O_0_round.png",
			"O_90_round.png",
			"O_180_round.png",
		],
		_id: "5f041d30eb06934b74f316ac",
		numRows: 3,
		numNodesPerRow: 15,
		padding: 10,
		timeLimit: null,
		showTimeLimit: false,
		showNextButton: false,
		numTrials: 3,
		targets: [
			{
				shapes: [
					"L_0_sharp.png",
					"L_90_sharp.png",
					"L_180_sharp.png",
					"L_270_sharp.png",
				],
				_id: "5f041d30eb06934b74f316ad",
				isNTarget: "1",
				relationship: false,
				relationshipRule: {},
				proportion: 50,
				withholdResponseFor: 1,
			},
		],
		nearDistractorProportion: 20,
		scanningDirectionVertical: "tb",
		scanningDirectionHorizontal: "lr",
		scanningDirectionLineByLine: "sd",
		adaptive: false,
		adaptiveRules: [],
		showTrialRules: true,
		preTrialMessage: "",
		postTrialMessage: "",
		trialGap: 200,
	};

	beforeAll(() => {
		const trialGeneratorService = new TrialGeneratorService();

		for (let i = 0; i < numTrials; i++) {
			generatedTrials.push(
				trialGeneratorService.generateGrid(trialDetails)
			);
		}

		targetShapes = getTrialTargetShapes(trialDetails);
	});

	it("should have withhold response set for every target", () => {
		generatedTrials.forEach((trial) => {
			trial.shapes.forEach((shape) => {
				if (shape.isTarget) {
					expect(shape.withholdResponse).toBeTruthy();
				}
			});
		});
	});

	it("all target shapes (by file) should be targets", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (targetShapes.filter((s) => s === shape.file).length > 0) {
					expect(shape.isTarget).toBeTruthy();
				}
			});
		});
	});
});

describe("No Relationships, Withhold Response For Every 2nd Shape, Every Target", () => {
	let generatedTrials = [];
	let targetShapes = [];
	let trialDetails = {
		nearDistractors: [
			"X_0_sharp.png",
			"T_0_sharp.png",
			"T_90_sharp.png",
			"T_180_sharp.png",
			"T_270_sharp.png",
			"I_0_sharp.png",
			"I_90_sharp.png",
			"O_0_sharp.png",
			"O_90_sharp.png",
		],
		farDistractors: [
			"X_0_round.png",
			"T_0_round.png",
			"T_90_round.png",
			"T_180_round.png",
			"T_270_round.png",
			"L_0_round.png",
			"L_90_round.png",
			"L_180_round.png",
			"L_270_round.png",
			"I_0_round.png",
			"I_90_round.png",
			"O_0_round.png",
			"O_90_round.png",
			"O_180_round.png",
		],
		_id: "5f041d30eb06934b74f316ac",
		numRows: 3,
		numNodesPerRow: 15,
		padding: 10,
		timeLimit: null,
		showTimeLimit: false,
		showNextButton: false,
		numTrials: 3,
		targets: [
			{
				shapes: [
					"L_0_sharp.png",
					"L_90_sharp.png",
					"L_180_sharp.png",
					"L_270_sharp.png",
				],
				_id: "5f041d30eb06934b74f316ad",
				isNTarget: "1",
				relationship: false,
				relationshipRule: {},
				proportion: 50,
				withholdResponseFor: 2,
			},
		],
		nearDistractorProportion: 20,
		scanningDirectionVertical: "tb",
		scanningDirectionHorizontal: "lr",
		scanningDirectionLineByLine: "sd",
		adaptive: false,
		adaptiveRules: [],
		showTrialRules: true,
		preTrialMessage: "",
		postTrialMessage: "",
		trialGap: 200,
	};

	beforeAll(() => {
		const trialGeneratorService = new TrialGeneratorService();

		for (let i = 0; i < numTrials; i++) {
			generatedTrials.push(
				trialGeneratorService.generateGrid(trialDetails)
			);
		}

		targetShapes = getTrialTargetShapes(trialDetails);
	});

	it("should have withhold response set for every 2nd target", () => {
		generatedTrials.forEach((trial) => {
			let targetNum = 0;
			trial.shapes.forEach((shape) => {
				if (shape.isTarget) {
					if ((targetNum + 1) % 2 === 0) {
						expect(shape.withholdResponse).toBeTruthy();
					}
					targetNum++;
				}
			});
		});
	});

	it("all target shapes (by file) should be either targets", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (targetShapes.filter((s) => s === shape.file).length > 0) {
					expect(shape.isTarget).toBeTruthy();
				}
			});
		});
	});
});

describe("No Relationships, No Withhold Response, Multiple Targets - One With All And One Every 2nd", () => {
	let generatedTrials = [];
	let trialDetails = {
		nearDistractors: [
			"X_0_sharp.png",
			"T_0_sharp.png",
			"T_90_sharp.png",
			"T_180_sharp.png",
			"T_270_sharp.png",
			"I_0_sharp.png",
			"I_90_sharp.png",
			"O_0_sharp.png",
			"O_90_sharp.png",
		],
		farDistractors: [
			"X_0_round.png",
			"T_0_round.png",
			"T_90_round.png",
			"T_180_round.png",
			"T_270_round.png",
			"L_0_round.png",
			"L_90_round.png",
			"L_180_round.png",
			"L_270_round.png",
			"I_0_round.png",
			"I_90_round.png",
			"O_0_round.png",
			"O_90_round.png",
			"O_180_round.png",
		],
		numRows: 5,
		numNodesPerRow: 20,
		timeLimit: 60,
		showTimeLimit: true,
		showNextButton: false,
		numTrials: 5,
		targets: [
			{
				shapes: ["L_0_round.png", "L_90_round.png"],
				_id: "5edf9e3b4c37785110d9068e",
				isNTarget: 1,
				relationship: false,
				relationshipRule: {},
				proportion: 20,
			},
			{
				shapes: ["L_0_sharp.png", "L_90_sharp.png"],
				_id: "5edf9e3b4c37785110d9068f",
				isNTarget: 2,
				relationship: false,
				relationshipRule: {},
				proportion: 20,
			},
		],
		nearDistractorProportion: 20,
		scanningDirectionVertical: "tb",
		scanningDirectionHorizontal: "lr",
		scanningDirectionLineByLine: "sd",
		withholdResponse: false,
		withholdNResponse: 2,
		withholdResponseOnlyForIsTarget: true,
		padding: 5,
		adaptive: true,
		adaptiveRules: [
			{
				_id: "5ede3f65c6361b9299abbf71",
				afterNTrials: 1,
				averageStatistic: "timeRemaining",
				averageStatisticComparison: "lessThan",
				averageStatisticPercentage: 95,
				updateVariable: "timeLimit",
				updateVariablePercentage: 10,
				continuous: true,
			},
			{
				_id: "5ede3f65c6361b9299abbf72",
				afterNTrials: 1,
				averageStatistic: "timeRemaining",
				averageStatisticComparison: "greaterThan",
				averageStatisticPercentage: 60,
				updateVariable: "gridSize",
				updateVariablePercentage: 20,
				continuous: true,
			},
		],
	};
	beforeAll(() => {
		const trialGeneratorService = new TrialGeneratorService();

		for (let i = 0; i < numTrials; i++) {
			generatedTrials.push(
				trialGeneratorService.generateGrid(trialDetails)
			);
		}
	});

	it("should have correct n targets for each set of targets with distractors set correctly", () => {
		generatedTrials.forEach((trial) => {
			trialDetails.targets.forEach((target) => {
				let targetNum = 0;

				trial.shapes.forEach((shape) => {
					if (shape.isTarget || shape.isDistractorTarget) {
						// shape is one from that target
						if (shape.targetInfo._id === target._id) {
							if (target.isNTarget === 1) {
								expect(shape.isNotNthTarget).toBeFalsy();
								expect(shape.isDistractorTarget).toBeFalsy();
								expect(shape.isTarget).toBeTruthy();
							} else {
								if ((targetNum + 1) % target.isNTarget === 0) {
									expect(shape.isNotNthTarget).toBeFalsy();
									expect(
										shape.isDistractorTarget
									).toBeFalsy();
									expect(shape.isTarget).toBeTruthy();
								} else {
									expect(shape.isNotNthTarget).toBeTruthy();
									expect(
										shape.isDistractorTarget
									).toBeTruthy();
									expect(shape.isTarget).toBeFalsy();
								}
							}
							targetNum++;
						}
					}
				});
			});
		});
	});
});

describe("Is Before Relationship With Same Shape As Target, No Withhold Response, Every Target", () => {
	let generatedTrials = [];
	let relationshipShapes = [];
	let targetShapes = [];
	let trialDetails = {
		numRows: 5,
		numNodesPerRow: 25,
		padding: 10,
		timeLimit: null,
		showTimeLimit: false,
		showNextButton: false,
		numTrials: 1,
		targets: [
			{
				shapes: ["L_0_sharp.png"],
				isNTarget: 1,
				relationship: true,
				relationshipRule: {
					not: false,
					position: "before",
					shapes: ["L_0_sharp.png"],
					proportion: 50,
				},
				targetAfter: [],
				targetBefore: [],
				withholdResponse: false,
				withholdNResponse: 1,
				withholdResponseOnlyForIsTarget: false,
				proportion: 20,
			},
		],
		targetProportion: 20,
		nearDistractors: [
			"X_0_sharp.png",
			"T_0_sharp.png",
			"T_90_sharp.png",
			"T_180_sharp.png",
			"T_270_sharp.png",
			"I_0_sharp.png",
			"I_90_sharp.png",
			"O_0_sharp.png",
			"O_90_sharp.png",
		],
		nearDistractorProportion: 20,
		farDistractors: [
			"X_0_round.png",
			"T_0_round.png",
			"T_90_round.png",
			"T_180_round.png",
			"T_270_round.png",
			"L_0_round.png",
			"L_90_round.png",
			"L_180_round.png",
			"L_270_round.png",
			"I_0_round.png",
			"I_90_round.png",
			"O_0_round.png",
			"O_90_round.png",
			"O_180_round.png",
		],
		scanningDirectionVertical: "tb",
		scanningDirectionHorizontal: "lr",
		scanningDirectionLineByLine: "sd",
		withholdResponse: false,
		withholdNResponse: 1,
		withholdResponseOnlyForIsTarget: false,
		adaptive: false,
		adaptiveRules: [],
	};

	beforeAll(() => {
		const trialGeneratorService = new TrialGeneratorService();

		for (let i = 0; i < numTrials; i++) {
			generatedTrials.push(
				trialGeneratorService.generateGrid(trialDetails)
			);
		}

		relationshipShapes = getTrialRelationshipShapes(trialDetails);
		targetShapes = getTrialTargetShapes(trialDetails);
	});

	it("generated grids should have correct proportion of targets and distractor targets", () => {
		generatedTrials.forEach((trial) => {
			let totalTargets = 0;
			let totalDistractorTargets = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isTarget) {
						totalTargets++;
					}
					if (shape.isDistractorTarget) {
						totalDistractorTargets++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			let totalDistractorTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
				totalDistractorTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
			});

			const targetProportion = totalTargets / totalShapes;
			const targetDiff = targetProportion - totalTargetProportion / 100;
			// can be up to 25% out
			expect(targetDiff).toBeGreaterThan(-maxError);
			expect(targetDiff).toBeLessThan(maxError);

			const distractorTargetProportion =
				totalDistractorTargets / totalShapes;
			const distractorTargetDiff =
				distractorTargetProportion -
				totalDistractorTargetProportion / 100;
			// can be up to 25% out
			expect(distractorTargetDiff).toBeGreaterThan(-maxError);
			expect(distractorTargetDiff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct near distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let nearDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isNearDistractor) {
						nearDistractors++;
					}
					totalShapes++;
				});
			});

			const nearDistractorProportion = nearDistractors / totalShapes;
			const diff =
				nearDistractorProportion -
				trialDetails.nearDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct far distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let farDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isFarDistractor) {
						farDistractors++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion += target.proportion;
			});
			let expectedFarDistractorProportion =
				100 -
				totalTargetProportion -
				trialDetails.nearDistractorProportion;

			const farDistractorProportion = farDistractors / totalShapes;
			const diff =
				farDistractorProportion - expectedFarDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("all targets and distractor targets should be target shapes", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (shape.isTarget || shape.isDistractorTarget) {
					expect(
						targetShapes.filter((s) => s === shape.file).length
					).toBe(1);
				}
			});
		});
	});

	it("all target shapes (by file) should be either targets, distractor targets or relationships", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (targetShapes.filter((s) => s === shape.file).length > 0) {
					expect(
						shape.isTarget ||
							shape.isDistractorTarget ||
							shape.isRelationship
					).toBeTruthy();
				}
			});
		});
	});

	it("all targets should have relationship or target shapes after them but not before them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isTarget && index + 1 < trial.shapes.length) {
					if (trial.shapes[index + 1]) {
						expect(
							trial.shapes[index + 1].isRelationship ||
								trial.shapes[index + 1].isTarget
						).toBeTruthy();
						expect(
							relationshipShapes.filter(
								(s) => s === trial.shapes[index + 1].file
							).length
						).toBe(1);
					}
					if (trial.shapes[index - 1]) {
						expect(
							trial.shapes[index - 1].isRelationship
						).toBeFalsy();
					}
				}
			});
		});
	});

	it("all relationships should have target shapes before them but not after", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isRelationship && index + 1 < trial.shapes.length) {
					expect(trial.shapes[index - 1].isTarget).toBeTruthy();
					expect(
						targetShapes.filter(
							(s) => s === trial.shapes[index - 1].file
						).length
					).toBe(1);
					expect(
						targetShapes.filter(
							(s) => s === trial.shapes[index + 1].file
						).length
					).toBe(0);
				}
			});
		});
	});

	it("all distractor targets should not have relationship shapes after them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (
					shape.isDistractorTarget &&
					index + 1 < trial.shapes.length
				) {
					expect(trial.shapes[index + 1].isRelationship).toBeFalsy();
					expect(
						relationshipShapes.filter(
							(s) => s === trial.shapes[index + 1].file
						).length
					).toBe(0);
				}
			});
		});
	});
});

describe("Is Not Before Relationship With Same Shape As Target, No Withhold Response, Every Target", () => {
	let generatedTrials = [];
	let relationshipShapes = [];
	let targetShapes = [];
	let trialDetails = {
		nearDistractors: [
			"X_0_sharp.png",
			"T_0_sharp.png",
			"T_90_sharp.png",
			"T_180_sharp.png",
			"T_270_sharp.png",
			"I_0_sharp.png",
			"I_90_sharp.png",
			"O_0_sharp.png",
			"O_90_sharp.png",
		],
		farDistractors: [
			"X_0_round.png",
			"T_0_round.png",
			"T_90_round.png",
			"T_180_round.png",
			"T_270_round.png",
			"L_0_round.png",
			"L_90_round.png",
			"L_180_round.png",
			"L_270_round.png",
			"I_0_round.png",
			"I_90_round.png",
			"O_0_round.png",
			"O_90_round.png",
			"O_180_round.png",
		],
		_id: "5efb08210286b0928865aeea",
		numRows: 6,
		numNodesPerRow: 30,
		padding: 10,
		timeLimit: null,
		showTimeLimit: false,
		showNextButton: false,
		numTrials: 1,
		targets: [
			{
				shapes: ["L_0_sharp.png"],
				_id: "5efb08210286b0928865aeeb",
				isNTarget: 1,
				relationship: true,
				relationshipRule: {
					shapes: ["L_0_sharp.png"],
					not: true,
					_id: "5efb19730286b0928865aef9",
					position: "before",
					proportion: 50,
				},
				proportion: 40,
			},
		],
		nearDistractorProportion: 20,
		scanningDirectionVertical: "tb",
		scanningDirectionHorizontal: "lr",
		scanningDirectionLineByLine: "sd",
		withholdResponse: false,
		withholdNResponse: 1,
		withholdResponseOnlyForIsTarget: false,
		adaptive: false,
		adaptiveRules: [],
	};

	beforeAll(() => {
		const trialGeneratorService = new TrialGeneratorService();

		for (let i = 0; i < numTrials; i++) {
			generatedTrials.push(
				trialGeneratorService.generateGrid(trialDetails)
			);
		}

		relationshipShapes = getTrialRelationshipShapes(trialDetails);
		targetShapes = getTrialTargetShapes(trialDetails);
	});

	it("generated grids should have correct proportion of targets and distractor targets", () => {
		generatedTrials.forEach((trial) => {
			let totalTargets = 0;
			let totalDistractorTargets = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isTarget) {
						totalTargets++;
					}
					if (shape.isDistractorTarget) {
						totalDistractorTargets++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			let totalDistractorTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
				totalDistractorTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
			});

			const targetProportion = totalTargets / totalShapes;
			const targetDiff = targetProportion - totalTargetProportion / 100;
			// can be up to 25% out
			expect(targetDiff).toBeGreaterThan(-maxError);
			expect(targetDiff).toBeLessThan(maxError);

			const distractorTargetProportion =
				totalDistractorTargets / totalShapes;
			const distractorTargetDiff =
				distractorTargetProportion -
				totalDistractorTargetProportion / 100;
			// can be up to 25% out
			expect(distractorTargetDiff).toBeGreaterThan(-maxError);
			expect(distractorTargetDiff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct near distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let nearDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isNearDistractor) {
						nearDistractors++;
					}
					totalShapes++;
				});
			});

			const nearDistractorProportion = nearDistractors / totalShapes;
			const diff =
				nearDistractorProportion -
				trialDetails.nearDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct far distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let farDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isFarDistractor) {
						farDistractors++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion += target.proportion;
			});
			let expectedFarDistractorProportion =
				100 -
				totalTargetProportion -
				trialDetails.nearDistractorProportion;

			const farDistractorProportion = farDistractors / totalShapes;
			const diff =
				farDistractorProportion - expectedFarDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("all targets and distractor targets should be target shapes", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (shape.isTarget || shape.isDistractorTarget) {
					expect(
						targetShapes.filter((s) => s === shape.file).length
					).toBe(1);
				}
			});
		});
	});

	it("all targets should not have relationship or target shapes after them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isTarget && index + 1 < trial.shapes.length) {
					expect(
						trial.shapes[index + 1].isRelationship &&
							trial.shapes[index + 1].isTarget
					).toBeFalsy();
					expect(
						relationshipShapes.filter(
							(s) => s === trial.shapes[index + 1].file
						).length
					).toBe(0);
				}
			});
		});
	});

	it("all relationships (flagged) should have target shapes before them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isRelationship && index + 1 < trial.shapes.length) {
					expect(trial.shapes[index - 1].isTarget).toBeTruthy();
					// grid relationship shapes should not be the relationship shapes specified
					expect(
						targetShapes.filter(
							(s) => s === trial.shapes[index - 1].file
						).length
					).toBe(1);
				}
			});
		});
	});

	it("all distractor targets should have relationship shapes (but no flag) after them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (
					shape.isDistractorTarget &&
					index + 1 < trial.shapes.length
				) {
					expect(
						relationshipShapes.filter(
							(s) => s === trial.shapes[index + 1].file
						).length
					).toBe(1);
				}
			});
		});
	});
});

describe("Is After Relationship With Same Shape As Target, No Withhold Response, Every Target", () => {
	let generatedTrials = [];
	let relationshipShapes = [];
	let targetShapes = [];
	let trialDetails = {
		numRows: 5,
		numNodesPerRow: 25,
		padding: 10,
		timeLimit: null,
		showTimeLimit: false,
		showNextButton: false,
		numTrials: 1,
		targets: [
			{
				shapes: ["L_0_sharp.png"],
				isNTarget: 1,
				relationship: true,
				relationshipRule: {
					not: false,
					position: "after",
					shapes: ["L_0_sharp.png"],
					proportion: 50,
				},

				targetAfter: [],
				targetBefore: [],
				withholdResponse: false,
				withholdNResponse: 1,
				withholdResponseOnlyForIsTarget: false,
				proportion: 20,
			},
		],
		targetProportion: 20,
		nearDistractors: [
			"X_0_sharp.png",
			"T_0_sharp.png",
			"T_90_sharp.png",
			"T_180_sharp.png",
			"T_270_sharp.png",
			"I_0_sharp.png",
			"I_90_sharp.png",
			"O_0_sharp.png",
			"O_90_sharp.png",
		],
		nearDistractorProportion: 20,
		farDistractors: [
			"X_0_round.png",
			"T_0_round.png",
			"T_90_round.png",
			"T_180_round.png",
			"T_270_round.png",
			"L_0_round.png",
			"L_90_round.png",
			"L_180_round.png",
			"L_270_round.png",
			"I_0_round.png",
			"I_90_round.png",
			"O_0_round.png",
			"O_90_round.png",
			"O_180_round.png",
		],
		scanningDirectionVertical: "tb",
		scanningDirectionHorizontal: "lr",
		scanningDirectionLineByLine: "sd",
		withholdResponse: false,
		withholdNResponse: 1,
		withholdResponseOnlyForIsTarget: false,
		adaptive: false,
		adaptiveRules: [],
	};

	beforeAll(() => {
		const trialGeneratorService = new TrialGeneratorService();

		for (let i = 0; i < numTrials; i++) {
			generatedTrials.push(
				trialGeneratorService.generateGrid(trialDetails)
			);
		}

		relationshipShapes = getTrialRelationshipShapes(trialDetails);
		targetShapes = getTrialTargetShapes(trialDetails);
	});

	it("generated grids should have correct proportion of targets and distractor targets", () => {
		generatedTrials.forEach((trial) => {
			let totalTargets = 0;
			let totalDistractorTargets = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isTarget) {
						totalTargets++;
					}
					if (shape.isDistractorTarget) {
						totalDistractorTargets++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			let totalDistractorTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
				totalDistractorTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
			});

			const targetProportion = totalTargets / totalShapes;
			const targetDiff = targetProportion - totalTargetProportion / 100;
			// can be up to 25% out
			expect(targetDiff).toBeGreaterThan(-maxError);
			expect(targetDiff).toBeLessThan(maxError);

			const distractorTargetProportion =
				totalDistractorTargets / totalShapes;
			const distractorTargetDiff =
				distractorTargetProportion -
				totalDistractorTargetProportion / 100;
			// can be up to 25% out
			expect(distractorTargetDiff).toBeGreaterThan(-maxError);
			expect(distractorTargetDiff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct near distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let nearDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isNearDistractor) {
						nearDistractors++;
					}
					totalShapes++;
				});
			});

			const nearDistractorProportion = nearDistractors / totalShapes;
			const diff =
				nearDistractorProportion -
				trialDetails.nearDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct far distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let farDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isFarDistractor) {
						farDistractors++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion += target.proportion;
			});
			let expectedFarDistractorProportion =
				100 -
				totalTargetProportion -
				trialDetails.nearDistractorProportion;

			const farDistractorProportion = farDistractors / totalShapes;
			const diff =
				farDistractorProportion - expectedFarDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("all targets and distractor targets should be target shapes", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (shape.isTarget || shape.isDistractorTarget) {
					expect(
						targetShapes.filter((s) => s === shape.file).length
					).toBe(1);
				}
			});
		});
	});

	it("all target shapes (by file) should be either targets, distractor targets or relationships", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (targetShapes.filter((s) => s === shape.file).length > 0) {
					expect(
						shape.isTarget ||
							shape.isDistractorTarget ||
							shape.isRelationship
					).toBeTruthy();
				}
			});
		});
	});

	it("all targets should have relationship or target shapes before them but not after them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isTarget && index + 1 < trial.shapes.length) {
					expect(
						trial.shapes[index - 1].isRelationship ||
							trial.shapes[index - 1].isTarget
					).toBeTruthy();
					expect(
						relationshipShapes.filter(
							(s) => s === trial.shapes[index - 1].file
						).length
					).toBe(1);
					if (trial.shapes[index + 1]) {
						expect(
							trial.shapes[index + 1].isRelationship
						).toBeFalsy();
					}
				}
			});
		});
	});

	it("all relationships should have target shapes after them but not before", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isRelationship && index + 1 < trial.shapes.length) {
					// expect(trial.shapes[index + 1].isTarget).toBeTruthy();
					expect(
						targetShapes.filter(
							(s) => s === trial.shapes[index + 1].file
						).length
					).toBe(1);
					if (trial.shapes[index - 1]) {
						expect(trial.shapes[index - 1].isTarget).toBeFalsy();
						// expect(
						// 	targetShapes.filter(
						// 		(s) => s === trial.shapes[index - 1].file
						// 	).length
						// ).toBe(0);
					}
				}
			});
		});
	});

	it("all distractor targets should not have relationship shapes before them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (
					shape.isDistractorTarget &&
					index + 1 < trial.shapes.length
				) {
					expect(trial.shapes[index - 1].isRelationship).toBeFalsy();
					expect(
						relationshipShapes.filter(
							(s) => s === trial.shapes[index - 1].file
						).length
					).toBe(0);
				}
			});
		});
	});
});

describe("Is Not After Relationship With Same Shape As Target, No Withhold Response, Every Target", () => {
	let generatedTrials = [];
	let relationshipShapes = [];
	let targetShapes = [];
	let trialDetails = {
		nearDistractors: [
			"X_0_sharp.png",
			"T_0_sharp.png",
			"T_90_sharp.png",
			"T_180_sharp.png",
			"T_270_sharp.png",
			"I_0_sharp.png",
			"I_90_sharp.png",
			"O_0_sharp.png",
			"O_90_sharp.png",
		],
		farDistractors: [
			"X_0_round.png",
			"T_0_round.png",
			"T_90_round.png",
			"T_180_round.png",
			"T_270_round.png",
			"L_0_round.png",
			"L_90_round.png",
			"L_180_round.png",
			"L_270_round.png",
			"I_0_round.png",
			"I_90_round.png",
			"O_0_round.png",
			"O_90_round.png",
			"O_180_round.png",
		],
		_id: "5efb08210286b0928865aeea",
		numRows: 6,
		numNodesPerRow: 30,
		padding: 10,
		timeLimit: null,
		showTimeLimit: false,
		showNextButton: false,
		numTrials: 1,
		targets: [
			{
				shapes: ["L_0_sharp.png"],
				_id: "5efb08210286b0928865aeeb",
				isNTarget: 1,
				relationship: true,
				relationshipRule: {
					shapes: ["L_0_sharp.png"],
					not: true,
					_id: "5efb19730286b0928865aef9",
					position: "after",
					proportion: 50,
				},
				proportion: 40,
			},
		],
		nearDistractorProportion: 20,
		scanningDirectionVertical: "tb",
		scanningDirectionHorizontal: "lr",
		scanningDirectionLineByLine: "sd",
		withholdResponse: false,
		withholdNResponse: 1,
		withholdResponseOnlyForIsTarget: false,
		adaptive: false,
		adaptiveRules: [],
	};

	beforeAll(() => {
		const trialGeneratorService = new TrialGeneratorService();

		for (let i = 0; i < numTrials; i++) {
			generatedTrials.push(
				trialGeneratorService.generateGrid(trialDetails)
			);
		}

		relationshipShapes = getTrialRelationshipShapes(trialDetails);
		targetShapes = getTrialTargetShapes(trialDetails);
	});

	it("generated grids should have correct proportion of targets and distractor targets", () => {
		generatedTrials.forEach((trial) => {
			let totalTargets = 0;
			let totalDistractorTargets = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isTarget) {
						totalTargets++;
					}
					if (shape.isDistractorTarget) {
						totalDistractorTargets++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			let totalDistractorTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
				totalDistractorTargetProportion +=
					target.proportion *
					(target.relationshipRule.proportion / 100);
			});

			const targetProportion = totalTargets / totalShapes;
			const targetDiff = targetProportion - totalTargetProportion / 100;
			// can be up to 25% out
			expect(targetDiff).toBeGreaterThan(-maxError);
			expect(targetDiff).toBeLessThan(maxError);

			const distractorTargetProportion =
				totalDistractorTargets / totalShapes;
			const distractorTargetDiff =
				distractorTargetProportion -
				totalDistractorTargetProportion / 100;
			// can be up to 25% out
			expect(distractorTargetDiff).toBeGreaterThan(-maxError);
			expect(distractorTargetDiff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct near distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let nearDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isNearDistractor) {
						nearDistractors++;
					}
					totalShapes++;
				});
			});

			const nearDistractorProportion = nearDistractors / totalShapes;
			const diff =
				nearDistractorProportion -
				trialDetails.nearDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("generated grids should have the correct far distractor proportion", () => {
		generatedTrials.forEach((trial) => {
			let farDistractors = 0;
			let totalShapes = 0;

			trial.grid.forEach((row) => {
				row.forEach((shape) => {
					if (shape.isFarDistractor) {
						farDistractors++;
					}
					totalShapes++;
				});
			});

			let totalTargetProportion = 0;
			trialDetails.targets.forEach((target) => {
				totalTargetProportion += target.proportion;
			});
			let expectedFarDistractorProportion =
				100 -
				totalTargetProportion -
				trialDetails.nearDistractorProportion;

			const farDistractorProportion = farDistractors / totalShapes;
			const diff =
				farDistractorProportion - expectedFarDistractorProportion / 100;
			// can be up to 25% out
			expect(diff).toBeGreaterThan(-maxError);
			expect(diff).toBeLessThan(maxError);
		});
	});

	it("all targets and distractor targets should be target shapes", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape) => {
				if (shape.isTarget || shape.isDistractorTarget) {
					expect(
						targetShapes.filter((s) => s === shape.file).length
					).toBe(1);
				}
			});
		});
	});

	it("all targets should not have relationship or target shapes before them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isTarget && index + 1 < trial.shapes.length) {
					expect(
						trial.shapes[index - 1].isRelationship &&
							trial.shapes[index - 1].isTarget
					).toBeFalsy();
					expect(
						relationshipShapes.filter(
							(s) => s === trial.shapes[index - 1].file
						).length
					).toBe(0);
				}
			});
		});
	});

	it("all relationships (flagged) should have target shapes after them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (shape.isRelationship && index + 1 < trial.shapes.length) {
					expect(trial.shapes[index + 1].isTarget).toBeTruthy();
					// grid relationship shapes should not be the relationship shapes specified
					expect(
						targetShapes.filter(
							(s) => s === trial.shapes[index + 1].file
						).length
					).toBe(1);
				}
			});
		});
	});

	it("all distractor targets should have relationship shapes (but no flag) before them", () => {
		generatedTrials.forEach((trial) => {
			// use shapes as there are no rows to handle
			trial.shapes.forEach((shape, index) => {
				if (
					shape.isDistractorTarget &&
					index + 1 < trial.shapes.length
				) {
					expect(
						relationshipShapes.filter(
							(s) => s === trial.shapes[index - 1].file
						).length
					).toBe(1);
				}
			});
		});
	});
});

describe("1x1 Grid", () => {
	let generatedTrials = [];
	let trialDetails = {
		nearDistractors: [
			"X_0_sharp.png",
			"T_0_sharp.png",
			"T_90_sharp.png",
			"T_180_sharp.png",
			"T_270_sharp.png",
			"I_0_sharp.png",
			"I_90_sharp.png",
			"O_0_sharp.png",
			"O_90_sharp.png",
		],
		farDistractors: [
			"X_0_round.png",
			"T_0_round.png",
			"T_90_round.png",
			"T_180_round.png",
			"T_270_round.png",
			"L_0_round.png",
			"L_90_round.png",
			"L_180_round.png",
			"L_270_round.png",
			"I_0_round.png",
			"I_90_round.png",
			"O_0_round.png",
			"O_90_round.png",
			"O_180_round.png",
		],
		_id: "5f02da4cd790e044343511c7",
		numRows: "1",
		numNodesPerRow: "1",
		padding: "300",
		timeLimit: null,
		showTimeLimit: false,
		showNextButton: false,
		numTrials: 1,
		targets: [
			{
				shapes: ["X_0_round.png"],
				_id: "5f02da4cd790e044343511c8",
				isNTarget: 1,
				relationship: false,
				relationshipRule: {},
				proportion: 50,
				withholdResponseFor: 0,
			},
		],
		nearDistractorProportion: 20,
		scanningDirectionVertical: "tb",
		scanningDirectionHorizontal: "lr",
		scanningDirectionLineByLine: "sd",
		adaptive: false,
		adaptiveRules: [],
		showTrialRules: true,
		preTrialMessage: "",
		postTrialMessage: "",
		trialGap: 200,
	};

	beforeAll(() => {
		const trialGeneratorService = new TrialGeneratorService();

		for (let i = 0; i < numTrials; i++) {
			generatedTrials.push(
				trialGeneratorService.generateSingleShapeGrid(trialDetails)
			);
		}
	});

	it("generated grid should only have one shape", () => {
		generatedTrials.forEach((trial) => {
			expect(trial.shapes.length).toBe(1);
		});
	});

	it("single shape should be a target proportionally", () => {
		let totalTargets = 0;
		generatedTrials.forEach((trial) => {
			if (trial.shapes[0].isTarget) {
				totalTargets++;
			}
		});

		let totalTargetProportion = 0;
		trialDetails.targets.forEach((target) => {
			totalTargetProportion += target.proportion;
		});

		const targetProportion = totalTargets / generatedTrials.length;
		const diff = targetProportion - totalTargetProportion / 100;
		// can be up to 25% out
		expect(diff).toBeGreaterThan(-maxError);
		expect(diff).toBeLessThan(maxError);
	});
});

// helper methods
function getTrialRelationshipShapes(trialDetails) {
	let relationshipShapes = [];
	trialDetails.targets.forEach((target) => {
		if (target.relationship) {
			relationshipShapes = target.relationshipRule.shapes;
		}
	});
	return relationshipShapes;
}

function getTrialTargetShapes(trialDetails) {
	let targetShapes = [];
	trialDetails.targets.forEach((target) => {
		targetShapes = targetShapes.concat(target.shapes);
	});
	return targetShapes;
}
